package fr.icdc.dei.edt.presentation.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.security.concurrent.DelegatingSecurityContextRunnable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.HexaposteService;
import fr.icdc.dei.lm4.paraneo.metier.service.SuiviTraitementService;
import fr.icdc.dei.lm4.paraneo.metier.service.impl.TraitementHexaposte;
import fr.icdc.dei.lm4.paraneo.presentation.commun.controller.AbstractReferentielController;

@Controller
public class HexaposteController extends AbstractReferentielController{

	private static final String MESSAGE_ERREUR = "messageErreur";

	private static final String VUE_HEXAPOSTE = "hexaposte";

	@Autowired
	private TaskExecutor taskExecutor;

	@Autowired
	private TraitementHexaposte traitementHexaposte;
	
	@Resource(name = "hexaposteBusinessService")
	private HexaposteService service;
	
	@Resource(name = "suiviTraitementService")
	private SuiviTraitementService suiviTraitementService;
	
	
	private static final Logger LOGGER = Logger.getLogger(HexaposteController.class);

	
	@RequestMapping(value = "/hexaposte")
	public ModelAndView lancerTraitementHexaposte(){
		// On choisit le menu actif (surligne en bleu)
		cacheHolder.getMenuItems();
		pickMenu(ParaneoConstantes.CODE_MENU_HEXAPOSTE, null);

		ModelAndView model = new ModelAndView(VUE_HEXAPOSTE); // Nom de la vue dans templates.xml (qui contient le nom de la JSP)
		
		return model;
		
	}
	
	@RequestMapping(value ="/hexaposteformulaire")
	public ModelAndView gererFormulaire(@RequestParam("file") MultipartFile file) {
		String nomFichier = file.getOriginalFilename();
		ModelAndView model;
		try {
			
			InputStream fluxFichier = file.getInputStream();
			ByteArrayOutputStream copieFluxFichier = new ByteArrayOutputStream();
			IOUtils.copy(fluxFichier, copieFluxFichier);
			byte[] octets = copieFluxFichier.toByteArray();
			ByteArrayInputStream fluxComptageFichier = new ByteArrayInputStream(octets);
			ByteArrayInputStream fluxLectureFichier = new ByteArrayInputStream(octets);
			
			String empreinte = DigestUtils.md5DigestAsHex(octets);			
			
			if(suiviTraitementService.isEmpreinteDejaTraitee("HEXAPOSTE",empreinte)){
				model = new ModelAndView(VUE_HEXAPOSTE); // Nom de la vue dans templates.xml (qui contient le nom de la JSP)
				model.addObject(MESSAGE_ERREUR,"paraneo.hexaposte.erreur.empreinte");				
			} else {		
				if(nomFichier.endsWith(".tri")){
					if(service.hasNombreDeLignesSuffisant(fluxComptageFichier)){
						if(!suiviTraitementService.isTraitementEnCours("HEXAPOSTE")){
							Authentication auth = SecurityContextHolder.getContext().getAuthentication();
							String nomUtilisateur = auth.getName();
			
							traitementHexaposte.setFichierHexaposte(fluxLectureFichier);
							traitementHexaposte.setNomUtilisateur(nomUtilisateur);
							traitementHexaposte.setEmpreinte(empreinte);
							SecurityContext securityContext = SecurityContextHolder.getContext();
							DelegatingSecurityContextRunnable delegatingSecurityContextRunnable = new DelegatingSecurityContextRunnable(traitementHexaposte, securityContext);
							taskExecutor.execute(delegatingSecurityContextRunnable);
							model = new ModelAndView(VUE_HEXAPOSTE);
							model.addObject("messageSuccess","paraneo.hexaposte.succes");
						} else {
							model = new ModelAndView(VUE_HEXAPOSTE); // Nom de la vue dans templates.xml (qui contient le nom de la JSP)
							model.addObject(MESSAGE_ERREUR,"paraneo.hexaposte.erreur.traitementencours");	
						}
					} else {
						model = new ModelAndView(VUE_HEXAPOSTE); // Nom de la vue dans templates.xml (qui contient le nom de la JSP)
						model.addObject(MESSAGE_ERREUR,"paraneo.hexaposte.erreur.fichiervide");						
					}
				} else {
					model = new ModelAndView(VUE_HEXAPOSTE); // Nom de la vue dans templates.xml (qui contient le nom de la JSP)
					model.addObject(MESSAGE_ERREUR,"paraneo.hexaposte.erreur.mauvaiseextension");
				}
			}

		} catch(BusinessServiceException | IOException e){
			LOGGER.error("Erreur dans le lancement du traitement Hexaposte",e);
			model = new ModelAndView(VUE_HEXAPOSTE); // Nom de la vue dans templates.xml (qui contient le nom de la JSP)
			model.addObject(MESSAGE_ERREUR,"Erreur lors du lancement du traitement. Veuillez contacter votre support technique.");			
		}
		return model;

		

	}
}
