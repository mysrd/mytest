package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeFiliereLmtay401;

public class TaTypeFiliereLmtay401ToString implements Converter<TaTypeFiliereLmtay401,String> {

	@Override
	public String convert(TaTypeFiliereLmtay401 arg0) {
		return arg0.getCdtyfi();
	}

}
