package fr.icdc.dei.lm4.paraneo.presentation.converters;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.core.convert.converter.Converter;

public class StringToDate implements Converter<String,Date>{
	private static final Logger LOGGER = Logger.getLogger(StringToDate.class);

	@Override
	public Date convert(String arg0) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			return sdf.parse(arg0);
		} catch (ParseException e) {
			LOGGER.error(e);
		}
		return null;
	}

}
