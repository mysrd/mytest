package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleFiscaleLmtay934;

public class TaFamilleFiscaleLmtay934ToString implements Converter<TaFamilleFiscaleLmtay934,String> {

	@Override
	public String convert(TaFamilleFiscaleLmtay934 arg0) {
		return arg0.getCofafi();
	}

}
