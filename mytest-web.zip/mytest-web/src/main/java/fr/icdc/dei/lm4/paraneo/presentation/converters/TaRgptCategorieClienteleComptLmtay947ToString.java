package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRgptCategorieClienteleComptLmtay947;

public class TaRgptCategorieClienteleComptLmtay947ToString implements Converter<TaRgptCategorieClienteleComptLmtay947,String> {

	@Override
	public String convert(TaRgptCategorieClienteleComptLmtay947 arg0) {
		return arg0.getCcclir();
	}

}
