package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeNomEnClair;

public class StringToTaTypeDeNomEnClair implements Converter<String,TaTypeDeNomEnClair> {

	@Override
	public TaTypeDeNomEnClair convert(String arg0) {
		TaTypeDeNomEnClair object = new TaTypeDeNomEnClair();
		object.setTncc(arg0.split("-")[0]);
		return object;
	}

}
