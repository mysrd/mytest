package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleFiscaleLmtay934;

public class StringToTaFamilleFiscaleLmtay934 implements Converter<String,TaFamilleFiscaleLmtay934> {

	@Override
	public TaFamilleFiscaleLmtay934 convert(String arg0) {
		TaFamilleFiscaleLmtay934 object = new TaFamilleFiscaleLmtay934();
		object.setCofafi(arg0.split("-")[0]);
		return object;
	}



}
