package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategSicovamDeClientLmtay524;

public class TaCategSicovamDeClientLmtay524ToString implements Converter<TaCategSicovamDeClientLmtay524,String> {

	@Override
	public String convert(TaCategSicovamDeClientLmtay524 arg0) {
		return arg0.getCcacli();
	}

}
