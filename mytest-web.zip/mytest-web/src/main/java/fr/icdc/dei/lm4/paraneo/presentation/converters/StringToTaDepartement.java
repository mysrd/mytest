package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDepartement;

public class StringToTaDepartement implements Converter<String,TaDepartement> {

	@Override
	public TaDepartement convert(String arg0) {
		TaDepartement object = new TaDepartement();
		object.setYc0dep(arg0.split("-")[0]);
		return object;
	}

}
