package fr.icdc.dei.lm4.paraneo.presentation.commun.helper;

import java.io.IOException;
import java.io.InputStream;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

public class VersionUtil {

	public static String readVersion() throws IOException {

		InputStream inputStream = HttpRuntimeHelper.getSessionContext().getServletContext().getResourceAsStream("/META-INF/MANIFEST.MF");
		Manifest manifest = new Manifest(inputStream);
		if (manifest.getMainAttributes() != null) {
			String version = manifest.getMainAttributes().getValue(Attributes.Name.IMPLEMENTATION_VERSION);
			inputStream.close();
			return version;
		}
		return null;
	}

}
