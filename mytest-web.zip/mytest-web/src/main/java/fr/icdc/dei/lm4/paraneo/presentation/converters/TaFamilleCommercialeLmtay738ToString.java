package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleCommercialeLmtay738;

public class TaFamilleCommercialeLmtay738ToString implements Converter<TaFamilleCommercialeLmtay738,String> {

	@Override
	public String convert(TaFamilleCommercialeLmtay738 arg0) {
		return arg0.getC0fcm();
	}

}
