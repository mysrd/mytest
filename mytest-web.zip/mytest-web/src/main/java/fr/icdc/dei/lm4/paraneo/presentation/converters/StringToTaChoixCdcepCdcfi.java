package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaChoixCdcepCdcfi;

public class StringToTaChoixCdcepCdcfi implements Converter<String,TaChoixCdcepCdcfi> {

	@Override
	public TaChoixCdcepCdcfi convert(String arg0) {
		TaChoixCdcepCdcfi object = new TaChoixCdcepCdcfi();
		object.setC0etcd(arg0.split("-")[0]);
		return object;
		}


}



