package fr.icdc.dei.edt.presentation.controller;

import java.io.Serializable;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables.TableDescriptionDto;

@Component
@Scope(value="session",proxyMode=ScopedProxyMode.TARGET_CLASS)
public class ValeursUtilisateurEdittable implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * Table à afficher dans l'écran détail.
	 */
	private TableDescriptionDto tableAAfficher;

	/**
	 * Liste des enregistrements de la table à afficher.
	 */
	private List<Object> objetsTableAAfficher;

	/**
	 * Valeur du formulaire (<=> un enregistrement d'une table) avant
	 * modification de celui-ci.
	 */
	private Object oldValue;


	private List<String> tablesEnConsultation;

	private List<String> tablesEnCreation;

	private List<String> tablesEnModification;

	private List<String> tablesEnSuppression;

	private List<String> tablesEnNotification;


	@SuppressWarnings("rawtypes")
	private Class classe;

	public TableDescriptionDto getTableAAfficher() {
		return tableAAfficher;
	}

	public void setTableAAfficher(TableDescriptionDto tableAAfficher) {
		this.tableAAfficher = tableAAfficher;
	}

	public List<Object> getObjetsTableAAfficher() {
		return objetsTableAAfficher;
	}

	public void setObjetsTableAAfficher(List<Object> objetsTableAAfficher) {
		this.objetsTableAAfficher = objetsTableAAfficher;
	}

	public Object getOldValue() {
		return oldValue;
	}

	public void setOldValue(Object oldValue) {
		this.oldValue = oldValue;
	}

	public Class getClasse() {
		return classe;
	}

	public void setClasse(Class classe) {
		this.classe = classe;
	}

	public List<String> getTablesEnConsultation() {
		return tablesEnConsultation;
	}

	public void setTablesEnConsultation(List<String> tablesEnConsultation) {
		this.tablesEnConsultation = tablesEnConsultation;
	}

	public List<String> getTablesEnModification() {
		return tablesEnModification;
	}

	public void setTablesEnModification(List<String> tablesEnModification) {
		this.tablesEnModification = tablesEnModification;
	}

	public List<String> getTablesEnCreation() {
		return tablesEnCreation;
	}

	public void setTablesEnCreation(List<String> tablesEnCreation) {
		this.tablesEnCreation = tablesEnCreation;
	}

	public List<String> getTablesEnSuppression() {
		return tablesEnSuppression;
	}

	public void setTablesEnSuppression(List<String> tablesEnSuppression) {
		this.tablesEnSuppression = tablesEnSuppression;
	}

	public List<String> getTablesEnNotification() {
		return tablesEnNotification;
	}

	public void setTablesEnNotification(List<String> tablesEnNotification) {
		this.tablesEnNotification = tablesEnNotification;
	}


}
