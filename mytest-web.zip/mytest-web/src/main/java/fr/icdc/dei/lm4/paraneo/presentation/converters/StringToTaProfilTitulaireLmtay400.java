package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaProfilTitulaireLmtay400;

public class StringToTaProfilTitulaireLmtay400 implements Converter<String,TaProfilTitulaireLmtay400> {

	@Override
	public TaProfilTitulaireLmtay400 convert(String arg0) {
		TaProfilTitulaireLmtay400 object = new TaProfilTitulaireLmtay400();
		object.setCprtit(arg0.split("-")[0]);
		return object;
	}



}
