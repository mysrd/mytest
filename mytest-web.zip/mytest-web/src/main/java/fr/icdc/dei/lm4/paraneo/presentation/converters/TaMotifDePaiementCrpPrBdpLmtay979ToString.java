package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaMotifDePaiementCrpPrBdpLmtay979;



public class TaMotifDePaiementCrpPrBdpLmtay979ToString implements Converter<TaMotifDePaiementCrpPrBdpLmtay979,String> {

	@Override
	public String convert(TaMotifDePaiementCrpPrBdpLmtay979 arg0) {
		return arg0.getCmpai();
	}

}
