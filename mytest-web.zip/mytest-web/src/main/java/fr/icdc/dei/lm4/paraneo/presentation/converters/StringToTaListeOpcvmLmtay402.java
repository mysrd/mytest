package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaListeOpcvmLmtay402;

public class StringToTaListeOpcvmLmtay402 implements Converter<String,TaListeOpcvmLmtay402> {

	@Override
	public TaListeOpcvmLmtay402 convert(String arg0) {
		TaListeOpcvmLmtay402 object = new TaListeOpcvmLmtay402();
		object.setCdlopc(arg0.split("-")[0]);
		return object;
	}



}
