
package fr.icdc.dei.lm4.paraneo.pivot.schema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

import org.w3c.dom.Element;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaApparentementCdcLmtay538;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategSicovamDeClientLmtay524;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieContrepartieFmLmtay799;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieDeClientLmtay523;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieDeContrepartieBicLmtay830;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieDeDeposantLmtay525;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieEconomiqueLmtay930;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaClassificationBale2Lmtay717;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaClassificationMifLmtay718;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeComptableElementaireGmtamo06;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeEditiqueLmtay403;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodePostal;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodificationReglementaireLmtay997;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCommuneInsee;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaComplementStructureBanqLmtay890;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaConventionFiscaleFranceLmtay716;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCorrespondanceMetierRoleLmtay719;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDepartement;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDeviseLmtay502;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaEtatDuClientLmtay532;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaEtatPersonneMoraleLmtay786;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleCommercialeLmtay738;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleFiscaleLmtay934;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFormeJuridiqueDgiLmtay518;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieBoursePlaceLmtay755;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieCambistePaysLmtay741;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieCdcLmtay591;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieCeLmtay596;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieLegalParPaysLmtay602;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieOcBdfLmtay603;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFeriePosteLmtay509;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieSitPepsLmtay984;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieTargetLmtay739;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieTresorLmtay593;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLienCategClientDeposantLmtay560;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLienCategClientSicovamLmtay533;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLieuDeCompensationLmtay891;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaListeOpcvmLmtay402;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaMetierOperationnelTiersLmtay787;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaModeDeGestionClientsLmtay831;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNatureJuridiqueFicobaLmtay504;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNomenclatInseeActivEconomLmtay677;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNomenclatureDeClienteleLmtay774;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaPaysLmtay501;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaProfilTitulaireLmtay400;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaQualiteNormalQualitePolitesLmtay527;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaQualiteNormaliseeLmtay520;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaQualitePolitesseLmtay526;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegimeMatrimonialLmtay788;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegionAdministrativeLmtay547;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaResidenceFiscaleFicobaLmtay511;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRoleDeTiersLmtay778;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTierCorrespInseeNomfaLmtay999;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeAdresseElectroniqueLmtay789;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeAdresseLmtay540;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeCodificationDesTiersLmtay796;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeGestionLmtay793;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeLienEntreTiersLmtay797;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeRestrictionSicovamLmtay794;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeTiersLmtay791;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeFiliereLmtay401;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeQualificationFiscaleCliLmtay983;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeQualificationFiscaleIntLmtay982;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeSituationMatrimonialesLmtay792;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeUtilisationAdresseLmtay790;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaUniteDeConfidentialiteFbLmtay894;



/**
 * <p>Classe Java pour anonymous complex type.
 *
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;any processContents='lax'/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "any"
})
@XmlSeeAlso({TaProfilTitulaireLmtay400.class,
			 TaTypeFiliereLmtay401.class,
			 TaListeOpcvmLmtay402.class,
			 TaCodeEditiqueLmtay403.class,
			 TaFormeJuridiqueDgiLmtay518.class,
			 TaCategSicovamDeClientLmtay524.class,
			 TaCategorieDeDeposantLmtay525.class,
			 TaLienCategClientSicovamLmtay533.class,
			 TaApparentementCdcLmtay538.class,
			 TaLienCategClientDeposantLmtay560.class,
			 TaClassificationBale2Lmtay717.class,
			 TaClassificationMifLmtay718.class,
			 TaFamilleCommercialeLmtay738.class,
			 TaNomenclatureDeClienteleLmtay774.class,
			 TaEtatPersonneMoraleLmtay786.class,
			 TaRegimeMatrimonialLmtay788.class,
			 TaTypeAdresseElectroniqueLmtay789.class,
			 TaTypeDeTiersLmtay791.class,
			 TaTypeSituationMatrimonialesLmtay792.class,
			 TaTypeDeGestionLmtay793.class,
			 TaTypeDeRestrictionSicovamLmtay794.class,
			 TaTypeCodificationDesTiersLmtay796.class,
			 TaTypeDeLienEntreTiersLmtay797.class,
			 TaCategorieContrepartieFmLmtay799.class,
			 TaModeDeGestionClientsLmtay831.class,
			 TaQualiteNormalQualitePolitesLmtay527.class,
			 TaQualiteNormaliseeLmtay520.class,
			 TaQualitePolitesseLmtay526.class,
			 TaCategorieDeClientLmtay523.class,
			 TaTypeUtilisationAdresseLmtay790.class,
			 TaTypeAdresseLmtay540.class,
			 TaResidenceFiscaleFicobaLmtay511.class,
			 TaTierCorrespInseeNomfaLmtay999.class,
			 TaRoleDeTiersLmtay778.class,
			 TaMetierOperationnelTiersLmtay787.class,
			 TaCorrespondanceMetierRoleLmtay719.class,
			 TaJourFerieTargetLmtay739.class,
			 TaConventionFiscaleFranceLmtay716.class,
			 TaDeviseLmtay502.class,
			 TaJourFerieBoursePlaceLmtay755.class,
			 TaJourFerieCambistePaysLmtay741.class,
			 TaJourFerieCdcLmtay591.class,
			 TaJourFerieCeLmtay596.class,
			 TaJourFerieLegalParPaysLmtay602.class,
			 TaJourFerieOcBdfLmtay603.class,
			 TaJourFeriePosteLmtay509.class,
			 TaJourFerieSitPepsLmtay984.class,
			 TaJourFerieTresorLmtay593.class,
			 TaPaysLmtay501.class,
			 TaTypeQualificationFiscaleCliLmtay983.class,
			 TaTypeQualificationFiscaleIntLmtay982.class,
			 TaCategorieEconomiqueLmtay930.class,
			 TaCodificationReglementaireLmtay997.class,
			 TaCategorieDeContrepartieBicLmtay830.class,
			 TaFamilleFiscaleLmtay934.class,
			 TaEtatDuClientLmtay532.class,
			 TaNatureJuridiqueFicobaLmtay504.class,
			 TaNomenclatInseeActivEconomLmtay677.class,
			 TaComplementStructureBanqLmtay890.class,
			 TaLieuDeCompensationLmtay891.class,
			 TaRegion2016.class,
			 TaCodePostal.class,
			 TaCommuneInsee.class,
			 TaDepartement.class,
			 TaRegionAdministrativeLmtay547.class,
			 TaCodeComptableElementaireGmtamo06.class,
			 TaUniteDeConfidentialiteFbLmtay894.class
			 })
@XmlRootElement(name = "Reponse")
public class Reponse {

    @XmlAnyElement(lax = true)
    protected Object any;

    /**
     * Obtient la valeur de la propriété any.
     *
     * @return
     *     possible object is
     *     {@link Element }
     *     {@link Object }
     *
     */
    public Object getAny() {
        return any;
    }

    /**
     * Définit la valeur de la propriété any.
     *
     * @param value
     *     allowed object is
     *     {@link Element }
     *     {@link Object }
     *
     */
    public void setAny(Object value) {
        this.any = value;
    }

}
