package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeRegroupementCategorieBic;

public class TaCodeRegroupementCategorieBicToString implements Converter<TaCodeRegroupementCategorieBic,String> {

	@Override
	public String convert(TaCodeRegroupementCategorieBic arg0) {
		return arg0.getCrcbic();
	}


}
