package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaMotifDePaiementCrpPrBdpLmtay979;

public class StringToTaMotifDePaiementCrpPrBdpLmtay979 implements Converter<String,TaMotifDePaiementCrpPrBdpLmtay979> {

	@Override
	public TaMotifDePaiementCrpPrBdpLmtay979 convert(String arg0) {
		TaMotifDePaiementCrpPrBdpLmtay979 object = new TaMotifDePaiementCrpPrBdpLmtay979();
		object.setCmpai(arg0.split("-")[0]);
		return object;
	}



}
