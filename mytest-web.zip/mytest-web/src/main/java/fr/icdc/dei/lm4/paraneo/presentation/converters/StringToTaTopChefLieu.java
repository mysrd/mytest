package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopChefLieu;

public class StringToTaTopChefLieu implements Converter<String,TaTopChefLieu> {

	@Override
	public TaTopChefLieu convert(String arg0) {
		TaTopChefLieu object = new TaTopChefLieu();
		object.setTchefl(arg0.split("-")[0]);
		return object;
	}

}
