package fr.icdc.dei.lm4.paraneo.presentation.commun.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;

@Controller
public class HomeController extends AbstractReferentielController {

	private final static Logger LOGGER = LoggerFactory
			.getLogger(HomeController.class);



	@RequestMapping(value = "/accueil")
	public String showAccueil() throws Exception {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		LOGGER.debug("Appel de AccueilController.afficherAccueil()");
		cacheHolder.getMenuItems();
		LOGGER.info("Connection à l'application PARANEO par l'utilisateur "+userDetails.getUsername()+" avec le(s) role(s) :"+userDetails.getAuthorities());
		pickMenu(ParaneoConstantes.CODE_MENU_ACCUEIL, null);

		return "accueil.scene";
	}

	@RequestMapping(value = "/login")
	public String showLogin() throws Exception {
		LOGGER.debug("Appel de AccueilController.afficherLogin()");
		cacheHolder.getVersion();
		return "login.scene";
	}

	@RequestMapping(value = "/healthCheck")
	public String showHealthCheck() throws Exception {
		LOGGER.debug("Appel de HomeController.showHealthCheck()");

		return "healthcheck/healthCheck";
	}

}
