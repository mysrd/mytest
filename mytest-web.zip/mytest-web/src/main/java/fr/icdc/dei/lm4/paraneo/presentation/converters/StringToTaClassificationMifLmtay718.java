package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaClassificationMifLmtay718;

public class StringToTaClassificationMifLmtay718 implements Converter<String,TaClassificationMifLmtay718> {

	@Override
	public TaClassificationMifLmtay718 convert(String arg0) {
		TaClassificationMifLmtay718 object = new TaClassificationMifLmtay718();
		object.setYc0mif(arg0.split("-")[0]);
		return object;
	}



}
