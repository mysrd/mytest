package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRoleDeTiersLmtay778;

public class TaRoleDeTiersLmtay778ToString implements Converter<TaRoleDeTiersLmtay778,String> {

	@Override
	public String convert(TaRoleDeTiersLmtay778 arg0) {
		return arg0.getYcrolt();
	}

}
