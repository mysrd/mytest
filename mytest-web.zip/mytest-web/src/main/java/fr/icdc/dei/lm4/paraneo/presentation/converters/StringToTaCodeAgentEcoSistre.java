package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeAgentEcoSistre;

public class StringToTaCodeAgentEcoSistre implements Converter<String,TaCodeAgentEcoSistre> {

	@Override
	public TaCodeAgentEcoSistre convert(String arg0) {
		TaCodeAgentEcoSistre object = new TaCodeAgentEcoSistre();
		object.setCagsis(arg0.split("-")[0]);
		return object;
		}


}



