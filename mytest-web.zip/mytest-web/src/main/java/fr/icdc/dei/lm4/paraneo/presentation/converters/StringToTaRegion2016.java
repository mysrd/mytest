package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016;

public class StringToTaRegion2016 implements Converter<String,TaRegion2016> {

	@Override
	public TaRegion2016 convert(String arg0) {
		TaRegion2016 object = new TaRegion2016();
		object.setRegion(arg0.split("-")[0]);
		return object;
	}

}
