package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDepartement;

public class TaDepartementToString implements Converter<TaDepartement,String> {

	@Override
	public String convert(TaDepartement arg0) {
		return arg0.getYc0dep();
	}

}
