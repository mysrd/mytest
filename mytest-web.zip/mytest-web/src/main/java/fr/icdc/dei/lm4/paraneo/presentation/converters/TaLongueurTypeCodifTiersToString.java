package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLongueurTypeCodifTiers;

public class TaLongueurTypeCodifTiersToString implements Converter<TaLongueurTypeCodifTiers,String> {

	@Override
	public String convert(TaLongueurTypeCodifTiers arg0) {
		return Integer.toString(arg0.getYlgtct());
	}

}
