package fr.icdc.dei.lm4.paraneo.presentation.commun.dto;

import java.util.ArrayList;
import java.util.List;

import fr.icdc.dei.lm4.paraneo.entite.transverse.DroitsMenuEnum;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Menu;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.AbstractDto;

public class MenuDto extends AbstractDto{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String codeMenu;
	private String libelleMenu;

	private String url;

	private boolean valide;

	private Integer ordre;

	private List<DroitsMenuEnum> droits;

	private String structures;

	private List<MenuDto> noeudsEnfants = new ArrayList<MenuDto>();

	private Menu parent;

	private boolean estSelectionne;

	/**
	 *
	 */
	public MenuDto() {
		super();
	}

	/**
	 * @return the codeMenu
	 */
	public String getCodeMenu() {
		return codeMenu;
	}

	/**
	 * @param codeMenu
	 *            the codeMenu to set
	 */
	public void setCodeMenu(String codeMenu) {
		this.codeMenu = codeMenu;
	}

	/**
	 * @return the libelleMenu
	 */
	public String getLibelleMenu() {
		return libelleMenu;
	}

	/**
	 * @param libelleMenu
	 *            the libelleMenu to set
	 */
	public void setLibelleMenu(String libelleMenu) {
		this.libelleMenu = libelleMenu;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the valide
	 */
	public boolean isValide() {
		return valide;
	}

	/**
	 * @param valide
	 *            the valide to set
	 */
	public void setValide(boolean valide) {
		this.valide = valide;
	}

	/**
	 * @return the ordre
	 */
	public Integer getOrdre() {
		return ordre;
	}

	/**
	 * @param ordre
	 *            the ordre to set
	 */
	public void setOrdre(Integer ordre) {
		this.ordre = ordre;
	}

	/**
	 * @return the structures
	 */
	public String getStructures() {
		return structures;
	}

	/**
	 * @param structures
	 *            the structures to set
	 */
	public void setStructures(String structures) {
		this.structures = structures;
	}

	/**
	 * @return the noeudsEnfant
	 */
	public List<MenuDto> getNoeudsEnfants() {
		return noeudsEnfants;
	}

	/**
	 * @param noeudsEnfants
	 *            the noeudsEnfant to set
	 */
	public void setNoeudsEnfants(List<MenuDto> noeudsEnfants) {
		this.noeudsEnfants = noeudsEnfants;
	}

	/**
	 * @return the parent
	 */
	public Menu getParent() {
		return parent;
	}

	/**
	 * @param parent
	 *            the parent to set
	 */
	public void setParent(Menu parent) {
		this.parent = parent;
	}

	public boolean isEstSelectionne() {
		return estSelectionne;
	}

	public void setEstSelectionne(boolean estSelectionne) {
		this.estSelectionne = estSelectionne;
	}

	/**
	 * @param droits
	 *            the droits to set
	 */
	public void setDroits(List<DroitsMenuEnum> droits) {
		this.droits = droits;
	}

	/**
	 * @return the droits
	 */
	public List<DroitsMenuEnum> getDroits() {
		return droits;
	}

}
