package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDeviseLmtay502;

public class StringToTaDeviseLmtay502 implements Converter<String,TaDeviseLmtay502> {

	@Override
	public TaDeviseLmtay502 convert(String arg0) {
		TaDeviseLmtay502 object = new TaDeviseLmtay502();
		object.setCdev(arg0.split("-")[0]);
		return object;
	}
}
