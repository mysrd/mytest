package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopDecoupageCommuneCantons;

public class TaTopDecoupageCommuneCantonsToString implements Converter<TaTopDecoupageCommuneCantons,String> {

	@Override
	public String convert(TaTopDecoupageCommuneCantons arg0) {
		return arg0.getCdc();
	}

}
