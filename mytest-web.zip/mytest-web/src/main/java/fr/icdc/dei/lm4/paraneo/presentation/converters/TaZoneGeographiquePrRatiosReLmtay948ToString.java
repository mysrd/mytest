package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaZoneGeographiquePrRatiosReLmtay948;

public class TaZoneGeographiquePrRatiosReLmtay948ToString implements Converter<TaZoneGeographiquePrRatiosReLmtay948,String> {

	@Override
	public String convert(TaZoneGeographiquePrRatiosReLmtay948 arg0) {
		return arg0.getCzgeor();
	}

}
