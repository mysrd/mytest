package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopChefLieu;

public class TaTopChefLieuToString implements Converter<TaTopChefLieu,String> {

	@Override
	public String convert(TaTopChefLieu arg0) {
		return arg0.getTchefl();
	}

}
