package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTerritorialiteFicobaLmtay508;

public class StringToTaTerritorialiteFicobaLmtay508 implements Converter<String,TaTerritorialiteFicobaLmtay508> {

	@Override
	public TaTerritorialiteFicobaLmtay508 convert(String arg0) {
		TaTerritorialiteFicobaLmtay508 object = new TaTerritorialiteFicobaLmtay508();
		object.setCte(arg0.split("-")[0]);
		return object;
	}

}
