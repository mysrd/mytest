package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeNomEnClair;

public class TaTypeDeNomEnClairToString implements Converter<TaTypeDeNomEnClair,String> {

	@Override
	public String convert(TaTypeDeNomEnClair arg0) {
		return arg0.getTncc();
	}

}
