package fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables;


import java.util.Comparator;
import java.util.List;
import java.util.Map;

import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.AbstractDto;


public class TableDescriptionDto extends AbstractDto {

	/**
	 * Le nom de la classe qui correspond à l'entité.
	 */
	private String entityClassName;

	/**
	 * Le nom de la table qui correspond à l'entité.
	 */
	private String tableName;

	/**
	 * Le nom de la clé primaire.
	 */
	private String idName;

	/**
	 * Le nom de la classe de la clé primaire.
	 */
	private String idClassName;

	/**
	 * Permet de dire si la cléprimaire est composée.
	 */
	private boolean compositeId;

	/**
	 * Liste de colonnes de la table {@link ColumnDescriptionDto}.
	 */
	private List<ColumnDescriptionDto> columnList;

	/**
	 * Clé : nom de la colonne<br>
	 * Valeur : {@link ColumnDescriptionDto}.
	 */
	private Map<String, ColumnDescriptionDto> columnNameColumnDescriptionMap;

	/**
	 * Clé: nom de l'attribut<br>
	 * Valeur : {@link ColumnDescriptionDto}.
	 */
	private Map<String, ColumnDescriptionDto> propertyNameColumnDescriptionMap;

	private TableConfigurationDto configuration;

	public TableDescriptionDto() {

	}

	/**
	 * TableDescription est un objet qui contient des informations concernant
	 * une entité et sa table correpondante.
	 */
	public TableDescriptionDto(TableConfigImpl config, String entityClassName, String tableName, String idName, String idClassName, boolean isCompositeId,
			List<ColumnDescriptionDto> columnList, Map<String, ColumnDescriptionDto> columnNameColumnDescriptionMap,
			Map<String, ColumnDescriptionDto> propertyNameColumnDescriptionMap) {

		this.entityClassName = entityClassName;

		this.tableName = tableName;

		this.columnList = columnList;

		this.idClassName = idClassName;

		this.idName = idName;

		this.compositeId = isCompositeId;

		this.columnNameColumnDescriptionMap = columnNameColumnDescriptionMap;

		this.propertyNameColumnDescriptionMap = propertyNameColumnDescriptionMap;
	}



	/**
	 * @return the entityClassName
	 */
	public String getEntityClassName() {
		return entityClassName;
	}

	/**
	 * @param entityClassName the entityClassName to set
	 */
	public void setEntityClassName(String entityClassName) {
		this.entityClassName = entityClassName;
	}

	/**
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param tableName the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return the idName
	 */
	public String getIdName() {
		return idName;
	}

	/**
	 * @param idName the idName to set
	 */
	public void setIdName(String idName) {
		this.idName = idName;
	}

	/**
	 * @return the idClassName
	 */
	public String getIdClassName() {
		return idClassName;
	}

	/**
	 * @param idClassName the idClassName to set
	 */
	public void setIdClassName(String idClassName) {
		this.idClassName = idClassName;
	}

	/**
	 * @return the compositeId
	 */
	public boolean isCompositeId() {
		return compositeId;
	}

	/**
	 * @param compositeId the compositeId to set
	 */
	public void setCompositeId(boolean compositeId) {
		this.compositeId = compositeId;
	}

	/**
	 * @return the columnList
	 */
	public List<ColumnDescriptionDto> getColumnList() {
		return columnList;
	}

	/**
	 * @param columnList the columnList to set
	 */
	public void setColumnList(List<ColumnDescriptionDto> columnList) {
		this.columnList = columnList;
	}

	/**
	 * @return the columnNameColumnDescriptionMap
	 */
	public Map<String, ColumnDescriptionDto> getColumnNameColumnDescriptionMap() {
		return columnNameColumnDescriptionMap;
	}

	/**
	 * @param columnNameColumnDescriptionMap the columnNameColumnDescriptionMap to set
	 */
	public void setColumnNameColumnDescriptionMap(Map<String, ColumnDescriptionDto> columnNameColumnDescriptionMap) {
		this.columnNameColumnDescriptionMap = columnNameColumnDescriptionMap;
	}

	/**
	 * @return the propertyNameColumnDescriptionMap
	 */
	public Map<String, ColumnDescriptionDto> getPropertyNameColumnDescriptionMap() {
		return propertyNameColumnDescriptionMap;
	}

	/**
	 * @param propertyNameColumnDescriptionMap the propertyNameColumnDescriptionMap to set
	 */
	public void setPropertyNameColumnDescriptionMap(Map<String, ColumnDescriptionDto> propertyNameColumnDescriptionMap) {
		this.propertyNameColumnDescriptionMap = propertyNameColumnDescriptionMap;
	}


	/**
	 * @return the configuration
	 */
	public TableConfigurationDto getConfiguration() {
		return configuration;
	}

	/**
	 * @param configuration the configuration to set
	 */
	public void setConfiguration(TableConfigurationDto configuration) {
		this.configuration = configuration;
	}

	/**
	 * Permet de r�cup�rer un {@link Comparator} permettant de comparer deux {@link TableDescriptionDto} selon leur nom de table de mani�re asc.
	 * @return
	 */
	public static final Comparator<TableDescriptionDto> getComparatorByTableNameAsc() {
		Comparator<TableDescriptionDto> comparator = new Comparator<TableDescriptionDto>() {

			@Override
			public int compare(TableDescriptionDto o1, TableDescriptionDto o2) {
				String nom1 = o1.getTableName();
				String nom2 = o2.getTableName();
				if (nom1 == null ^ nom2 == null) {
			        return (nom1 == null) ? -1 : 1;
			    }
			    if (nom1 == null && nom2 == null) {
			        return 0;
			    }
				return nom1.compareTo(nom2);
			}
		};
		return comparator;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tableName == null) ? 0 : tableName.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (!(obj instanceof TableDescriptionDto)){
			return false;
		}
		TableDescriptionDto other = (TableDescriptionDto) obj;
		if (tableName == null) {
			if (other.tableName != null){
				return false;
			}
		} else if (!tableName.equals(other.tableName)){
			return false;
		}
		return true;
	}
}
