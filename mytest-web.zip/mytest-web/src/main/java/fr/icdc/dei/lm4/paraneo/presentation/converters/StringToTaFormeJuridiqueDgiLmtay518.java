package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFormeJuridiqueDgiLmtay518;

public class StringToTaFormeJuridiqueDgiLmtay518 implements Converter<String,TaFormeJuridiqueDgiLmtay518> {

	@Override
	public TaFormeJuridiqueDgiLmtay518 convert(String arg0) {
		TaFormeJuridiqueDgiLmtay518 object = new TaFormeJuridiqueDgiLmtay518();
		object.setYc0fjd(arg0.split("-")[0]);
		return object;
	}



}
