package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaPaysLmtay501;

public class StringToTaPaysLmtay501 implements Converter<String,TaPaysLmtay501> {

	@Override
	public TaPaysLmtay501 convert(String arg0) {
		TaPaysLmtay501 object = new TaPaysLmtay501();
		object.setCpay(arg0.split("-")[0]);
		return object;
	}

}
