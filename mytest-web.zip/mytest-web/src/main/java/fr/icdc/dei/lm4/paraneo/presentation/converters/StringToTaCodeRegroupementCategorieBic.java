package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeRegroupementCategorieBic;

public class StringToTaCodeRegroupementCategorieBic implements Converter<String,TaCodeRegroupementCategorieBic> {

	@Override
	public TaCodeRegroupementCategorieBic convert(String arg0) {
		TaCodeRegroupementCategorieBic object = new TaCodeRegroupementCategorieBic();
		object.setCrcbic(arg0.split("-")[0]);
		return object;
		}


}



