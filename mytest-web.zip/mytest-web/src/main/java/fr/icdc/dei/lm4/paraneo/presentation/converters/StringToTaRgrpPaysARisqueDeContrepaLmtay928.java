package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRgrpPaysARisqueDeContrepaLmtay928;

public class StringToTaRgrpPaysARisqueDeContrepaLmtay928 implements Converter<String,TaRgrpPaysARisqueDeContrepaLmtay928> {

	@Override
	public TaRgrpPaysARisqueDeContrepaLmtay928 convert(String arg0) {
		TaRgrpPaysARisqueDeContrepaLmtay928 object = new TaRgrpPaysARisqueDeContrepaLmtay928();
		object.setCrgpay(arg0.split("-")[0]);
		return object;
	}

}