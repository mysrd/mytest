package fr.icdc.dei.lm4.paraneo.presentation.exception;

/**
 *
 * Exception commune aux exceptions de l'IHM paraneo
 *
 * @author CCMT Team
 *
 */
@SuppressWarnings("serial")
public abstract class AbstractPresentationException extends Exception {
}
