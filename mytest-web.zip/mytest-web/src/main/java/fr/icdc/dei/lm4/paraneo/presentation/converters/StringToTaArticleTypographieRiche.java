package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaArticleTypographieRiche;

public class StringToTaArticleTypographieRiche implements Converter<String,TaArticleTypographieRiche> {

	@Override
	public TaArticleTypographieRiche convert(String arg0) {
		TaArticleTypographieRiche object = new TaArticleTypographieRiche();
		object.setArtmin(arg0.split("-")[0]);
		return object;
	}

}
