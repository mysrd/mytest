package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTerritorialiteFicobaLmtay508;

public class TaTerritorialiteFicobaLmtay508ToString implements Converter<TaTerritorialiteFicobaLmtay508,String> {

	@Override
	public String convert(TaTerritorialiteFicobaLmtay508 arg0) {
		return arg0.getCte();
	}

}
