package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLieuDeCompensationLmtay891;

public class StringToTaLieuDeCompensationLmtay891 implements Converter<String,TaLieuDeCompensationLmtay891> {

	@Override
	public TaLieuDeCompensationLmtay891 convert(String arg0) {
		TaLieuDeCompensationLmtay891 object = new TaLieuDeCompensationLmtay891();
		object.setClcmc(arg0.split("-")[0]);
		return object;
	}

}
