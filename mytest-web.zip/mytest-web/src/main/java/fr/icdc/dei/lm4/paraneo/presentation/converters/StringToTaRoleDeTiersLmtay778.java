package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRoleDeTiersLmtay778;

public class StringToTaRoleDeTiersLmtay778 implements Converter<String,TaRoleDeTiersLmtay778> {

	@Override
	public TaRoleDeTiersLmtay778 convert(String arg0) {
		TaRoleDeTiersLmtay778 object = new TaRoleDeTiersLmtay778();
		object.setYcrolt(arg0.split("-")[0]);
		return object;
	}

}
