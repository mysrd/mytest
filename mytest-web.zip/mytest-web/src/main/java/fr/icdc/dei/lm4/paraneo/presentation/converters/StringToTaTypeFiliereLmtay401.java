package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeFiliereLmtay401;

public class StringToTaTypeFiliereLmtay401 implements Converter<String,TaTypeFiliereLmtay401> {

	@Override
	public TaTypeFiliereLmtay401 convert(String arg0) {
		TaTypeFiliereLmtay401 object = new TaTypeFiliereLmtay401();
		object.setCdtyfi(arg0.split("-")[0]);
		return object;
	}



}
