package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeResidentLmtay554;

public class TaCodeResidentLmtay554ToString implements Converter<TaCodeResidentLmtay554,String> {

	@Override
	public String convert(TaCodeResidentLmtay554 arg0) {
		return arg0.getCresac();
	}

}
