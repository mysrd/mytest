package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopSiegeReseau;

public class TaTopSiegeReseauToString implements Converter<TaTopSiegeReseau,String> {

	@Override
	public String convert(TaTopSiegeReseau arg0) {
		return arg0.getTsigre();
	}

}
