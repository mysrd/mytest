package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeRegroupementCategorieClientFed;

public class StringToTaCodeRegroupementCategorieClientFed implements Converter<String,TaCodeRegroupementCategorieClientFed> {

	@Override
	public TaCodeRegroupementCategorieClientFed convert(String arg0) {
		TaCodeRegroupementCategorieClientFed object = new TaCodeRegroupementCategorieClientFed();
		object.setCrccli(arg0.split("-")[0]);
		return object;
		}


}



