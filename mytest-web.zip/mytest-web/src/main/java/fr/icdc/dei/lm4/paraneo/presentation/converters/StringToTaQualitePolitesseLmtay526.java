package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaQualitePolitesseLmtay526;

public class StringToTaQualitePolitesseLmtay526 implements Converter<String,TaQualitePolitesseLmtay526> {

	@Override
	public TaQualitePolitesseLmtay526 convert(String arg0) {
		TaQualitePolitesseLmtay526 object = new TaQualitePolitesseLmtay526();
		object.setCqpol(arg0.split("-")[0]);
		return object;
	}

}

