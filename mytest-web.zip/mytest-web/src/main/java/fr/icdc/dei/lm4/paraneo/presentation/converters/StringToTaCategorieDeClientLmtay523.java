package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieDeClientLmtay523;

public class StringToTaCategorieDeClientLmtay523 implements Converter<String,TaCategorieDeClientLmtay523> {

	@Override
	public TaCategorieDeClientLmtay523 convert(String arg0) {
		TaCategorieDeClientLmtay523 object = new TaCategorieDeClientLmtay523();
		object.setCcclie(arg0.split("-")[0]);
		return object;
	}

}
