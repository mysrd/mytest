package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeResidentLmtay554;

public class StringToTaCodeResidentLmtay554 implements Converter<String,TaCodeResidentLmtay554> {

	@Override
	public TaCodeResidentLmtay554 convert(String arg0) {
		TaCodeResidentLmtay554 object = new TaCodeResidentLmtay554();
		object.setCresac(arg0.split("-")[0]);
		return object;
	}

}