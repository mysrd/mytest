package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleCommercialeLmtay738;

public class StringToTaFamilleCommercialeLmtay738 implements Converter<String,TaFamilleCommercialeLmtay738> {

	@Override
	public TaFamilleCommercialeLmtay738 convert(String arg0) {
		TaFamilleCommercialeLmtay738 object = new TaFamilleCommercialeLmtay738();
		object.setC0fcm(arg0.split("-")[0]);
		return object;
	}



}
