if (window.CDC == null) {
	CDC = {};
}
CDC.relativeImagePath = "../..";

// Initialisation du datatable
$(function() {
	// On actualise les élements du layout qui doivent être recalculés
	resizeHeight();
	$(".date").datepicker({changeMonth: true, changeYear: true,yearRange: "c-84:c+84"});
	mettreEnFormeErreurs();

	function calculCOG(){
		var codeCommune = $( "#com" ).val().trim();
		var codeDepartement = $("#taDepartement").val().split("-")[0].trim();

		var COG;
			COG = codeDepartement+codeCommune;

		$("#cog").val(COG);
	}

	if($(".tableTitle").text().split(":")[1].trim()=="ta_commune_insee"){
		$("#com").blur(calculCOG);
		$("#taDepartement").change(calculCOG);
	}

});

CDC.creerEnregistrementForm = {

		creerEnregistrement : function() {
			validateForm("#creerEnregistrement", {});
			if (isValidForm("#creerEnregistrement", {})) {
				submitForm('#creerEnregistrement');
			}
		},

		majEnregistrement : function() {
			validateForm("#creerEnregistrement", {});
			if (isValidForm("#creerEnregistrement", {})) {
				submitForm('#creerEnregistrement');
		}
}

};

function mettreEnFormeErreurs() {
	$('span.help-inline').has('span').each(function(){
		$(this).closest('div.control-group').addClass('error');
		$(this).siblings('input').attr('data-original-title',$(this).children('span').html());
		$(this).siblings('input').tooltip({html : true});
		$(this).children('span').html('');

	})
}
