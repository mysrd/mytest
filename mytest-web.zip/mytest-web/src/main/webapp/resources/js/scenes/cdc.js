if(window.CDC == null){
	window.CDC = {
		relativeImagePath : ''
	};
}

//nom du cookie qui contient le flag qui permet d'identifier si l'utilisateur est arriv�
//sur la page en cliquant sur le menu ou par un autre moyen
var nomCookieIsClickMenu = "isClickMenu";
//nom du cookie qui contient la liste des datatables dont l'�tat est sauvegard�
var nomCookieGestionnaireDatatables = "gestionnaireDatatables";

//cache le spinner et affiche la page quand elle est charg�e
$( window ).load(function() {
	$('.chargement-icone').css('display','none');
	$('.page-attente-chargement').css('visibility','visible').animate({opacity:1},500);
});


$(function() {


	//fonction qui v�rifie si l'element selectionn� existe
	jQuery.fn.exists = function(){return this.length>0;};

	// Show/hide Bootstrap tooltip on click on the info element

	$('.blueInfo').tooltip({
		trigger : 'manual'
	}).click(function() {
		$(this).tooltip('show');
		$('.tooltip .tooltip-arrow').addClass('tooltip-information-fleche');
		$('.tooltip .tooltip-inner').addClass('tooltip-information');
	}).mouseout(function() {
		$(this).tooltip('hide');
	});

	// Disable click on current and future steps in the breadcrumb
	$('.future, .current').click(function() {
		return false;
	});

	// Open/close the product information
	$('.toggleProduit').click(function() {
		if ($(this).hasClass("open")) {
			$(this).removeClass("open");
		} else {
			$(this).addClass("open");
		}
		$('.laCaisseContent').toggle();
		$('.num_de_stock_title').toggleClass('titleBottomBorder');
		return false;
	});

	// Open/close the ribbon area in the form
	$('.ribbon').each(function(){
		if($(this).hasClass("ribbonLink"))
		{
			if ($(this).hasClass("open")) {
				var messageOpen = $(this).attr("data-message-open");
				if(messageOpen == null || messageOpen.trim() == "")
				{
					$(this).html("Masquer les informations compl&#233;mentaires");
				}
				else
				{
					$(this).html(messageOpen);
				}
			} else {
				var messageClose = $(this).attr("data-message-close");
				if(messageClose == null || messageClose.trim() == "")
				{
					$(this).html("Afficher les informations compl&#233;mentaires");
				}
				else
				{
					$(this).html(messageClose);
				}
			}
		}
	});


	// Open/close the ribbon area in the form
	$('.ribbon').click(function() {
		var selecteurCSS = $(this).attr("data-target");
		if ($(this).hasClass("open")) {
			$(this).removeClass("open");
			if($(this).hasClass("ribbonLink"))
			{
				var messageClose = $(this).attr("data-message-close");
				if(messageClose == null || messageClose.trim() == "")
				{
					$(this).html("Afficher les informations compl&#233;mentaires");
				}
				else
				{
					$(this).html(messageClose);
				}
			}
			$(selecteurCSS).slideUp();
		}
		else
		{
			$(this).addClass("open");
			if($(this).hasClass("ribbonLink"))
			{
				var messageOpen = $(this).attr("data-message-open");
				if(messageOpen == null || messageOpen.trim() == "")
				{
					$(this).html("Masquer les informations compl&#233;mentaires");
				}
				else
				{
					$(this).html(messageOpen);
				}
			}
			$(selecteurCSS).slideDown();
		}
		return false;
	});






	// Jquery UI datepicker
	$(".icondate").datepicker(
			{
				showOn : "button",
				buttonImage : CDC.relativeImagePath + "/resources/img/cdc/calendar_icon.png",
				buttonText : '',
				buttonImageOnly : true,
				maxDate : new Date(),
				dateFormat : 'dd/mm/yy',
				dayNamesMin : [ 'D', 'L', 'M', 'M', 'J', 'V', 'S' ],
				firstDay : 1,
				gotoCurrent : true,
				monthNames : [ 'Janvier', 'F�vrier', 'Mars', 'Avril', 'Mai',
						'Juin', 'Juillet', 'Ao�t', 'Septembre', 'Octobre',
						'Novembre', 'D�cembre' ],
				onClose : function(dateText, inst) {
					$(this).removeClass('ignore');
					this.focus();
					this.blur();
				},
				beforeShow : function(input, inst) {
					$(this).addClass('ignore');
				},
				nextText: "Suivant",
				prevText: "Pr�c�dent"
			});

	//formatage de la date au format JJ/MM/AAAA
	$(".icondate").blur(function(){
		var resu = parseFrenchDate($(this).val());
		if (resu!=null)
			$(this).val($.datepicker.formatDate("dd/mm/yy",resu));
		return;
	});


	var hauteurHeader = $("header").height();
	if($("header").children('div').length == 3)
	{
		var hauteurHeader = $("header").height();
		$(".contenu-service").css("padding-top",hauteurHeader+20);
	}

	afficherOmbreService();

	$(window).scroll(function(){
		afficherOmbreService();
	});

	//
	//Extension du plugin Validate
	//
	extendValidator();



	// Datatable checkbox "cocheTout" --> decoche la case cocheTout
	$('td.checkboxRow input[type="checkbox"]').click(function() {
		// on cherche la ligne parent
		var eTr = $(this).closest("tr");
		// on cherche la case cocheTout parent

		// on remonte au thead parent
		var eCochetout = $(this).closest("table").find(".cocheTout");

		if (!$(this).is(':checked')) {
			$(eCochetout).attr('checked', false);
			$(eTr).removeClass("export_row_selected");
		} else {
			$(eTr).addClass("export_row_selected");
		}
	});

	// Reset button
	$('.reset').click(function() {
		clear_form_elements($(this).parents('form'));
		return false;
	});

	// Show the hidden form
	$('.showHiddenForm').click(function() {
		$(this).toggleClass('disabled');
		$('.hiddenForm').toggle();
		$('html, body').animate({
			scrollTop : $(".hiddenForm").offset().top
		}, 500);
		return false;
	});

	// Inline Input label
	inlineInputLabel = function(input, label) {
		input.value = (input.value == '') ? label : input.value;

		input.onfocus = function(e) {
			input.value = input.value == label ? '' : input.value;
		};
		input.onblur = function(e) {
			input.value = input.value == '' ? label : input.value;
		};
	};

	$('.hiddenForm').hide();

	// Reset form elements function
	function clear_form_elements(ele) {
		$(ele).find(':input').each(function() {
			switch (this.type) {
			case 'password':
			case 'select-multiple':
			case 'select-one':
			case 'text':
			case 'textarea':
				$(this).val('');
				break;
			case 'checkbox':
			case 'radio':
				this.checked = false;
			}
		});
	}

	// Calculate the width of the left column of the site
	var screenWidth = document.body.offsetWidth;
	function setLeftColumnWidth() {
		if (parseInt(screenWidth) > 940) {
			var leftColumnWidth = $('#leftColumn').width();
			$('#mainAreaHolder').css({
				'margin-left' : leftColumnWidth + 'px'
			});
		}
	}


	//récupération du cookie
	var cookieIsClickMenu = $.cdcStorage.get(nomCookieIsClickMenu,'sessionStorage');
	//initialisation du cookie s'il n'existe pas
	if (typeof cookieIsClickMenu === "undefined")
	{
		$.cdcStorage.set( nomCookieIsClickMenu, true,'sessionStorage' );
		resetGestionnaireDatatable();
	}


	//flag qui permet d'identifier si l'utilisateur est arriv� sur la page depuis le menu ou un autre lien
	$("a").click(function() {
		var menuPortletParent = $(this).closest('#menuPortlet').length;
		if(menuPortletParent != 0)
		{
			$.cdcStorage.set( nomCookieIsClickMenu, true,'sessionStorage');
			resetGestionnaireDatatable();
		}
	});

	$(window).resize();

	// calcul de la hauteur du formulaire gris clair pour l'appliquer � la
	// partie droite du formulaire(gris foncé)
	$(window).resize(function() {
		resizeHeight();
	});
	// calcul de la hauteur du formulaire gris clair pour l'appliquer � la
	// partie droite du formulaire(gris foncé)
	$("ul.sidelinks a").click(function() {
		resizeHeight();
	});

	//action au click sur une languette de dépliage/pliage
	$("a.ribbon").click(function() {
		//on redimensionne la partie grise foncée du formulaire
		resizeHeight();
	});

	// calcul de la hauteur du formulaire gris clair pour l'appliquer à la
	// partie droite du formulaire(gris foncé)
	$("tfoot").keyup(function() {
		resizeHeight();
	});

	// calcul de la hauteur du formulaire gris clair pour l'appliquer à la
	// partie droite du formulaire(gris foncé)
	$(".myModal").click(function() {
		resizeHeight();
	});



	// Selectionne la premiere ligne de chaque tableau
	$(document).ready(function() {
		$("table.dataTable tbody").each(function() {
			$(this).find("tr:first").addClass("row_selected");
		});
	});

	// gestion de la touche 'enter' - éxecute la premiére action primaire (gris foncé)
	$(document).keypress(function(e) {
		var tag = e.target.tagName.toLowerCase();
		if (e.which == 13 &&  tag != 'textarea' && tag !='select') {
			if($('ul.sidelinks a.buttonLink:not(.disabled,.light,:hidden)').length > 0)
			{
				$('ul.sidelinks a.buttonLink:not(.disabled,.light,:hidden)')[0].click();
				$.cdcStorage.set( nomCookieIsClickMenu, false,'sessionStorage');
			}
		}
	});

	$('.typeahead').typeahead({
		source : [ 'aaaa', 'aaab', 'aaac' ],
		minLength : 0
	});

	$('.combobox').select2({
		formatNoMatches : function() {return "Pas d'informations";},
		dropdownAutoWidth : true
	});

    $('.combobox').on('select2-blur',function(){
    	$(this).closest(".controls").find("select").focusout();
    });

	$.mask.definitions['h'] = "."; //accepte tous les caract�res
	$(".iban").mask("?hhhh hhhh hhhh hhhh hhhh hhhh hhhhhhhhhh", {
		placeholder : " "
	});

	//Fonction pour centraliser le message "Les champs marqu&#233;s d�une bordure rouge sont obligatoires"
	$(".formFooter").append(function(){
		//On supprime le contenu existant dans la div formFooter
		$(this).children().remove();
		//On ajoute le texte suivant
		return "<span>Les champs marqu&#233;s d&#145;une bordure rouge sont obligatoires.</span>";
	});

	//Ajoute un icone dans le header des tableaux pour d�plier/replier toute les lignes
	$("th.expandRow").html("<span class='openDescr'>Plusd&#39;informations</span>");

	//Fonction pour centraliser le message "Plus d'informations" sur le bouton de d�pliage d'un tableau
	$(".openDescr").text("Plus d'informations");


	// Rendu graphique des messages d'erreur g�n�r�s c�t� serveur
	var errorFields = $("input,select");
	errorFields = errorFields.filter("[data-original-title][data-original-title != '']");
	errorFields.closest('.control-group').addClass("error orange").removeClass("rouge");

	$(errorFields).each(function(){
		var element = $(this);
		if($(this).hasClass("combobox"))
		{
			var elementSelect2Choice = $(element).closest('.controls').find('.select2-choice');
			var errorMessage = $(element).attr('data-original-title');
			$(elementSelect2Choice).attr('data-original-title', errorMessage);
			element = $(elementSelect2Choice);
		}
		$(element).tooltip();
	});


	// calcul de la hauteur du formulaire gris clair pour l'appliquer � la
	// partie droite du formulaire(gris fonc�)
	$(document).ready(function() {
		resizeHeight();
		$("div.datatableFooterOptions").click(function() {
			resizeHeight();
		});
		$(".dataTables_filter").keyup(function() {
			resizeHeight();
		});
		$(".dataTables_length select").click(function() {
			resizeHeight();
		});
	});

	//Initialisation de la modal d'erreur bloquante
	$('#page-erreur-bloquante').modal();

	//Initialisation du carousel
	$('.carousel').carousel();

	//Fonction qui initialise les diff�rents evenements click sur le tableau
	gestionClickTableau();

});

function resizeHeight() {
	$("div.span11 + div.span1 > div.row, div.span6 + div.span2 > div.row").css('height', function() {
		return $(this).parent().prev().height();
	});
	if (isInferieurIE10()) {
		$.placeholder.shim();
	}
}

// fonction de padding a gauche de date
// quand le jour ou le mois sont inferieur a 10 on ajoute un zero a gauche
Number.prototype.padLeft = function(base, chr) {
	var len = (String(base || 10).length - String(this).length) + 1;
	return len > 0 ? new Array(len).join(chr || '0') + this : this;
};


/**
 * Fonction g�n�rique de submission de formulaire depuis un lien
 */
function submitForm(formSelector, url) {
	$(formSelector).attr("action", url);
	$(formSelector).submit();
}

/**
 * Fonction qui submit un formulaire et r�initialise l'�tat des tableaux
 */
function submitFormAvecReinitialisationDuTableau(formSelector, url){
	//Submit du formulaire
	submitForm(formSelector,url);

	// fonction dans cdc.js, qui supprime les �tats sauvegard�s des tableaux.
	resetGestionnaireDatatable();
}

/**
 * Fonction qui affiche la pop-in avec un message "merci de patienter"
 */
function afficherMessageChargement(){
	$("#pop-attente").modal({
		keyboard: false,
		backdrop: 'static'
	});
}

/**
 * Fonction qui cache la pop-in avec un message "merci de patienter"
 */
function cacherMessageChargement(){
	$("#pop-attente").modal('hide');
}

/**
 * Fonction d'export de donn�e du datatable
 */
function exportData(idDatatableSelecteur, resourceURL, estExportDeSelection)
{
	//On vérifie s'il s'agit d'un export de lignes cochées
	estExportDeSelection = estExportDeSelection || false;

	var idFormExportTableSelecteur = "#formExportTable";
    //On supprime l'ancien formulaire
	$(idFormExportTableSelecteur).remove();

    //creation d'un formulaire spécifique pour l'export
	$('body').append($('<form></form>').attr("method", "POST").attr("id","formExportTable").attr("commandName","exportForm"));

    if(estExportDeSelection)
	{
    	clonerChampSelectionneExportTableau(idDatatableSelecteur, idFormExportTableSelecteur,"listExportTable");
	}
    else
	{
    	clonerChampExportTableau(idDatatableSelecteur, idFormExportTableSelecteur,"listExportTable");
	}


    // On submit le formulaire qui contient la liste des donn�es � exporter dans des input hidden
    submitForm(idFormExportTableSelecteur,resourceURL);
}


/**
*Fonction pour cloner toute les lignes d'un tableau
*/
function clonerChampExportTableau(idDatatableSelecteur, idFormExportTableSelecteur, inputNameHiddenFormulaireSelecteur)
{
	//On r�cup�re l'instance du Datatable
	var oDT = $(idDatatableSelecteur).dataTable();

	//On r�cup�re la configutation du Datatable
    var oSettings = oDT.fnSettings();

    var inputNameHiddenTableauSelecteur = "listExportTable";

    //On parcourt la liste des index des lignes visibles. "aiDisplay" contient un tableau des index des lignes visibles.
    for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ )
    {
    	//On r�cup�re une ligne visible gr�ce � son index.
    	var eTr = oDT.fnGetNodes(oSettings.aiDisplay[ i ]);
    	//On clone l'input hidden ayant le name listExportTable
    	var eCloneInput = $(eTr).find('input[name="'+inputNameHiddenTableauSelecteur+'"]').clone();
    	//On ajoute "tf" au name afin qu'il soit charg� dans le RequestBean au moment du submit
    	$(eCloneInput).attr("name",inputNameHiddenFormulaireSelecteur);
    	//On ajoute le champ dans le formulaire cr�� pr�c�demment
    	$(idFormExportTableSelecteur).append(eCloneInput);
    }
}
/**
*Fonction pour cloner les lignes selectionnées d'un tableau
*/
function clonerChampSelectionneExportTableau(idDatatableSelecteur, idFormExportTableSelecteur, inputNameHiddenFormulaireSelecteur)
{
	//On r�cup�re l'instance du Datatable
	var oDT = $(idDatatableSelecteur).dataTable();

	//On r�cup�re la configutation du Datatable
    var oSettings = oDT.fnSettings();

    var inputNameHiddenTableauSelecteur = "listExportTable";

    //On parcourt la liste des index des lignes visibles. "aiDisplay" contient un tableau des index des lignes visibles.
    for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ )
    {
    	//On r�cup�re une ligne visible gr�ce � son index.
    	var eTr = oDT.fnGetNodes(oSettings.aiDisplay[ i ]);

    	if($(eTr).find('.checkboxRow input[type="checkbox"]').is(':checked'))
		{
			//On clone l'input hidden ayant le name listExportTable
	    	var eCloneInput = $(eTr).find('input[name="'+inputNameHiddenTableauSelecteur+'"]').clone();

	    	//On ajoute "tf" au name afin qu'il soit charg� dans le RequestBean au moment du submit
	    	$(eCloneInput).attr("name",inputNameHiddenFormulaireSelecteur);

	    	//On ajoute le champ dans le formulaire cr�� pr�c�demment
	    	$(idFormExportTableSelecteur).append(eCloneInput);
		}
    }
}

/**
 * Fonction d'export de donnée de plusieurs datatables
 * idsDatatablesSelecteurs = ['#idDatatable1','#idDatatable2']
 * attributNames = ['attributName1','attributName2']
 */
function exportDataMultiDatatable(idsDatatablesSelecteurs, resourceURL, estExportDeSelection)
{

	//On v�rifie s'il s'agit d'un export de lignes coch�es
	estExportDeSelection = estExportDeSelection || false;

	var idFormExportTableSelecteur = "#formExportTable";

	//On supprime l'ancien formulaire
	$(idFormExportTableSelecteur).remove();

	//creation d'un formulaire sp�cifique pour l'export
	$('body').append($('<form></form>').attr("method", "POST").attr("id","formExportTable").attr("commandName","exportForm"));

    //On parcourt les selecteurs
	for ( var j=0, iCpt=idsDatatablesSelecteurs.length ; j<iCpt ; j++ )
    {
	    if(estExportDeSelection)
		{
	    	clonerChampSelectionneExportTableau(idsDatatablesSelecteurs[j], idFormExportTableSelecteur,"listExportTable"+j);
		}
	    else
		{
	    	clonerChampExportTableau(idsDatatablesSelecteurs[j], idFormExportTableSelecteur,"listExportTable"+j);
		}
    }
    // On submit le formulaire qui contient la liste des donn�es � exporter dans des input hidden
    submitForm(idFormExportTableSelecteur,resourceURL);
}

function capitaliseFirstLetter(string)
{
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function getDatatableCheckboxesSerialize(idDatatableSelecteur)
{
	//On récupére l'instance du Datatable
	var oDT = $(idDatatableSelecteur).dataTable();

	//On récupére la configutation du Datatable
	var oSettings = oDT.fnSettings();

	//variable qui contientra les paramtres serializ�s
    var attributsSerialize = [];

	//On vérifie l'existence du Datatable sinon on retourne un chaine vide
	if(oSettings!= null)
	{
	    //On parcourt la liste des index des lignes visibles. "aiDisplay" contient un tableau des index des lignes visibles.
	    for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ )
	    {
	    	//On récupére une ligne visible grace à son index.
	    	var eTr = oDT.fnGetNodes(oSettings.aiDisplay[ i ]);
	    	//On récupére la checkbox coch�e et non désactivée
	    	var eInputCheckbox = $('input[type="checkbox"]:checked', eTr).not(":disabled");

	    	//On vérifie qu'il y a un element
	    	if($(eInputCheckbox).length > 0)
	    	{
	    		//On concatene l'attribut et sa valeur.
	    		attributsSerialize.push($(eInputCheckbox));
	    	}
	    }
	}
	return attributsSerialize;
}

/**
 * Fonction qui s�rialize les checkboxes d�coch�es et d�sactiv�es d'un datatable
 */
function getDatatableCheckboxesUncheckedSerialize(idDatatableSelecteur)
{
	//On r�cup�re l'instance du Datatable
	var oDT = $(idDatatableSelecteur).dataTable();

	//On r�cup�re la configutation du Datatable
	var oSettings = oDT.fnSettings();

	//variable qui contientra les paramtres serializ�s
    var attributsSerialize = [];

	//On v�rifie l'existence du Datatable sinon on retourne un chaine vide
	if(oSettings!= null)
	{
	    //On parcourt la liste des index des lignes visibles. "aiDisplay" contient un tableau des index des lignes visibles.
	    for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ )
	    {
	    	//On r�cup�re une ligne visible gr�ce � son index.
	    	var eTr = oDT.fnGetNodes(oSettings.aiDisplay[ i ]);
	    	//On r�cup�re la checkbox coch�e et non d�sactiv�e
	    	var eInputCheckbox = $('input[type="checkbox"]', eTr).not(":disabled").not(":checked");

	    	//On v�rifie qu'il y a un element
	    	if($(eInputCheckbox).length > 0)
	    	{
	    		//On concatene l'attribut et sa valeur.
	    		attributsSerialize.push($(eInputCheckbox));
	    	}
	    }
	}
	return attributsSerialize;
}

var genericValidateOptions = {
		errorPlacement : function(error, element) {
			/* Ajout du message d'erreur dans la tooltip */
			$(element).attr('data-original-title', error.text());
		},
		highlight : function(element, errorClass, validClass) {
			/* Ajout de la class error */
			$(element).closest('.control-group').addClass(errorClass);
			/* Activation de la tooltip */
			$(element).tooltip();
		},
		unhighlight : function(element, errorClass, validClass) {
			/* Retrait de la class error */
			$(element).closest('.control-group').removeClass(errorClass);
			/*
			 * Retrait du message d'erreur de la tooltip. Par d�fault, s'il n'y
			 * a pas de message elle s'efface.
			 */
			$(element).attr('data-original-title', "");
		},
		errorClass : "error",
		validClass : "success",
		errorElement : "label"
	};

/**
 * Fonction g�n�rique de validation de formulaire
 */
function validateForm(formSelector, options) {
	var validateOptions = $.extend({}, genericValidateOptions, options);
	return $(formSelector).validate(validateOptions);
}

function isValidForm(formSelector, options){
	var validateOptions = $.extend({}, genericValidateOptions, options);
	return $(formSelector).valid(validateOptions);
}

/**
 * Parse une date au format jj/MM/yyyy et retourne l'objet Date
 */
function parseFrenchDate(stringDate) {
	var regex_jj_mm_aaaa_et_jj_mm_aa = "^(0[1-9]|[12][0-9]|3[01])(/?)(0[1-9]|1[0-2])(/?)(\\d{4}|\\d{2})$";

	var stringDate = $.trim(stringDate);

	var resu = stringDate.match(regex_jj_mm_aaaa_et_jj_mm_aa);

	if (resu)
	{
		var jour=resu[1];
		var mois=resu[3];
		var annee = resu[5];

		//horrible code pour consid�rer qu'une date au format JJ/MM/AA est �gale � JJ/MM/20AA
		if(annee.length==2)
			annee="20"+annee;
		//Instanciation d'un objet date. Attention, le parametre mois accepte les valeurs de 0 � 11.
		date=new Date(annee,mois-1, jour);

		//On verifie que la date instanci�e est identique � la date saisie.
		//Le fonctionnement natif de l'objet Date fait que si l'on saisie 31/02/2012 alors la date instanci�e sera le 02/03/2012.
		//Donc si la date saisie est diff�rente de l'objet Date alors la date est fausse.
		if(date.getDate()!= jour)
			return null;
		else
			return date;
	}
	return null;
}

/**
 * Fonction qui personnalise les fonctionnalit�s du plugin validation
 */

function extendValidator(){
	// Personnalisation des messages d'erreur pour la validation
	$.extend($.validator.messages,
		{
			required : 'La saisie de ce champ est requise.',
			remote : 'needs to get fixed',
			email : 'Saisir un courriel valide.',
			url : 'L\'url saisie est invalide.',
			date : 'La date saisie est invalide.',
			dateISO : 'Le format de la date saisie est invalide (ISO)',
			number : 'La valeur de ce champ n\'est pas un nombre valide.',
			digits : 'Ce champ ne doit comporter que des chiffres.',
			creditcard : 'is not a valid credit card number',
			equalTo : 'is not the same value again',
			accept : 'is not a value with a valid extension',
			maxlength : jQuery.validator
					.format('Ce champ doit �tre compos� de {0} caract�res maximum.'),
			minlength : jQuery.validator
					.format('Ce champ doit comporter au moins {0} caract�res.'),
			rangelength : jQuery.validator
					.format('Ce champ doit comporter entre {0} et {1} caract�res.'),
			range : jQuery.validator
					.format('La valeur de ce champ doit �tre comprise entre {0} et {1}'),
			max : jQuery.validator
					.format('La valeur de ce champ doit �tre inf�rieure ou �gale � {0}'),
			min : jQuery.validator
					.format('La valeur de ce champ doit �tre sup�rieures � {0}')
		}
	);

	//Modification de la r�gle required, ajout d'un trim sur la value
	$.validator.addMethod("required",  function(value, element, param) {
		// check if dependency is met
		if ( !this.depend(param, element) ) {
			return "dependency-mismatch";
		}
		if ( element.nodeName.toLowerCase() === "select" ) {
			// could be an array for select-multiple or a string, both are fine this way
			var val = $.trim($(element).val());
			return val && val.length > 0;
		}
		if ( this.checkable(element) ) {
			return this.getLength(value, element) > 0;
		}
		return $.trim(value).length > 0;
	});

	// Ajout d'une r�gle 'date fran�aise' au format 'dd/MM/yyyy'
	$.validator.addMethod("frenchdate", function(value, element) {
		if(value!=null&&value!="")
			return (parseFrenchDate(value)!=null);
		return true;
	}, 'La date saisie est invalide.');

	//Ajout d'une r�gle 'format montant' au format '99999999999,99'
	$.validator.addMethod("montantParse", function (value, element) {
				var MONTANT_REGEX = /^[0-9]{0,12}([,.][0-9]{2})?$/;
				if (value != null) {
					value = $.trim(value);
					if (value.match(MONTANT_REGEX)) {
						return true;
					}
				}
				return null;
		    },
			message="Champ num&eacute;rique de 15 caract&egrave;res maximum, dont 2 caract&egrave;res apr&egrave;s la virgule."
		);


	// Modification du plugin validate afin d'ajouter le type de r�gle en echec dans la method highlight
	$.extend($.validator.prototype,
		{
			formatAndAdd: function( element, rule ) {
				var message = this.defaultMessage( element, rule.method ),
					theregex = /\$?\{(\d+)\}/g;
				if ( typeof message === "function" ) {
					message = message.call(this, rule.parameters, element);
				} else if (theregex.test(message)) {
					message = $.validator.format(message.replace(theregex, '{$1}'), rule.parameters);
				}
				this.errorList.push({
					message: message,
					element: element,
					//ajout du type de r�gle en erreur (required,minlength,...)
					method: rule.method
				});

				this.errorMap[element.name] = message;
				this.submitted[element.name] = message;
			},
			defaultShowErrors: function() {
				var i, elements;
				for ( i = 0; this.errorList[i]; i++ ) {
					var error = this.errorList[i];
					if ( this.settings.highlight ) {
						//passage du type de r�gle � la fonction highlight
						this.settings.highlight.call( this, error.element, this.settings.errorClass, this.settings.validClass, error.method );
					}
					this.showLabel( error.element, error.message );
				}
				if( this.errorList.length ) {
					this.toShow = this.toShow.add( this.containers );
				}
				if (this.settings.success) {
					for ( i = 0; this.successList[i]; i++ ) {
						this.showLabel( this.successList[i] );
					}
				}
				if (this.settings.unhighlight) {
					for ( i = 0, elements = this.validElements(); elements[i]; i++ ) {
						this.settings.unhighlight.call( this, elements[i], this.settings.errorClass, this.settings.validClass );
					}
				}
				this.toHide = this.toHide.not( this.toShow );
				this.hideErrors();
				this.addWrapper( this.toShow ).show();
			}
		}
	);
	// Modification du plugin validate de personnaliser les options par d�fauts
	$.extend($.validator.defaults,
		{
			ignore : ":hidden, .select2-input, .ignore",
			onkeyup: false,
			onfocusout: function(element, event) {
				//Active le controle lorsqu'on quitte un champ
				if($(element).not(this.settings.ignore).length>0)
				{
					if ( !this.checkable(element)) {
						this.element(element);
					}
				}
			},
			errorPlacement : function(error, element) {
				/* Ajout du message d'erreur dans la tooltip */
				if($(element).hasClass("combobox"))
				{
					var elementSelect2Choice = $(element).closest('.controls').find('.select2-choice');
					$(elementSelect2Choice).attr('data-original-title', error.text());
				}
				else
				{
					$(element).attr('data-original-title', error.text());
				}
			},invalidHandler: function(event, validator) {
				var errors = validator.numberOfInvalids();
				if (errors) {
					var message = 'Une ou plusieurs anomalies sont pr�sentes. Veuillez les corriger avant de continuer.';
					afficherMessageAvertissement("jaune",message);
				}
			},
			highlight : function(element, errorClass, validClass, method) {

				//On d�termine l'element impact�
				var elementImpacte;
				if($(element).hasClass("combobox"))
				{
					elementImpacte = $(element).closest('.controls').find('.select2-choice');
				}
				else
				{
					elementImpacte = element;
				}

				//On r�cup�re la div control-group parent
				var controlGroupElement = $(element).closest('.control-group');

				// On ajoute la classe CSS error
				$(controlGroupElement).addClass(errorClass);

				//Si l'erreur est de type "required" on ajoute la classe rouge sinon on ajoute la classe orange
				if (method.indexOf("required") !== -1) {
					$(controlGroupElement).removeClass("orange");
					$(controlGroupElement).addClass("rouge");
			    } else {
			    	$(controlGroupElement).removeClass("rouge");
					$(controlGroupElement).addClass("orange");
			    }

				//On active la tooltip sur l'element impact�
				$(elementImpacte).tooltip();

			},
			unhighlight : function(element, errorClass, validClass) {
				/*
				 * Retrait du message d'erreur de la tooltip. Par d�fault, s'il n'y
				 * a pas de message elle s'efface.
				 */
				var elementImpacte;

				if($(element).hasClass("combobox"))
				{
					elementImpacte = $(element).closest('.controls').find('.select2-choice');
				}
				else
				{
					elementImpacte = element;
				}

				$(elementImpacte).tooltip('destroy');

				$(elementImpacte).attr('data-original-title', "");

				var controlGroupElement = $(elementImpacte).closest('.control-group');
				$(controlGroupElement).removeClass(errorClass);

				if($(controlGroupElement).hasClass("mandatory"))
				{
					$(controlGroupElement).removeClass("orange");
					$(controlGroupElement).addClass("rouge");
				}
			},
			errorClass : "error",
			validClass : "success",
			errorElement : "label"
		}
	);
}


/*
 * Fonction qui affiche ou non l'ombre au dessus de la zone service en fonction de la position du scroll
 */
function afficherOmbreService()
{
	var scrollTop = $(document).scrollTop();
	if(scrollTop == 0)
	{
		$('.ombreService').hide();
	}
	else
	{
		$('.ombreService').show();
	}
};

/**
 * Nettoie une chaine de caract�re (utilis� pour les infos-bulles du datatable)
 */
function cleanString(chaine){

	var reg = new RegExp("<[^br]\w*(.*?)>","g");
	chaine = chaine.replace(/<[^br]\w*(.*?)>/g,'');
	//enl�ve les espaces en d�but et fin de chaine
	chaine = $.trim(chaine);
	//enl�ve les tabulations
	chaine = chaine.replace(/\t+/g, '');
	//enl�ve les sauts de lignes
	chaine = chaine.replace(/\n/g, '');
	//remplace les espaces ins�cables par un saut de ligne (� cause de consultationPortlet)
	//chaine = chaine.replace(/(\W)*(&nbsp;)(\W)*/g, '\n');
	//remplace les balises <br> par un saut de ligne
	chaine = chaine.replace(/(\W)*(<br>|<BR>)(\W)*/g, '\n');
	//decode les caract�res encod�s (&amp; --> &)
	chaine = $('<div />').html(chaine).text();

	return chaine;
}

/**
 *Fonction qui replace le contenu des filtres d'un tableau apr�s rechargement de la page
 */
function restoreFilters(tableSelector, oData)
{
    $(tableSelector+' tfoot input').each(function(index) {
    	var myElementTD = $(this).parent();
    	var allElementTD = $(this).parent().parent().children();
    	var index = $(allElementTD).index(myElementTD);
    	var colonne = oData.aoSearchCols[index];
    	if (colonne != null) {
    		$(this).val(colonne.sSearch);
    	}
    });
}

/**
 *Fonction qui determine s'il s'agit d'un navigateur IE7
 */
function isIE7()
{
	if($.browser.msie && parseInt($.browser.version, 10) == 7) {
		return true;
	}
	else
	{
		return false;
	}
}

/**
 *Fonction qui determine s'il s'agit d'un navigateur <IE10
 */
function isInferieurIE10()
{
	if($.browser.msie && parseInt($.browser.version) < 10) {
		return true;
	}
	else
	{
		return false;
	}
}

/**
 *Fonction qui construit la ligne � d�plier
 */
function afficherLigneDeplie(myDatatable, ligne)
{
	// on prepare les lignes a afficher dans le detail
	var aData = myDatatable.fnGetData(ligne);
	var oSettings = myDatatable.fnSettings();
	var detailRowRender = '<div class="row innerDetails form-horizontal"><div class="span8">';

	$(aData).each(
		function(index, value) {
			if (oSettings.aoColumns[index].bVisible === false) {
				var columnName = oSettings.aoColumns[index].sTitle;
				var codeColonne = oSettings.aoColumns[index].sTitle;
				var temp = columnName.substring(columnName.indexOf("<span"));
				var regexp = /<span name='([\S]+)'><\/span>/;
				codeColonne = temp.match(regexp)[1];

				// Conversion des éventuelles zones numériques en chaine pour éviter le plantage sur indexOf
				value = ''+value;
				// Le cas o� le champs � afficher est un champ de saisie ou une liste d�roulante
				if(value.indexOf("<input") >=0 || value.indexOf("<select") >=0){
					var mandatory = '';
					if(value.indexOf("require") >=0){
						mandatory = ' mandatory rouge';
					}
					detailRowRender = detailRowRender
					+ '<div class="row"><div class="span8 control-group'+mandatory+'"><label class="control-label">'
					+ columnName
					+ ' :</label><div class="controls">'
					+ value
					+ '</div></div></div>';
				} else {
					var values = value.split("<br>");
					if(columnName.trim().length != 00)
					{
						detailRowRender = detailRowRender
						+ '<div class="row"><div class="span8 control-group"><label class="control-label" name="'+codeColonne+'">'
						+ columnName
						+ ' :</label><div class="controls"><p title="'
						+ value.trim()
						+'">'
						+ value
						+ '</p></div></div></div>';
					}
					else if(columnName.trim().length == 0)
					{
						var concatenationValue = "";
						$.each(values,function(index,value){
							concatenationValue = concatenationValue
							+ '<p class="infoComplement" title="'
							+ value.trim()
							+ '">'
							+ value
							+ '</p>';
						});
						detailRowRender = detailRowRender
						+ '<div class="row"><div class="span8 control-group">'
						+ concatenationValue
						+ '</div></div>';
					}
				}
			}
		}
	);
	detailRowRender = detailRowRender + '</div></div>';
	//var nDetailsRow = myDatatable.fnOpen(ligne, detailRowRender, "info_row");
	var nDetailsRow = myDatatable.api().row(ligne).child(detailRowRender, "info_row");
	myDatatable.api().row(ligne).child.show();
	//ligne.rowindex
	//alert(myDatatable.api().row(ligne.rowindex).child.isShown());
//	$('div.innerDetails', nDetailsRow).show(0,
//		function() {
//			resizeHeight();
//		}
//	);
	return this;
}


/**
 * Fonction g�n�rique de cr�ation de datatable
 */
function createDatatable(tableSelector, options, otherOptions) {

	if($(tableSelector).length > 0)
	{
		if($.browser.msie && parseInt($.browser.version) == 9)
		{
			//PATCH IE9 - GHOST COLUMNS LARGE TABLE
			var expr = new RegExp('>[ \t\r\n\v\f]*<', 'g');
			var tbhtml = $(tableSelector).html();
			$(tableSelector).html(tbhtml.replace(expr, '><'));
		}




		//extension de la fonction de tri au date jj/mm/aaaa et nombre monetaire
		jQuery.extend( jQuery.fn.dataTableExt.oSort, {
		    "date-jjmmaaaa-pre": function ( a ) {
		        var jjmmaaaa = a.split('/');
		        return (jjmmaaaa[2] + jjmmaaaa[1] + jjmmaaaa[0]) * 1;
		    },

		    "date-jjmmaaaa-asc": function ( a, b ) {
		        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
		    },

		    "date-jjmmaaaa-desc": function ( a, b ) {
		        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
		    },
		    "nombre-monetaire-pre": function ( a ) {
		    	// On enl�ve les espaces
		    	var c = a.replace(/\s+/g, "");
		    	// On enl�ve les espaces ins�cables
		    	var d = c.replace(/(&nbsp;)/g, "");
		    	// On enl�ve toute chaine de caract�res (ex:EUR)
		    	var b = d.replace(/[A-Za-z]/g, "");
		    	// on remplace les "," par des "." pour les float
		    	var e = b.replace(',','.');

		    	return parseFloat( e );
		    },
		    "nombre-monetaire-asc": function ( a, b ) {
		    	if(isNaN(a) && isNaN(b))
		    		return 0;
		    	else if(isNaN(a))
	    			return -1;
	    		else if(isNaN(b))
	    			return 1;
	    		else
		    		return ((a < b) ? -1 : ((a > b) ? 1 : 0));

		    },

		    "nombre-monetaire-desc": function ( a, b ) {
		    	if(isNaN(a) && isNaN(b))
		    		return 0;
		    	else if(isNaN(a))
	    			return 1;
	    		else if(isNaN(b))
	    			return -1;
	    		else
	    			return ((a < b) ? 1 : ((a > b) ? -1 : 0));

		    }
		} );

		$.fn.dataTableExt.ofnSearch['nombre-monetaire'] = function ( sData ) {
			// On enl�ve les espaces
	    	var c = sData.replace(/\s+/g, "");
	    	// On enl�ve les espaces ins�cables
	    	var d = c.replace(/(&nbsp;)/g, "");

			return d;
		};

		// R�cup�re l'option qui indique si le tableau est un tableau limite
		var isTableauLimite = otherOptions['isTableauLimite'];

		// Positionnement du datatable
		var sDomOption = "<'datatableHeaderOptions'l f>" + "t"
				+ "<'datatableFooterOptions'i p>";

		//nom de la cl� qui stocke l'�tat du tableau en sessionStorage
		var nomCookieStateSave = 'DataTables_'+tableSelector.substring(1, tableSelector.length)+'_StateSave';

		//nom du cookie qui indique si l'utilisateur a cliqu� sur le bouton d�plier tout du tableau
		var nomCookieDeplieTout = 'DataTables_'+tableSelector.substring(1, tableSelector.length)+'_DeplieTout';


		// Configuration de base du datatable
		var genericDatatableOptions = {
			bJQueryUI : false,
			bAutoWidth : false,
			bStateSave : true,
			fnStateSave: function (oSettings, oData) {
				//On met � jour l'�tat du tableau dans le sessionStorage
				$.cdcStorage.set(nomCookieStateSave, JSON.stringify(oData),'sessionStorage');
				$.cdcStorage.set( nomCookieIsClickMenu, false,'sessionStorage' );

				//On r�cup�re le gestionnaire de datatable
				var gestionnaireDatatables = $.cdcStorage.get( nomCookieGestionnaireDatatables,'sessionStorage' );

				//On v�rifie si le cookie pour ce datatable est r�f�renc� dans le gestionnaire
				if(typeof gestionnaireDatatables === 'undefined' || !gestionnaireDatatables.hasOwnProperty(nomCookieStateSave))
				{
					//on cr�� une nouvelle entr�e pour ce cookie
					var jsonNomCookieStateSave = {};
					jsonNomCookieStateSave[nomCookieStateSave] = "";

					//on met � jour le gestionnaire avec la nouvelle valeur
					$.cdcStorage.set( nomCookieGestionnaireDatatables,$.extend(gestionnaireDatatables,jsonNomCookieStateSave),'sessionStorage' );
				}
			},
	        fnStateLoad: function (oSettings) {
	    		var gestionnaireDatatables = $.cdcStorage.get( nomCookieGestionnaireDatatables,'sessionStorage' );
	    		if(typeof gestionnaireDatatables !== 'undefined'  && gestionnaireDatatables.hasOwnProperty(nomCookieStateSave))
				{
	            	var valeurCookieIsClickMenu = $.cdcStorage.get( nomCookieIsClickMenu,'sessionStorage' );
	        		var isClickMenu = JSON.parse(valeurCookieIsClickMenu);
		    		if(!isClickMenu)
					{
		        		var dataSauvegarde = $.cdcStorage.get(nomCookieStateSave,'sessionStorage');
			        	if(dataSauvegarde != "" && dataSauvegarde != null)
			        	{
			        		var oData =  JSON.parse( dataSauvegarde );
			        		restoreFilters(tableSelector,oData);
			        		return oData;
			        	}
					}
				}
	        },
	        oSearch: {
	        	bSmart: true,
	        	bRegex: false
	        },
			sPaginationType : "full_numbers",
			aLengthMenu: [[5, 10, 25, 50, 100, -1],[5, 10, 25, 50, 100, "tous"]],
			iDisplayLength: 10,
			sDom : sDomOption,
			oLanguage : {
				sSearch : "_INPUT_",
				sLengthMenu : "Nombre de lignes par page : _MENU_",
				sZeroRecords : "Pas d&#39;information",
	//			sInfo :"_START_ &#224; _END_ / _TOTAL_ r&#233;sultat(s)", //d�fini dans le fnPreDrawCallback
				sInfoEmpty : " ",
				sInfoFiltered : " ",
				oPaginate : {
					sNext : "",
					sFirst : "",
					sLast : "",
					sPrevious : ""
				},
				sInfoThousands:" "
			},
			fnRowCallback : function(nRow, aData, iDisplayIndex) {
				// Code pour afficher le texte des cellules tronqu�es dans untooltip.
				// On ajoute un attribut title sur le TD, valoris� avec le texte du TD.
				// Le navigateur interprete l'attribut title et g�n�re un tooltip au
				// survol ou au clique. (fonction de base des navigateurs)
				var cellules = $(nRow).children();
				var nbCellule = $(cellules).length;
				for ( var cptDatatable = 0, i = nbCellule; cptDatatable < i; cptDatatable++) {
					var elementTd = $(cellules.get(cptDatatable));
					var contenu = $(elementTd).html();
					//$(elementTd).html($.trim(contenu));
					var title = cleanString(contenu);
					if (!$(elementTd).hasClass("checkboxRow") && !$(elementTd).hasClass("dtSettingsItem") && title != "" ) {
						$(elementTd).attr("title", title);
					}
				}
			},
			fnHeaderCallback : function(nHead, aData, iStart, iEnd, aiDisplay) {
				// Code pour afficher le texte des cellules tronqu�es dans un
				// tooltip.
				// On ajoute un attribut title sur le TH, valoris� avec le texte du
				// TH.
				// Le navigateur interprete l'attribut title et g�n�re un tooltip au
				// survol ou au clique. (fonction de base des navigateurs)
				var cellules = $(nHead).children($("th"));
				var nbCellule = $(cellules).length;
				for ( var cptDatatable = 0, i = nbCellule; cptDatatable < i; cptDatatable++) {
					var elementTd = $(cellules.get(cptDatatable));
					var contenu = $(elementTd).html();
					//$(elementTd).html($.trim(contenu));
					var title = cleanString(contenu);
					if (!$(elementTd).hasClass("checkboxRow") && !$(elementTd).hasClass("dtSettingsItem") && title != "" ) {
						$(elementTd).attr("title", title);
					}
				}
			},
			fnDrawCallback : function(oSettings) {
				var myDatatable = this;
				// on adapte la taille du message de tableau vide pour qu'il ne prenne pas en compte la colonne d'options
				if (oSettings.fnRecordsDisplay() == 0) {
					var tdToRedraw = $('.' + oSettings.oClasses.sRowEmpty,tableSelector), tdColspan = tdToRedraw.attr('colspan');
					tdToRedraw.attr('colspan', (tdColspan > 1 ? tdColspan - 1: tdColspan));
				}

				//on d�plie les lignes si le bouton de d�pliage de toutes les lignes est activ�
				var flagDeplieTout = $.cdcStorage.get(nomCookieDeplieTout,'sessionStorage');
				if(flagDeplieTout == true)
				{
					if($(tableSelector+' th.expandRow .openDescr').hasClass('minus'))
					{
						// on ouvre toutes les lignes ferm�es
						$(tableSelector).find("tr td").each(
						function() {
							// on prepare les lignes a afficher dans le detail
							afficherLigneDeplie(myDatatable, $(this).closest("tr")[0]);
							if(!($(this).find(".openDescr").hasClass("minus")))
							{
								$(this).find(".openDescr").addClass("minus");
							}
						});
					}
					else
					{
						// on ferme toutes les lignes ouvertes
						$(tableSelector).find("tr td").each(
						function() {
							myDatatable.fnClose($(this).closest("tr")[0]);
							if(($(this).find(".openDescr").hasClass("minus")))
							{
								$(this).find(".openDescr").removeClass("minus");
							}
						});
					}
				}
			},
			fnPreDrawCallback : function(oSettings) {
				//On r�cup�re le nombre de ligne � afficher
				var nbLigneAffichee = oSettings.fnRecordsDisplay();

				if (nbLigneAffichee == 1) {
					//s'il n'y a qu'une ligne, on �crit r�sultat sans "S"
					oSettings.oLanguage.sInfo = "_START_ &#224; _END_ / _TOTAL_ r&#233;sultat";
				}
				else if(nbLigneAffichee > 1)
				{
					//s'il y a plus qu'une ligne, on �crit r�sultat avec un "S"
					oSettings.oLanguage.sInfo = "_START_ &#224; _END_ / _TOTAL_ r&#233;sultats";
				}

				//On r�cup�re le nombre de r�sultat
				var nbResultatTotal = oSettings.fnRecordsTotal();

				//S'il n'y a pas de r�sultat ou qu'il s'agit d'un tableau limit�, on cache les filtres et les elements de pagination
				if(nbResultatTotal == 0 ||isTableauLimite)
				{
					//On d�finit le selecteur CSS
					var selectorHeader = tableSelector+"_wrapper .datatableHeaderOptions,"+tableSelector+"_wrapper .datatableFooterOptions,"+tableSelector+"_wrapper tfoot";
					//On passe la propri�t� display � "none"
					$(selectorHeader).css("display","none");
				}
			}
		};

		// Ajout des autres options � la conf de base du datatable
		var datatableOptions = $.extend({}, genericDatatableOptions, options);

		// Instanciation du datatable avec les options
		var myDatatable = $(tableSelector).dataTable(datatableOptions);

		// fonction open
		$(tableSelector).delegate('span.openDescr', 'click',
			function() {
				var nTh = $(this).parents('th')[0];
				var nTr = $(this).parents('tr')[0];
				if(typeof nTh == 'undefined')
				{
					$.cdcStorage.set(nomCookieDeplieTout, false,'sessionStorage');
					if (myDatatable.fnIsOpen(nTr))
					{
						$(this).removeClass("minus");
						myDatatable.fnClose(nTr);
					}
					else
					{
						// on ajoute la classe minus pour mettre l'icone deplier
						$(this).addClass("minus");
						// on prepare les lignes a afficher dans le detail
						afficherLigneDeplie(myDatatable, nTr);

					}
				}
				else
				{
					$.cdcStorage.set(nomCookieDeplieTout, true,'sessionStorage');
					if ($(nTh).hasClass("minus"))
					{
						//On retire la classe minus au header du tableau afin de passer l'icone du - au +
						$(nTh).removeClass("minus");
						// on ferme toutes les lignes ouvertes
						$(tableSelector).find("tr").each(
						function() {
							myDatatable.fnClose(this);
							$(this).find(".openDescr").removeClass("minus");
						});
					}
					else
					{
						//On ajoute la classe minus au header du tableau afin de passer l'icone du + au -
						$(nTh).addClass("minus");

						// on ouvre toutes les lignes ferm�es
						$(tableSelector).find("tr").each(
						function() {
							if(this.innerText != null && this.innerText != "") {
								// on prepare les lignes a afficher dans le detail
								afficherLigneDeplie(myDatatable, this);

								$(this).find(".openDescr").addClass("minus");
							}
						});
					}
				}
				resizeHeight();
			}
		);

		$('.cocheTout', tableSelector).click(function(e) {
			var nodes = myDatatable.fnGetNodes();

			if ($(this).is(':checked')) {
				// coche toutes les lignes de la table, meme les non affichees
				$('input[type="checkbox"]:not(:disabled)', nodes).attr('checked', 'checked');
				$(nodes).addClass("export_row_selected");
			} else {
				$('input[type="checkbox"]:not(:disabled)', nodes).removeAttr('checked');
				$(nodes).removeClass("export_row_selected");
			}
		});

		// instanciation des filtres de colonnes pour le datatable
		var filterInputSelector = tableSelector + " tfoot input";
		$(filterInputSelector).keyup(function() {
			var myElementTD = $(this).parent();
			var allElementTD = $(this).parent().parent().children();
			myDatatable.fnFilter(this.value, $(allElementTD).index(myElementTD));
			resizeHeight();
		});


		// Int�gration du mot "filtre" dans l'input. Besoin de refaire appel au
		// Javascript placeholders.
		$(".dataTables_filter input").attr("placeholder", "Filtre").addClass("input-medium");
		$("tfoot tr td input").attr("placeholder", "Filtre");

		return myDatatable;
	}
	return null;
}

/**
 * Fonction qui efface la liste des datatables contenu dans le cookie gestionnaire datatable.
 * Permet de r�initialiser l'�tat des tableaux.
 */
function resetGestionnaireDatatable()
{
	$.cdcStorage.set( nomCookieGestionnaireDatatables, {},'sessionStorage' );
}

function gestionClickTableau(){
	// gestion du double clique dans le tableau - execution de la 1er action du menu
	$("body").on('dblclick','.table tbody tr td:not(.checkboxRow,.expandRow)',function(e){
		var etr = $(this).parent();
		var edropdowntoggleinactive = $(etr).find(".dropdown-toggle.disabled");
		var efirstaction = $(etr).find("ul a:first");
		if (edropdowntoggleinactive.length == 0) {
			$(etr).find(".dropdown-toggle").dropdown('toggle');
			$(efirstaction)[0].click();
		}
	});

	// gestion du simple clique dans le tableau - ouverture/fermeture du menu d'actions
	$("body").on('click','.table tbody tr td:not(.checkboxRow,.expandRow,.dtSettingsItem)',function(e){
		e.stopPropagation();
		var etr = $(this).parent();
		var edropdowntoggle = $(etr).find(".dropdown-toggle");
		//Si la roue dent�e n'est pas d�sactiv�e alors on affiche le menu
		if(!$(edropdowntoggle).hasClass("disabled"))
		{
		$(edropdowntoggle).dropdown('toggle');
		}
		else
		{
			$(etr).closest("tbody").find(".dropdown.open .dropdown-toggle").dropdown('toggle');
		}
	});


	// gestion du simple clique dans le tableau - selection de la ligne
	$("body").on('click','.table tbody tr td:not(.checkboxRow)',function(){
		var etr = $(this).parent();
		// on enl�ve la classe row_selected de toute les lignes .
		$(this).closest("tbody").find("tr").removeClass("row_selected");
		// on ajoute la classe row_selected sur la ligne cliqu�e .
		$(etr).addClass("row_selected");
	});


}


/**
 * Appel ajax pour charger des donn�es de fa�on Asynchrone.
 *
 * @param url action � appeler
 * @param parameters Parametres � passer � l'action, en JSON
 * @param customCallBack [Optionnel] Callback de l'appel. Si aucun callback n'est donn�,
 * les data en retour seront positionn�es dans la page en fonction de l'ID des champs.
 */
function ajaxLoading(url, parameters, customCallBack) {
	parameters = parameters || {};

	// Options � ne pas modifier
	var options = {
		url: url,
		type: "POST",
		data: parameters
	};

	// CallBack avec gestion d'erreur
	var callBack = function(response){
		ajaxLoadingCallback(response, customCallBack);
	};

	$.ajax(options).done(callBack);
}

/**
 * Fonction appel�e en retour d'un appel AJAX (que ce soit par javascript pur ou via une applet)
 * @param response r�ponse AJAX
 * @param customCallBack [Optionnel] Callback de l'appel. Si aucun callback n'est donn�,
 * les data en retour seront positionn�es dans la page en fonction de l'ID des champs.
 */
function ajaxLoadingCallback(response, customCallBack) {

	// Bouton d'action de la page � d�sactiver
	var actionButton = $('ul.sidelinks a.buttonLink:not(.disabled,.light,:hidden)');
	actionButton.addClass('disabled');

	// Callback par d�faut, positionne les valeurs dans la page
	// En fonction des cl�s / Valeurs pr�sents dans data
	var noErrorStandardCallback = function(resultat){
		if (resultat) {
			for (fieldResponse in resultat){
				var field = $("#"+fieldResponse);
				var fieldValue = resultat[fieldResponse] || "";
				if (field.is("input")){
					field.val(fieldValue);
				} else{
					field.text(fieldValue);
				}
			}
		}
	};

	//Traitement de la r�ponse
	if (response) {
		if (response.erreurBloquanteMessage) {
			// Cacher un �ventuel message de chargement
			cacherMessageChargement();

			var erreurBloquanteAjax = $("#erreur-bloquante-ajax");
			erreurBloquanteAjax.find(".gras").text(response.erreurBloquanteMessage);
			if (response.erreurBloquanteUrl){
				erreurBloquanteAjax.find("a").attr("href", response.erreurBloquanteUrl);
			}
			erreurBloquanteAjax.modal();
			return;
		}
		else if (response.erreurTechnique) {
			// Cacher un �ventuel message de chargement
			cacherMessageChargement();

			//Variable qui contiendra la liste des messages d'erreur
			var messageRouge = "<p>" + response.erreurTechnique + "</p>";

			afficherMessageAvertissement("rouge", messageRouge);
		}
		else if (response.erreursMetier) {
			// Cacher un �ventuel message de chargement
			cacherMessageChargement();

			//Variable qui contiendra la liste des messages d'erreur
			var messageJaune = "";

			for (var i = 0; i < response.erreursMetier.length; i++){
				messageJaune = messageJaune + "<p>" + response.erreursMetier[i] + "</p>";
			}

			afficherMessageAvertissement("jaune", messageJaune);
		}
		else if (response.messageSucces) {
			// Cacher un �ventuel message de chargement
			cacherMessageChargement();

			//Variable qui contiendra la liste des messages de succes
			var messageVert = "<p>" + response.messageSucces + "</p>";

			afficherMessageAvertissement("vert", messageVert);

		}
		else {
			$("#message-rouge, #message-jaune, #message-vert").hide();
		}

		if (response.resultat) {
			var finalCallback = noErrorStandardCallback;
			if (customCallBack && $.isFunction(customCallBack)) {
				finalCallback = customCallBack;
			}
			finalCallback(response.resultat);
		}
	}
	// On r�active le bouton
	actionButton.removeClass('disabled');
}




/**
 * Fonction qui cache le message de couleur existant puis affiche un message de la couleur pass�e en param�tre
 * et contenant le message pass� en param�tre.
 * @param couleur couleur du cartouche � afficher. Valeur possible : "vert", "jaune", "rouge"
 * @param message Message � afficher dans le cartouche.
 */
function afficherMessageAvertissement(couleur, message){

	if(couleur != null && couleur.trim() != '' && message != null && message.trim() != '')
	{
		$("#message-rouge, #message-jaune, #message-vert, .message-avertissement").hide();

		var idMessage = "#message-"+couleur.trim();
		$(idMessage+" .textAlerte").html(message);
		$(idMessage).fadeIn();
	}

}
