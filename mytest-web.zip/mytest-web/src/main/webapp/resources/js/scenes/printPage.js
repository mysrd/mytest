/**
 * Plugin de mise en forme des pages pour l'impression
 *
 * Paramt�res : 1. Classes (Array) Ensemble des selecteurs permettant la
 * selection des �l�ments � afficher. Si l'option jQuerySelectors est activ�e :
 * Les selecteurs sont appliqu�s tels qu'indiqu� dans le tableau Exemple : [
 * '#logTable', 'header > div'] Si l'option est d�sactiv�e : Les classes pass�es
 * sous forme de tableau sont s�lectionn�es dans le document. Si un �lement du
 * tableau contient deux classes (par exemple "myTable red"), tout les �l�ments
 * ayant la classe "myTable" seront selectionn�s, ainsi que tout les �lements
 * ayant la classe css "red" Exemple : [ 'datatable', 'printable', 'myTable
 * red'] 2. Options (Object) Tableau associatif permettant la configuration
 * avanc�e du composant (voir options disponibles)
 *
 * Options disponibles : - title (string) - Defaut : Nom actuel de la page
 * Permet de s�cifier le nom de la page en mode impression (affichera un titre
 * H1) - displayTitle (bool) - Defaut : true Premet de sp�cifier si le titre est
 * affich� dans la page � imprimer - beforeFormat (function) - Defaut :
 * function(sender, args){} Permet de sp�cifier une fonction a executer avant la
 * mise en forme de la page "sender" est une r�f�rence sur le moteur de rendu
 * d'impression "args" est un objet permettant d'acceder � la liste des �lements
 * selectionn�s pour l'impression - afterFormat (function) - Defaut :
 * function(sender, args){} Permet de sp�cifier une fonction � executer apr�s la
 * mise en forme de la page "sender" est une r�f�rence sur le moteur de rendu
 * d'impression "args" est un objet permettant d'acceder � la liste des �lements
 * selectionn�s pour l'impression - jQuerySelectors (bool) - Defaut : false
 * Permet de sp�cifier que la liste de string pass� en paramt�re sont des
 * selecteurs jQuery permettant la selection des noeud � conserver - omit
 * (String) - Default : "unprintable" Permet de sp�cifier la classe css � ne pas
 * afficher lors de l'impression
 */

if (window.MVR == null) {
	window.MVR = {};
}

MVR.PagePrinter = {
	PrintPageEngine : null
};

// Configuration par d�faut
MVR.PagePrinter.DefaultConfig = {
	title : document.title,
	displayTitle : true,
	jQuerySelectors : false,
	beforeFormat : function() {
	},
	afterFormat : function() {
	},
	omit : 'unprintable'
};

// PagePrinterEngine
MVR.PagePrinter.PrintPageEngine = function(_classes, _opt) {
	this.options = $.extend({}, MVR.PagePrinter.DefaultConfig, _opt);

	this.classes = [ 'printable' ];
	if (_classes != null) {
		// Si le param�tre classes n'est pas un tableau
		if (typeof _classes == 'string') {
			_classes = [ _classes ];
		}

		this.classes = _classes;
	} else {
		// Si aucune classe n'est d�finie, on affiche tout les tableaux de la
		// page
		this.classes = [ 'table' ];
	}

	// Initialisation des options
	this._checkOptions(_opt);

	// Si on utilise pas les selecteurs jQuery
	if (this.options.jQuerySelectors == false) {
		// On converti les nom de classe CSS en selecteur jQuery
		var tempClasses = [];
		for ( var key in this.classes) {
			// On g�re le cas o� plusieurs classes sont sp�cifi�es dans un seul
			// �lement du tableau
			var splitted = this.classes[key].split(" ");
			for ( var i = 0; i < splitted.length; i++) {
				tempClasses.push('.' + splitted);
			}
		}
		// On red�finit le tableaux de selecteur
		this.classes = tempClasses;
	}
};

// Verification des options pass�es
MVR.PagePrinter.PrintPageEngine.prototype._checkOptions = function(_opt) {
	if (typeof (this.options['title']) != 'string') {
		throw 'L\'option "title" doit �tre de type string';
	}

	if (typeof (this.options['displayTitle']) != 'boolean') {
		throw 'L\'option "displayTitle" doit �tre de type bool';
	}

	if (typeof (this.options['beforeFormat']) != 'function') {
		throw 'L\'option "beforeFormat" doit �tre de type fonction';
	}
	if (typeof (this.options['afterFormat']) != 'function') {
		throw 'L\'option "afterFormat" doit �tre de type fonction';
	}
	if (typeof (this.options['jQuerySelectors']) != 'boolean') {
		throw 'L\'option "jQuerySelectors" doit �tre de type bool';
	}
	if (typeof (this.options['omit']) != 'string') {
		throw 'L\'option "omit" doit �tre de type string';
	}
};

// run method
MVR.PagePrinter.PrintPageEngine.prototype.run = function() {
	// On utilise la forme de la fonction jQuery utilisant un nombre dynamique
	// de param�tre
	// pour fusionner les requ�tes
	var elementsToKeep = jQuery.apply(null, this.classes);

	this.options.beforeFormat(this, {
		elements : elementsToKeep
	});

	// Cr�ation des deux div
	var printableDiv = $('<div>').addClass('print');

	// Ajout du titre
	if (this.options.displayTitle) {
		var titleTag = $('<h1>').html(this.options.title);
		printableDiv.append(titleTag);
	}

	var elementToKeepCopy = $(elementsToKeep).clone();

	// Copier les �lements conserv�s dans la Div2
	elementToKeepCopy.each(function(i, el) {
		printableDiv.append(el);
	});



	var omitClosure = this.options.omit;

	// Suppression des styles (non recursive car lin�arisation jQuery)
	printableDiv.find("*").each(function(i, el) {
		// Suppression des elements non-imprimables
		if ($(el).hasClass(omitClosure)) {
			$(el).remove();
		}
		if ($(el).hasClass('dataTables_filter')) {
			$(el).remove();
		}
		if ($(el).hasClass('span1')) {
			$(el).remove();
		}
		if ($(el).hasClass('span11')) {
				$(el).removeClass('span11');
				$(el).addClass('span12');
		}
	});

	this.options.afterFormat(this, {
		elements : elementToKeepCopy
	});



	// Cr�ation de la nouvelle fenetre

	var newWindow = window.open('', this.options.title, 'width=1000,height=900,scrollbars=1');
	newWindow.document.title = this.options.title;


	var headDestination = $(newWindow.document.head);

	// Ajout des styles CSS
	$(document.head).find('link[rel="stylesheet"]').each(function(i, el){
		var domEl = newWindow.document.createElement('link');
		var link = $(domEl).attr('href', el.href).attr('rel', 'stylesheet');
		link.appendTo(headDestination);
	});

	var printHtml = $('<div>').append(printableDiv).html();

	// Insertion du code HTML
	$(newWindow.document.body).html(printHtml);

	newWindow.print();
};

// Labels de traductions
MVR.PagePrinter.Locale = {
	NotSet : '-'
};

// Helpers
MVR.PagePrinter.Helpers = {
	Functions : {
		// permet de transformer les champs affich�s en simples labels
		renderInputs : function(elements) {
			// Chaque champ trouv�
			elements.find(":input").each(function(i, el) {
				$(el).css({
					display : 'none'
				});

				var visible = true;

				var type=$(el).attr('type');

				if(type=='checkbox'){
					$(el).css({
						display : ''
					});
					return;
				}


				// Si le champ est cach�
				if (type == 'hidden') {
					visible = false;
				}

				// Si le champ est visible
				if (visible) {
					var label = $('<span>'); // On cr�e un label
					var value = $(el).val();
					if (value == '') {
						value = MVR.PagePrinter.Locale.NotSet;
					}

					var name = $(el).attr('name');
					// Dans le cas de la taille du tableau, il faut afficher
					// ce qui est affich� � l'�cran et non pas la valeur de l'option
					if (name != null && name.indexOf("_length") !== -1) {
						var idSelect = '#' + name.substring(0, name.length - 7);
						var myDatatable = $(idSelect).dataTable();
						if (myDatatable.fnSettings()._iDisplayLength !== -1) {
							label.text(myDatatable.fnSettings()._iDisplayLength);
						} else {
							label.text('tous');
						}
					} else {
						label.text(value); // On y insert la valeur de l'input
					}

					label.insertAfter(el); // On ajout le nouveau noeud au DOM
				}
			});
		},
		removeImages : function(elements) {
			elements.find('img').each(function(i, el) {
				$(el).css({
					display : 'none'
				});
			});
		}
	}
};
