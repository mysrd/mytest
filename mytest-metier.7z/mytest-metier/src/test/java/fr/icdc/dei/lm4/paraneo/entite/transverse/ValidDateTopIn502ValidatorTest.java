package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

public class ValidDateTopIn502ValidatorTest {

	@Test
	public void testTopInNonTrue() {

		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, 0001);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,01);
		Date yddin = calendrier.getTime();

		TaChoixOuiNon ytopin = new TaChoixOuiNon();
		ytopin.setCodeChoixOuiNon("N");

		TaDeviseLmtay502 taDeviseLmtay502 = new TaDeviseLmtay502();
		taDeviseLmtay502.setTaChoixOuiNonByYtopin(ytopin);
		taDeviseLmtay502.setYddin(yddin);

		ValidDateTopIn502Validator validator = new ValidDateTopIn502Validator();
		assertEquals(true,validator.isValid(taDeviseLmtay502, null));
	}

	@Test
	public void testTopInNonFalse() {

		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, 1900);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,01);
		Date yddin = calendrier.getTime();

		TaChoixOuiNon ytopin = new TaChoixOuiNon();
		ytopin.setCodeChoixOuiNon("N");

		TaDeviseLmtay502 taDeviseLmtay502 = new TaDeviseLmtay502();
		taDeviseLmtay502.setTaChoixOuiNonByYtopin(ytopin);
		taDeviseLmtay502.setYddin(yddin);

		ValidDateTopIn502Validator validator = new ValidDateTopIn502Validator();
		assertEquals(false,validator.isValid(taDeviseLmtay502, null));
	}

	@Test
	public void testTopInOuiTrue1() {

		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, 1900);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,01);
		calendrier.set(Calendar.HOUR_OF_DAY, 0);
		calendrier.set(Calendar.MINUTE,0);
		calendrier.set(Calendar.SECOND, 0);
		calendrier.set(Calendar.MILLISECOND, 0);
		Date yddin = calendrier.getTime();

		TaChoixOuiNon ytopin = new TaChoixOuiNon();
		ytopin.setCodeChoixOuiNon("O");

		TaDeviseLmtay502 taDeviseLmtay502 = new TaDeviseLmtay502();
		taDeviseLmtay502.setTaChoixOuiNonByYtopin(ytopin);
		taDeviseLmtay502.setYddin(yddin);

		ValidDateTopIn502Validator validator = new ValidDateTopIn502Validator();
		assertEquals(true,validator.isValid(taDeviseLmtay502, null));
	}

	@Test
	public void testTopInOuiTrue2() {

		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, 1900);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,02);
		calendrier.set(Calendar.HOUR_OF_DAY, 0);
		calendrier.set(Calendar.MINUTE,0);
		calendrier.set(Calendar.SECOND, 0);
		calendrier.set(Calendar.MILLISECOND, 0);
		Date yddin = calendrier.getTime();

		TaChoixOuiNon ytopin = new TaChoixOuiNon();
		ytopin.setCodeChoixOuiNon("O");

		TaDeviseLmtay502 taDeviseLmtay502 = new TaDeviseLmtay502();
		taDeviseLmtay502.setTaChoixOuiNonByYtopin(ytopin);
		taDeviseLmtay502.setYddin(yddin);

		ValidDateTopIn502Validator validator = new ValidDateTopIn502Validator();
		assertEquals(true,validator.isValid(taDeviseLmtay502, null));
	}

	@Test
	public void testTopInOuiFalse() {

		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, 1899);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,01);
		calendrier.set(Calendar.HOUR_OF_DAY, 0);
		calendrier.set(Calendar.MINUTE,0);
		calendrier.set(Calendar.SECOND, 0);
		calendrier.set(Calendar.MILLISECOND, 0);
		Date yddin = calendrier.getTime();

		TaChoixOuiNon ytopin = new TaChoixOuiNon();
		ytopin.setCodeChoixOuiNon("O");

		TaDeviseLmtay502 taDeviseLmtay502 = new TaDeviseLmtay502();
		taDeviseLmtay502.setTaChoixOuiNonByYtopin(ytopin);
		taDeviseLmtay502.setYddin(yddin);

		ValidDateTopIn502Validator validator = new ValidDateTopIn502Validator();
		assertEquals(false,validator.isValid(taDeviseLmtay502, null));
	}
}
