package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.jms.Destination;

import mockit.Injectable;
import mockit.Mocked;
import mockit.NonStrictExpectations;
import mockit.Tested;
import mockit.Verifications;

import org.junit.Test;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.lm4.paraneo.entite.transverse.NotificationDido;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaJourFerieTargetLmtay739;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016;
import static org.junit.Assert.assertEquals;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
public class NotificationDidoBusinessServiceImplTest {


	@Injectable
	JmsTemplate mockJMS;

	@Mocked
	SecurityContextHolder mockSecurity;

	@Mocked
	SecurityContext mockSecurityContext;

	@Mocked
	Authentication mockAuth;

	@Tested
	NotificationDidoBusinessServiceImpl testedClass;


	private TaJourFerieTargetLmtay739 getTable(){
		TaJourFerieTargetLmtay739 lmtay739 = new TaJourFerieTargetLmtay739();
		lmtay739.setYdjfer(Calendar.getInstance().getTime());
		lmtay739.setYdc000(Calendar.getInstance().getTime());
		lmtay739.setCuser("TOTO");
		return lmtay739;
	}



	private TableDescription getTableDescription(){
		TableDescription descriptionLmtay739 = new TableDescription();
		List<ColumnDescription> listeColonnes = new ArrayList<ColumnDescription>();

		ColumnDescription colonneYdjfer = new ColumnDescription();
		colonneYdjfer.setPrimaryKey(true);
		colonneYdjfer.setClassName(Date.class.getName());
		colonneYdjfer.setColumnName("ydjfer");
		colonneYdjfer.setTable(descriptionLmtay739);
		listeColonnes.add(colonneYdjfer);

		ColumnDescription colonneCuser = new ColumnDescription();
		colonneCuser.setClassName(String.class.getName());
		colonneCuser.setColumnName("cuser");
		colonneCuser.setTable(descriptionLmtay739);
		listeColonnes.add(colonneCuser);

		descriptionLmtay739.setEntityClassName(TaJourFerieTargetLmtay739.class.getName());
		descriptionLmtay739.setColumnList(listeColonnes);

		return descriptionLmtay739;

	}





	@Test
	public void testEnvironnementLocalPasDeNotif() throws BusinessServiceException{
		testedClass.setEnvironnement("LOC");

		new NonStrictExpectations() {{
			mockAuth.getName();result="Toto";
		}};

		TaJourFerieTargetLmtay739 lmtay739 = getTable();
		TableDescription descriptionLmtay739 = getTableDescription();

		testedClass.envoyerNotificationCreation(lmtay739, descriptionLmtay739);
		testedClass.envoyerNotificationModification(lmtay739, descriptionLmtay739);
		testedClass.envoyerNotificationSuppression(lmtay739, descriptionLmtay739);

		new Verifications() {
			{
				mockJMS.convertAndSend((Destination) any,(NotificationDido) any);times=0;
			}
		};
	}

	@Test
	public void testEnvironnementIntegrationLoginAcceptation() throws BusinessServiceException {
		testedClass.setEnvironnement("DEV");

		new NonStrictExpectations() {
			{
				mockAuth.getName();result="aparaneo";
			}
		};


		TaJourFerieTargetLmtay739 lmtay739 = getTable();
		TableDescription descriptionLmtay739 = getTableDescription();

		testedClass.envoyerNotificationCreation(lmtay739, descriptionLmtay739);
		testedClass.envoyerNotificationModification(lmtay739, descriptionLmtay739);
		testedClass.envoyerNotificationSuppression(lmtay739, descriptionLmtay739);

		new Verifications() {
			{
				mockJMS.convertAndSend((Destination) any,(NotificationDido) any);times=0;
			}
		};

	}

	@Test
	public void testEnvoiTableSimple() throws BusinessServiceException{
		testedClass.setEnvironnement("DEV");

		new NonStrictExpectations() {
			{
				mockAuth.getName();result="test";
			}
		};


		TaJourFerieTargetLmtay739 lmtay739 = getTable();
		TableDescription descriptionLmtay739 = getTableDescription();

		testedClass.envoyerNotificationCreation(lmtay739, descriptionLmtay739);

		final NotificationDido notifAttendue = new NotificationDido();
		notifAttendue.setCodeEvenement("INSERT");
		String identifiant = new SimpleDateFormat("yyyy-MM-dd").format(lmtay739.getYdjfer());
		notifAttendue.setIdObjet(identifiant);
		notifAttendue.setTypeObjet("LMTAY739");
		notifAttendue.setIdCible("");

		new Verifications() {
			{
				NotificationDido notifEnvoyee;
				mockJMS.convertAndSend((Destination) any, notifEnvoyee = withCapture());times=1;
				assertEquals(notifAttendue.getCodeEvenement(),notifEnvoyee.getCodeEvenement());
				assertEquals(notifAttendue.getIdObjet(), notifEnvoyee.getIdObjet());
				assertEquals(notifAttendue.getTypeObjet(), notifEnvoyee.getTypeObjet());
				assertEquals(notifAttendue.getIdCible(), notifEnvoyee.getIdCible());
			}
		};

	}



}
