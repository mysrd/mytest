package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculCogValidatorTest {

	@Test
	public void testIsValidCasPassant() throws Exception {
		CalculCogValidator validator = new CalculCogValidator();	
		TaCommuneInsee classeValidee = new TaCommuneInsee();
		classeValidee.setCom("123");
		TaDepartement taDepartement = new TaDepartement();
		taDepartement.setYc0dep("12");
		taDepartement.setYl0dep("Armor");
		classeValidee.setTaDepartement(taDepartement );
		classeValidee.setCog("12123");
		assertEquals(true,validator.isValid(classeValidee , null));
	}

	
	@Test
	public void testIsValidCasNonPassant() throws Exception {
		CalculCogValidator validator = new CalculCogValidator();	
		TaCommuneInsee classeValidee = new TaCommuneInsee();
		classeValidee.setCom("123");
		TaDepartement taDepartement = new TaDepartement();
		taDepartement.setYc0dep("12");
		taDepartement.setYl0dep("Armor");
		classeValidee.setTaDepartement(taDepartement );
		classeValidee.setCog("99999");
		assertEquals(false,validator.isValid(classeValidee , null));
	}

}
