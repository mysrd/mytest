package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import java.lang.annotation.Annotation;

import javax.validation.Payload;

import org.junit.Test;

public class CaracAutorisesDecimalSansFractionValidatorTest {

	private void initTestDecimal(CaracAutorisesDecimalSansFractionValidator validator) {
		CaracAutorisesDecimalSansFraction annotation = new CaracAutorisesDecimalSansFraction() {

			@Override
			public Class<? extends Annotation> annotationType() {
				return null;
			}

			@Override
			public Class<? extends Payload>[] payload() {
				return null;
			}

			@Override
			public int nbCarac() {			// La zone saisie contient au plus 3 caractères
				return 3;
			}

			@Override
			public String message() {
				return null;
			}

			@Override
			public Class<?>[] groups() {
				return null;
			}
		};
		validator.initialize(annotation);
	}

	@Test
	public void test1() {
		CaracAutorisesDecimalSansFractionValidator validator = new CaracAutorisesDecimalSansFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(1, null));
	}

	@Test
	public void test2(){
		CaracAutorisesDecimalSansFractionValidator validator = new CaracAutorisesDecimalSansFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(123, null));
	}

	@Test
	public void test3(){
		CaracAutorisesDecimalSansFractionValidator validator = new CaracAutorisesDecimalSansFractionValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid(123456789, null));
	}

}
