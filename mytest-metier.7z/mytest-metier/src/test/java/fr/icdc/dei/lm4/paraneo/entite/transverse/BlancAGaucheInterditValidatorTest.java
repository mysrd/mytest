package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import org.junit.Test;

public class BlancAGaucheInterditValidatorTest {

	@Test
	public void BlancBlancBlanc(){
		BlancAGaucheInterditValidator validator = new BlancAGaucheInterditValidator();
		String Valeur = "   ";
		assertEquals(false,validator.isValid(Valeur, null));
	}

	@Test
	public void BlancPasBlancBlanc(){
		BlancAGaucheInterditValidator validator = new BlancAGaucheInterditValidator();
		String Valeur = " A ";
		assertEquals(false,validator.isValid(Valeur, null));
	}

	@Test
	public void PasBlancBlancBlanc(){
		BlancAGaucheInterditValidator validator = new BlancAGaucheInterditValidator();
		String Valeur = "A  ";
		assertEquals(true,validator.isValid(Valeur, null));
	}

	@Test
	public void BlancBlancPasBlanc(){
		BlancAGaucheInterditValidator validator = new BlancAGaucheInterditValidator();
		String Valeur = "  A";
		assertEquals(false,validator.isValid(Valeur, null));
	}


}
