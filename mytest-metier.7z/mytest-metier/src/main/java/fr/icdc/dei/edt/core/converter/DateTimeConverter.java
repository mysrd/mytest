package fr.icdc.dei.edt.core.converter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateTimeConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.DateTimeConverter";

	private static final TimeZone TIMEZONE_DEFAULT = TimeZone.getTimeZone("Europe/Paris");

	/**
	 * Specifies what contents the string value will be formatted to include, or
	 * parsed expecting. Valid values are "date", "time", and "both". Default
	 * value is "date".
	 */
	private String type;

	/**
	 * Predefined formatting style which determines how the date component of a
	 * date string is to be formatted and parsed. Applied only if type is "date"
	 * or "both". Valid values are "default", "short", "medium", "long", and
	 * "full".
	 * 
	 * Default value is "default".
	 */
	private String dateStyle;

	/**
	 * Predefined formatting style which determines how the time component of a
	 * date string is to be formatted and parsed. Applied only if type is "time"
	 * or "both". Valid values are "default", "short", "medium", "long", and
	 * "full". Default value is "default".
	 */
	private String timeStyle;

	/**
	 * Locale whose predefined styles for dates and times are used during
	 * formatting or parsing. If not specified, the default Locale will be used.
	 * */
	private Locale locale = Locale.getDefault();

	/**
	 * Custom formatting pattern which determines how the date/time string
	 * should be formatted and parsed.
	 */
	private String pattern = "dd/MM/yyyy";

	/**
	 * Time zone in which to interpret any time information in the date String.
	 * Value must be a String that is a timezone ID as described in the javadocs
	 * for java.util.TimeZone.getTimeZone().
	 */
	private TimeZone timeZone;

	public DateTimeConverter() {
	}

	/**
	 * @see fr.icdc.dei.edt.core.converter.Converter#getAsObject(java.lang.String)
	 */
	public Object getAsObject(String value) throws ConverterException {

		if (value == null) {
			return null;
		}

		String trimmedValue = value.trim();
		if (trimmedValue.length() == 0) {
			return null;
		}

		DateFormat dateFormat = prepareDateFormat();
		Date date;
		try {
			date = dateFormat.parse(trimmedValue);
		} catch (ParseException e) {
			throw new ConverterException(CONVERSION_MESSAGE_ID, e);
		}

		// La m�thode parse de DateFormat peut analyser qu'une
		// partie de la cha�ne, ce comportement ne nous int�resse pas. Il faut
		// que la chaine de caract�re soit analys�e. C'est pour cela que
		// nous faisant l'op�ration inverse pour s'assurer que la chaine cr��e
		// � partir de la date est strictement �gale � la chaine qui servit
		// � la cr�ation de la date.

		String dateAsString = dateFormat.format(date);
		if (!dateAsString.equals(value))
			throw new ConverterException(CONVERSION_MESSAGE_ID);

		return date;
	}

	/**
	 * @see fr.icdc.dei.edt.core.converter.Converter#getAsString(java.lang.Object)
	 */
	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}

		DateFormat dateFormat = prepareDateFormat();
		String dateAsString = dateFormat.format(value);
		return dateAsString;

	}

	// ============================================================================

	private DateFormat prepareDateFormat() throws ConverterException {
		DateFormat format = getDateFormat();
		// format cannot be lenient (JSR-127)
		format.setLenient(false);

		TimeZone tz = getTimeZone();
		if (tz != null) {
			format.setTimeZone(tz);
		}

		return format;
	}

	private DateFormat getDateFormat() throws ConverterException {
		if (this.pattern != null) {
			try {
				return new SimpleDateFormat(this.pattern, getLocale());
			} catch (IllegalArgumentException iae) {
				throw new ConverterException("Invalid pattern", iae, new Object[] { this.pattern });
			}
		}

		return AbstractType.getType(getType()).getFormatter(calcDateStyle(), calcTimeStyle(), getLocale());
	}

	private int calcDateStyle() throws ConverterException {
		return Style.getStyleFormat(getDateStyle());
	}

	private int calcTimeStyle() throws ConverterException {
		return Style.getStyleFormat(getTimeStyle());
	}

	// ============================================================================

	public String getDateStyle() {
		return this.dateStyle != null ? this.dateStyle : Style.DEFAULT.getName();
	}

	public void setDateStyle(String dateStyle) {
		// TODO validate timeStyle
		this.dateStyle = dateStyle;
	}

	public Locale getLocale() {
		return this.locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getPattern() {
		return this.pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getTimeStyle() {
		return this.timeStyle != null ? this.timeStyle : Style.DEFAULT.getName();
	}

	public void setTimeStyle(String timeStyle) {
		// TODO validate timeStyle
		this.timeStyle = timeStyle;
	}

	public TimeZone getTimeZone() {
		return this.timeZone != null ? this.timeZone : TIMEZONE_DEFAULT;
	}

	public void setTimeZone(TimeZone timeZone) {
		this.timeZone = timeZone;
	}

	public String getType() {
		return this.type != null ? this.type : AbstractType.DATE.getName();
	}

	public void setType(String type) {
		// TODO validate type
		this.type = type;
	}

	// ==============================================================================
	private static class Style {

		private static final Style DEFAULT = new Style("default", DateFormat.DEFAULT);

		private static final Style MEDIUM = new Style("medium", DateFormat.MEDIUM);

		private static final Style SHORT = new Style("short", DateFormat.SHORT);

		private static final Style LONG = new Style("long", DateFormat.LONG);

		private static final Style FULL = new Style("full", DateFormat.FULL);

		private static final Style[] VALUES = new Style[] { DEFAULT, MEDIUM, SHORT, LONG, FULL };

		public static Style getStyle(String name) throws ConverterException {
			for (int i = 0; i < VALUES.length; i++) {
				if (VALUES[i]._name.equals(name)) {
					return VALUES[i];
				}
			}

			throw new ConverterException("invalid style '" + name + "'");
		}

		private static int getStyleFormat(String name) throws ConverterException {
			return getStyle(name).getFormat();
		}

		private String _name;

		private int _format;

		private Style(String name, int format) {
			this._name = name;
			this._format = format;
		}

		public String getName() {
			return _name;
		}

		public int getFormat() {
			return _format;
		}
	}

	// ============================================================================
	private abstract static class AbstractType {

		private static final AbstractType DATE = new AbstractType("date") {
			public DateFormat getFormatter(int dateStyle, int timeStyle, Locale locale) {
				return DateFormat.getDateInstance(dateStyle, locale);
			}
		};

		private static final AbstractType TIME = new AbstractType("time") {
			public DateFormat getFormatter(int dateStyle, int timeStyle, Locale locale) {
				return DateFormat.getTimeInstance(timeStyle, locale);
			}
		};

		private static final AbstractType BOTH = new AbstractType("both") {
			public DateFormat getFormatter(int dateStyle, int timeStyle, Locale locale) {
				return DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
			}
		};

		private static final AbstractType[] VALUES = new AbstractType[] { DATE, TIME, BOTH };

		public static AbstractType getType(String name) throws ConverterException {
			for (int i = 0; i < VALUES.length; i++) {
				if (VALUES[i]._name.equals(name)) {
					return VALUES[i];
				}
			}

			throw new ConverterException("invalid type '" + name + "'");
		}

		private String _name;

		private AbstractType(String name) {
			this._name = name;
		}

		public String getName() {
			return _name;
		}

		public abstract DateFormat getFormatter(int dateStyle, int timeStyle, Locale locale);
	}

	// ==============================================================================

	private String label;

	public void setLabel(String label) {
		this.label = label;
	}

}
