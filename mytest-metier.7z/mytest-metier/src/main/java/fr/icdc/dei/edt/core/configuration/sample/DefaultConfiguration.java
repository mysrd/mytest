/**
 * 
 */
package fr.icdc.dei.edt.core.configuration.sample;

import fr.icdc.dei.edt.core.annotations.EditTable;

/**
 * Table de configuration par défaut d'EditTable
 * @author ffernandez-e
 *
 */
@EditTable
public class DefaultConfiguration {

}
