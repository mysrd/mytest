package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="notification")
@XmlType(propOrder={"typeObjet","idObjet","dateCreation","codeEvenement","idCible"})
public class NotificationDido {
	@XmlElement
	private String idObjet;
	@XmlElement
	private String typeObjet;
	@XmlElement
	private Date dateCreation;
	@XmlElement
	private String codeEvenement;
	@XmlElement
	private String idCible;

	@XmlTransient
	public String getIdObjet() {
		return idObjet;
	}

	public void setIdObjet(String idObjet) {
		this.idObjet = idObjet;
	}
	@XmlTransient
	public String getTypeObjet() {
		return typeObjet;
	}
	public void setTypeObjet(String typeObjet) {
		this.typeObjet = typeObjet;
	}
	@XmlTransient
	public Date getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}
	@XmlTransient
	public String getCodeEvenement() {
		return codeEvenement;
	}
	public void setCodeEvenement(String codeEvenement) {
		this.codeEvenement = codeEvenement;
	}
	@XmlTransient
	public String getIdCible() {
		return idCible;
	}
	public void setIdCible(String idCible) {
		this.idCible = idCible;
	}
}
