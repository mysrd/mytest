package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.ParamDef;

import fr.icdc.dei.edt.core.annotations.DisableTableOperation;
import fr.icdc.dei.edt.core.annotations.TableOperationsEnum;

@Entity
@Table(name = "TA_MENU")
@FilterDefs(value = { @FilterDef(name = "valideFilter", defaultCondition = "VALIDE = :valide", parameters = @ParamDef(name = "valide", type = "boolean")),
		@FilterDef(name = "structuresFilter", defaultCondition = "STRUCTURES like (:structure)", parameters = @ParamDef(name = "structure", type = "string")) })
@DisableTableOperation(operations = {TableOperationsEnum.AddNewRecord})
public class Menu implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "COD_MENU", nullable = false)
	private String codeMenu;

	@Column(name = "LIB_MENU", nullable = false)
	private String libelleMenu;

	@Column(name = "URL", nullable = false)
	private String url;

	@Column(name = "VALIDE", nullable = false)
	private boolean valide;

	@Column(name = "ORDRE", nullable = false)
	private Integer ordre;

	@Column(name = "DROITS", nullable = false)
	private int binaireDroits;

	@Column(name = "STRUCTURES", nullable = false)
	private String structures;

	@OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
	@Filters(value = { @Filter(name = "valideFilter"), @Filter(name = "structuresFilter") })
	@OrderBy("ordre ASC")
	private List<Menu> noeudsEnfants = new ArrayList<Menu>();

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(referencedColumnName = "COD_MENU", name = "PARENT")
	private Menu parent;

	/**
	 *
	 */
	public Menu() {
		super();
	}

	/**
	 * Recupére la liste d'autorisation permettant l'accés au menu
	 *
	 * @return
	 */
	public List<DroitsMenuEnum> getDroits() {
		List<DroitsMenuEnum> droits = new ArrayList<DroitsMenuEnum>();
		// Pour tout les droits de l'�num�ration
		for (DroitsMenuEnum typeDroit : DroitsMenuEnum.values()) {
			// On masque suivant le masque binaire du droit courant
			int result = this.binaireDroits & typeDroit.getCode();

			// Si le masque est superieur � 0
			if (result > 0) {
				// Le menu est autoris� pour ce droit
				droits.add(typeDroit);
			}
		}
		return droits;
	}

	/**
	 * @return the codeMenu
	 */
	public String getCodeMenu() {
		return codeMenu;
	}

	/**
	 * @param codeMenu
	 *            the codeMenu to set
	 */
	public void setCodeMenu(String codeMenu) {
		this.codeMenu = codeMenu;
	}

	/**
	 * @return the libelleMenu
	 */
	public String getLibelleMenu() {
		return libelleMenu;
	}

	/**
	 * @param libelleMenu
	 *            the libelleMenu to set
	 */
	public void setLibelleMenu(String libelleMenu) {
		this.libelleMenu = libelleMenu;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the valide
	 */
	public boolean isValide() {
		return valide;
	}

	/**
	 * @param valide
	 *            the valide to set
	 */
	public void setValide(boolean valide) {
		this.valide = valide;
	}

	/**
	 * @return the ordre
	 */
	public Integer getOrdre() {
		return ordre;
	}

	/**
	 * @param ordre
	 *            the ordre to set
	 */
	public void setOrdre(Integer ordre) {
		this.ordre = ordre;
	}

	/**
	 * @return the structures
	 */
	public String getStructures() {
		return structures;
	}

	/**
	 * @param structures
	 *            the structures to set
	 */
	public void setStructures(String structures) {
		this.structures = structures;
	}

	/**
	 * @return the noeudsEnfant
	 */
	public List<Menu> getNoeudsEnfants() {
		return noeudsEnfants;
	}

	/**
	 * @param noeudsEnfants
	 *            the noeudsEnfant to set
	 */
	public void setNoeudsEnfants(List<Menu> noeudsEnfants) {
		this.noeudsEnfants = noeudsEnfants;
	}

	/**
	 * @return the parent
	 */
	public Menu getParent() {
		return parent;
	}

	/**
	 * @param parent
	 *            the parent to set
	 */
	public void setParent(Menu parent) {
		this.parent = parent;
	}

	public void addNoeudEnfant(Menu noeudEnfant) {
		this.noeudsEnfants.add(noeudEnfant);
	}

	/**
	 * @param binaireDroits
	 *            the binaireDroits to set
	 */
	public void setBinaireDroits(int binaireDroits) {
		this.binaireDroits = binaireDroits;
	}

	/**
	 * @return the binaireDroits
	 */
	public int getBinaireDroits() {
		return binaireDroits;
	}

	/**
	 * @return la valeur de la cl� primaire
	 */
	public String toString() {
		return getCodeMenu();
	}
}
