package fr.icdc.dei.edt.core.configuration;

import java.util.Map;

import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;

public interface ConfigurationLoader {

	/**
	 * @return Une map des configurations de toutes les tables. La clé est le
	 *         nom de la table en UpperCase.
	 * 
	 */
	Map<String, TableConfigImpl> getTableConfigurations();

}