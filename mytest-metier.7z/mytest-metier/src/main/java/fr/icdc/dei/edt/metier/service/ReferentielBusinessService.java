package fr.icdc.dei.edt.metier.service;

import java.beans.IntrospectionException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import fr.icdc.dei.edt.core.converter.ConverterException;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.core.recherche.Condition;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesInputAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesOutputAjax;
import fr.icdc.dei.lm4.paraneo.utils.HDIVWrapper;

public interface ReferentielBusinessService {

	/**
	 * Renvoie la liste des tables disponibles.
	 *
	 * @return Collection d'objets <code>TableDescription</code>
	 */
	List<TableDescription> getTableList() throws BusinessServiceException;

	/**
	 * Trouve un objet selon son id.
	 */
	Object findById(Class<?> clazz, Serializable id) throws BusinessServiceException;

	/**
	 * Renvoie tous les enregistrements d'une table.
	 */
	List<Object> findAll(String className) throws BusinessServiceException;

	/**
	 * Renvoie tous les enregistrements d'une table.
	 */
	List<Object> findAll(String className, int firstResult, int maxResults) throws BusinessServiceException;


	/**
	 * Renvoie certaines colonnes d'une table suivant des conditions.
	 */
	List<Object> findAll(String className, List<Condition> conditions) throws BusinessServiceException;

	/**
	 * Renvoie tous les enregistrements d'une table.
	 */
	/*
	 * List<Object> search(String className, List<Condition> conditions, int
	 * firstResult, int maxResults, List<OrderBy> orderByList) throws
	 * BusinessServiceException;
	 */
	  int count(String className) throws BusinessServiceException;
	  
	  /**
	   * Compte le nombre de lignes actives presentes dans une table
	   * @param className
	   * @return
	   * @throws BusinessServiceException
	   */
	  int countActif(String className) throws BusinessServiceException;
	  
	  /**
	   * Compte le nombre de lignes closes presentes dans une table
	   * @param className
	   * @return
	   * @throws BusinessServiceException
	   */
	  int countClos(String className) throws BusinessServiceException;
	 /*
	 * int countForConditions(String className, List<Condition> conditions)
	 * throws BusinessServiceException;
	 */

	void create(Object obj) throws BusinessServiceException, ConverterException, IllegalArgumentException, SecurityException,
	IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException;


	/**
	 * Creer un objet.
	 */
	void create(Object obj, TableDescription table) throws BusinessServiceException, ConverterException, IllegalArgumentException, SecurityException,
			IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException;

	/**
	 * Modifie un objet.
	 */
	void update(Object newValue, Object oldObject, TableDescription table) throws BusinessServiceException, ConverterException, IllegalArgumentException,
			SecurityException, IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException;

	/**
	 * Modifie un objet (sans log)
	 */
	public void update(Object newValue) throws BusinessServiceException;
	/**
	 * Supprime un objet.
	 */
	void delete(Object obj, TableDescription table) throws BusinessServiceException, ConverterException, IllegalArgumentException, SecurityException,
			IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException;

	/**
	 * Renvoie l'ordre des colonnes d'une table passée en paramétre
	 * @param table
	 * @return
	 */
	List<String> getColumnsOrder(TableDescription table);

	/**
	 * Recupere tous les libelles des colonnes des tables
	 * @return
	 * @throws BusinessServiceException
	 */
	List<TaLibelleColonneTable> getAllLibelleColonneTable() throws BusinessServiceException;

	/**
	 * Recherche d'un enregistrement a partir d'une cle primaire composee
	 * @param classeEntite
	 * @param clefsPrimaire
	 * @param valeurs
	 * @return
	 */
	Object findByMultiCriteria(Class<?> classeEntite,List<String> clefsPrimaire, List<Object> valeurs);

	/**
	 * Verifie que la date du jour ferie YDJFER saisie n'existe pas deja en base dans la table ta_jour_ferie_legal_par_pays_lmtay602
	 * @param dateRecherchee
	 * @return
	 */
	boolean verifUniciteJourFerieLegal(Date dateRecherchee);

	/**
	 * Verifie que la date du jour ferie YDJFER saisie dans la table ta_jour_ferie_legal_par_pays_lmtay602 n'existe pas deja en base
	 * @param nomTableTestee
	 * @param dateRecherchee
	 * @return
	 */
	boolean verifUniciteJourFerieLegal602(String nomTableTestee, Date dateRecherchee);

	/**
	 * Verifie que le code pays fourni (ISO2 ou ISO3 NUM) saisi dans la table ta_pays_lmtay501 n'existe pas deja dans cette table
	 * @param cpay
	 * @param valeurDuChamp
	 * @param nomChamp
	 * @return
	 */
	boolean verifUniciteCodePays501(String cpay, String valeurDuChamp, String nomChamp);

	/**
	 * Verifie que le code devise ISO NUM saisi dans la table ta_devise_lmtay502 n'existe pas deja dans cette table
	 * @param cdev
	 * @param valeurDuChamp
	 * @return
	 */
	boolean verifUniciteCodeDeviseIsoNum502(String cdev, String valeurDuChamp);

	/**
	 * Verifie que le couple code bureau et code service saisi dans la table ta_complement_structure_banq_lmtay_890 n'existe pas deja dans cette table
	 * @param cung
	 * @param cburo
	 * @param cdserv
	 * @return
	 */
	boolean verifUniciteCoupleCodesBureauEtService(String cung, String cburo, String cdserv);

	/**
	 * Verifie que le code pole saisi dans la table ta_complement_structure_banq_lmtay_890 n'existe pas deja dans cette table
	 * @param cung
	 * @param cburo
	 * @param cdserv
	 * @return
	 */
	boolean verifUniciteCodePole(String cung, String cpole);

	/***
	 *
	 * @param draw
	 * @param start
	 * @param length
	 * @param parametresStructures
	 * @param table TODO
	 * @param objetsTableAAficcher TODO
	 * @return
	 * @throws BusinessServiceException
	 */
	DatatablesOutputAjax requeteDatatables(Integer draw, Integer start, Integer length, DatatablesInputAjax parametresStructures, String table, List<String> tablesEnModification, List<String> tablesEnSuppression, HDIVWrapper hdivWrapper, List<Object> objetsTableAAficcher) throws BusinessServiceException;

	Integer countDatatableFiltre(DatatablesInputAjax parametresStructures,TableDescription descriptionTable) throws BusinessServiceException;

	public byte[] exportExcel(String className) throws BusinessServiceException;
}