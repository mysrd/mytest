package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import fr.icdc.dei.lm4.paraneo.entite.transverse.ChampCalcule;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.ChampCalculeService;

@Service("champCalculeService")
public class ChampCalculeServiceImpl implements ChampCalculeService {

	@Autowired
	private ApplicationContext applicationContext;
	
	@Override
	public List<String> obtenirColonnes(String nomClasse) throws BusinessServiceException {
		try {
			List<String> listeDesColonnesCalculees = new ArrayList<String>();
			Class<?> classeEnregistrement = Class.forName(nomClasse);
			Field[] champs = classeEnregistrement.getDeclaredFields();
			for (int i = 0; i < champs.length; i++) {
				if (champs[i].getAnnotation(ChampCalcule.class) != null) {
					listeDesColonnesCalculees.add(champs[i].getName());
				}
			}
			return listeDesColonnesCalculees;
		} catch (ClassNotFoundException e) {
			throw new BusinessServiceException(e);
		}

	}

	@Override
	public void calculerValeurChamps(Object enregistrement) throws BusinessServiceException {
		try {
			// On peut avoir entre 0 et N champs à calculer
			Class<? extends Object> classeEnregistrement = enregistrement.getClass();
			Field[] champs = classeEnregistrement.getDeclaredFields();
			for (int i = 0; i < champs.length; i++) {
				if (champs[i].getAnnotation(ChampCalcule.class) != null) {
					Field champACalculer = champs[i];
					ChampCalcule annotation = champs[i].getAnnotation(ChampCalcule.class);
					//On regarde le parametre qui est demande
					String nomDuChampParametre = annotation.champParametre();
					
					// On obtient le parametre
					String valeurDuChamp = "";
					for (int x = 0; x < champs.length; x++) {
						if(champs[x].getName().equals(nomDuChampParametre)){
							champs[x].setAccessible(true);
							valeurDuChamp = (String) champs[x].get(enregistrement);
							champs[x].setAccessible(false);
						}
					}
	
					Class<?> classeDeCalcul = annotation.methodeCalcul();
					if(ClasseDeCalcul.class.isAssignableFrom(classeDeCalcul)){
						// On appelle la méthode de calcul en lui passant le parametre						
						String nomDeClasse = classeDeCalcul.getSimpleName();
						String premiereLettre = nomDeClasse.substring(0, 1).toLowerCase();
						
						String nomClasseCamelCase = premiereLettre+nomDeClasse.substring(1); 
						ClasseDeCalcul calculateur = (ClasseDeCalcul) applicationContext.getBean(nomClasseCamelCase);
						String resultatCalcul = calculateur.calculer(valeurDuChamp);

						// On affecte le resultat a l'enregistrement initial
						champACalculer.setAccessible(true);
						champACalculer.set(enregistrement, resultatCalcul);
						champACalculer.setAccessible(false);
					} 
				} 
			}
		} catch(IllegalArgumentException | IllegalAccessException e ){
			throw new BusinessServiceException(e);
		}
	}
}
