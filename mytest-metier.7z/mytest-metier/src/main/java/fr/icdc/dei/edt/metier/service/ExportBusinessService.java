package fr.icdc.dei.edt.metier.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.supercsv.io.ICsvBeanWriter;

import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

public interface ExportBusinessService {
	void ecrireFichier(ICsvBeanWriter writer, Map<String,Object> model) throws IOException, BusinessServiceException;
	
	Map<String,String> obtenirCorrespondanceCodeLibelle(List<TaLibelleColonneTable> libelles, TableDescription descriptionTable );
}
