/**
 *
 */
package fr.icdc.dei.edt.core.configuration.impl.parser;

import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;

import fr.icdc.dei.edt.core.annotations.DisableTableOperation;
import fr.icdc.dei.edt.core.annotations.EditTable;
import fr.icdc.dei.edt.core.annotations.TableMetaData;
import fr.icdc.dei.edt.core.annotations.TableOperationsEnum;
import fr.icdc.dei.edt.core.configuration.ConfigurationException;
import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;

/**
 * Classe permettant la construction de l'objet TableConfigImpl
 *
 * @author ffernandez-e
 *
 */
public class AnnotationTableParser {

	/**
	 * Définition de la configuration par défaut des tables (cette configuration
	 * est surchargée à l'appel de AnnotationTableParser::setDefaultConfig(Class
	 * clazz)
	 */
	static {

		boolean addOp = Boolean.TRUE;
		boolean deleteOp = Boolean.TRUE;
		boolean editOp = Boolean.TRUE;
		boolean viewOp = Boolean.TRUE;

		// Initialisation
		TableConfigImpl temp = new TableConfigImpl();
		temp.setPagination(15);

		temp.setAddNewRecordOp(addOp);
		temp.setDeleteRecordOp(deleteOp);
		temp.setEditRecordOp(editOp);
		temp.setViewRecordOp(viewOp);

		// Mise en place
		AnnotationTableParser.setDefaultConfig(temp);
	}

	/**
	 * Confinguration par défaut utilisée pour l'heritage
	 */
	private static TableConfigImpl defaultConfig;

	/**
	 * Methode permettant de définir pour toute les constructions de table, la
	 * configuration par défaut.
	 *
	 * @param defaultConfig
	 *            , Configuration de table par défaut
	 */
	public static void setDefaultConfig(TableConfigImpl defaultConfig) {
		AnnotationTableParser.defaultConfig = defaultConfig;
	}

	/**
	 * Methode permettant de définir pour toute les constructions de table, la
	 * configuration par défaut à partir d'une classe.
	 *
	 * @param clazz
	 */
	public static void setDefaultConfig(Class clazz) {
		AnnotationTableParser parser = new AnnotationTableParser(clazz);
		AnnotationTableParser.defaultConfig = parser.build();
	}

	/**
	 * Classe de l'entiée
	 */
	private Class entityClass;

	/**
	 * Constructeur
	 *
	 * @param clazz
	 */
	public AnnotationTableParser(Class clazz) {
		this.entityClass = clazz;
	}

	@SuppressWarnings({ "unchecked" })
	public TableConfigImpl build() {
		TableConfigImpl config = new TableConfigImpl();

		EditTable editTableAnnotation = this.getAnnotation(this.entityClass, EditTable.class);
		Table tableAnnotation = this.getAnnotation(this.entityClass, Table.class);
		TableMetaData tableMetadata = this.getAnnotation(this.entityClass, TableMetaData.class);
		DisableTableOperation tableDisOperation = this.getAnnotation(this.entityClass, DisableTableOperation.class);

		// config.setEntityClass(this.entityClass);

		// Si l'annotation "EditTable" n'est pas renseignée
		if (editTableAnnotation == null) {
			throw new ConfigurationException("La classe '" + this.entityClass.getName()
					+ "' n'est pas gérée par EditTables. Veillez à renseigner l'annotation : 'EditTable'.");
		}

		// Récupération du nom de la table
		if (tableAnnotation != null) {
			config.setName(tableAnnotation.name());

			// Valeur par défaut de l'alias (nom de la table)
			config.setLabel(tableAnnotation.name());
		}

		// Valeur par défaut de la pagination
		config.setPagination(AnnotationTableParser.defaultConfig.getPagination());

		// Si les métadonnées sont renseignées
		if (tableMetadata != null) {
			// Si l'alias est définit
			if (StringUtils.isNotBlank(tableMetadata.alias())) {
				config.setLabel(tableMetadata.alias());
			}

			// Si la pagination est définie
			if (tableMetadata.pagination() > 0) {
				config.setPagination(tableMetadata.pagination());
			}

			// TODO : Validation bean
		}

		// Initialisation des opérations de tables
		config.setAddNewRecordOp(defaultConfig.getAddNewRecordOp());
		config.setViewRecordOp(defaultConfig.getViewRecordOp());
		config.setEditRecordOp(defaultConfig.getEditRecordOp());
		config.setDeleteRecordOp(defaultConfig.getDeleteRecordOp());

		// Si des opérations on étés explicitement prohibées
		if (tableDisOperation != null) {
			for (TableOperationsEnum operation : tableDisOperation.operations()) {

				// Si opération de type AddNewRecord
				if (TableOperationsEnum.AddNewRecord.equals(operation)) {
					boolean op = Boolean.FALSE;
					config.setAddNewRecordOp(op);
				}

				// Si opération de type DeleteRecordOperation
				else if (TableOperationsEnum.DeleteRecord.equals(operation)) {
					boolean op = Boolean.FALSE;
					config.setDeleteRecordOp(op);
				}

				// Si opération de type DeleteRecordOperation
				else if (TableOperationsEnum.EditRecord.equals(operation)) {
					boolean op = Boolean.FALSE;
					config.setEditRecordOp(op);
				}
				// Si opération de type ViewRecord
				else if (TableOperationsEnum.ViewRecord.equals(operation)) {
					boolean op = Boolean.FALSE;
					config.setViewRecordOp(op);
				} else {
					throw new ConfigurationException("You shouldn't be there...");
				}
			}

		}

		// TODO : Implémenter la construction des colonnes
		// String formValidationName = selectValidationFormName(doc);

		// Pour toutes les colonnes ...
		/*
		 * Map<String, ColumnConfiguration> columnConfigurationMap =
		 * columnConfigurationParser
		 * .getColumnConfigurations(defaultColumnConfiguration);
		 *
		 * tableConfig.setColumnConfigurationMap(columnConfigurationMap);
		 */

		return config;
	}

	private <T, U extends java.lang.annotation.Annotation> U getAnnotation(Class<T> clazz, Class<U> annotationClazz) {
		return (U) clazz.getAnnotation(annotationClazz);
	}
}
