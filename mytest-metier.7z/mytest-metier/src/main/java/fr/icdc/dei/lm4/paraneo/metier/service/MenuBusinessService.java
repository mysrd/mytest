package fr.icdc.dei.lm4.paraneo.metier.service;

import java.util.List;

import fr.icdc.dei.lm4.paraneo.critere.CritereRechercheMenu;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Menu;


public interface MenuBusinessService {

	public List<Menu> construireMenus(CritereRechercheMenu critere);

}
