/**
 * 
 */
package fr.icdc.dei.edt.core.exception;

/**
 * Exception levée lors d'une erreur EditTable
 * 
 * @author ffernandez-e
 * 
 */
public class EditTableException extends Exception {
	public EditTableException() {
		this(null, null);
	}

	public EditTableException(String message) {
		this(message, null);
	}
	
	public EditTableException(Throwable cause) {
		this(null, cause);
	}

	public EditTableException(String message, Throwable cause) {
		super(message, cause);
	}

}
