package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.lm4.paraneo.entite.transverse.NotificationDido;
import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.NotificationDidoBusinessService;
@Service("notificationDido")
public class NotificationDidoBusinessServiceImpl implements NotificationDidoBusinessService {

	private static final String SEPARATEUR = "|";


	@Autowired
    private JmsTemplate jmsTemplate;

	private String environnement;



	public String getEnvironnement() {
		return environnement;
	}

	public void setEnvironnement(String environnement) {
		this.environnement = environnement;
	}

	private static final Logger LOGGER = Logger.getLogger(NotificationDidoBusinessServiceImpl.class);

	private static final String TYPE_CREATION     = "INSERT";
	private static final String TYPE_MODIFICATION = "UPDATE";
	private static final String TYPE_SUPPRESSION  = "DELETE";

	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	/**
	 * Envoie une notification de creation a Dido
	 */
	@Override
	public void envoyerNotificationCreation(Object enregistrement,TableDescription description) throws BusinessServiceException {
		try {
			String identifiant = getIdentifiant(enregistrement, description);
			String typeObjet = getTypeObjet(enregistrement, description);
			this.envoiNotificationDido(identifiant,typeObjet,TYPE_CREATION, description);
		} catch (ClassNotFoundException | NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			throw new BusinessServiceException(e);
		}


	}

	/**
	 * Envoie une notification de modification a Dido
	 */
	@Override
	public void envoyerNotificationModification(Object enregistrement,TableDescription description) throws BusinessServiceException {
		try {
			String identifiant = getIdentifiant(enregistrement, description);
			String typeObjet = getTypeObjet(enregistrement, description);
			this.envoiNotificationDido(identifiant,typeObjet,TYPE_MODIFICATION, description);
		} catch (ClassNotFoundException | NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			throw new BusinessServiceException(e);
		}


	}

	@Override
	/**
	 * Envoie une notification de suppression a Dido
	 */
	public void envoyerNotificationSuppression(Object enregistrement,TableDescription description) throws BusinessServiceException {
		try {
			String identifiant = getIdentifiant(enregistrement, description);
			String typeObjet = getTypeObjet(enregistrement, description);
			this.envoiNotificationDido(identifiant,typeObjet,TYPE_SUPPRESSION, description);
		} catch (ClassNotFoundException | NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			throw new BusinessServiceException(e);
		}

	}


	private void envoiNotificationDido(String identifiant, String typeObjet, String codeEvenement, TableDescription descriptionTable){
		if(descriptionTable==null || (descriptionTable!=null && verifierDiffusionTable(descriptionTable.getEntityClassName()))){
			try {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String nomUtilisateur = auth.getName();
				// L'envoi de notification est desactive si l'application fonctionne en local afin de ne pas noyer Dido de notifications
				if((!"LOC".equals(environnement)) ){
					if("DEV".equals(environnement) && "aparaneo".equals(nomUtilisateur)){
						LOGGER.info("Notification non envoyée car utilisation du login pour les tests d'acceptation en intégration");
					} else {
						NotificationDido notification = new NotificationDido();
						notification.setIdObjet(identifiant);
						notification.setTypeObjet(typeObjet);
						Date dateCreation = new Date();
						notification.setDateCreation(dateCreation);
						notification.setCodeEvenement(codeEvenement);
						notification.setIdCible("");
						this.jmsTemplate.convertAndSend(jmsTemplate.getDefaultDestination(), notification);
						LOGGER.info("Envoi d'une notification à Dido avec les valeurs suivantes." +
								" id = "+identifiant+" | typeObjet = "+typeObjet+" | dateCreation = "+dateCreation+" | codeEvenement = "+codeEvenement);
					}
				} else {
					LOGGER.info("Notification non envoyée car environnement de développement");
				}
			} catch(JmsException e){
				LOGGER.error("Erreur lors de l'envoi de la notification JMS",e);
			}
		} else {
			LOGGER.info("Table non notifiée car ne faisant pas partie des tables diffusables");
		}
		
	}

	/**
	 * Fournit pour les tables reprises de PARAMETRES le nom de la table dans PARAMETRES (type : LMTAYXXX ou GMTAMXXX) correspondant à cette table PARANEO (TA_YYY...ZZZ_LMTAYXXX ou TA_YYY...ZZZ_GMTAMXXX)
	 * Fournit pour les tables nouvelles (non reprises de PARAMETRES) le nom de la table dans PARANEO (TA_YYY...ZZZ)
	 * @param enregistrement
	 * @param description
	 * @return
	 */
	private String getTypeObjet(Object enregistrement, TableDescription description) {
		boolean lmtay = (description.getEntityClassName().toLowerCase().contains("lmtay"));
		boolean gmtam = (description.getEntityClassName().toLowerCase().contains("gmtam"));

		if (lmtay == true){
			return description.getEntityClassName().toLowerCase().substring(description.getEntityClassName().toLowerCase().indexOf("lmtay")).toUpperCase();}
		else if(gmtam == true) {
			return description.getEntityClassName().toLowerCase().substring(description.getEntityClassName().toLowerCase().indexOf("gmtam")).toUpperCase();
		} else {
			return description.getEntityClassName().toLowerCase().substring(description.getEntityClassName().toLowerCase().indexOf("ta")).toUpperCase();}
		}



	/**
	 * <p>A partir de l'enregistrement d'une table et des metadonnees de cette table fournit l'identifiant de l'enregistrement sous forme de String</p>
	 * @param enregistrement
	 * @param description
	 * @return
	 * @throws ClassNotFoundException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private String getIdentifiant(Object enregistrement, TableDescription description) throws ClassNotFoundException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		List<ColumnDescription> listeColonnes = description.getColumnList();
		Collections.sort(listeColonnes);
		List<String> clefsPrimaire = new ArrayList<String>();
		Class<?> classe = Class.forName(description.getEntityClassName());	// Instanciation de la classe Class
		for (ColumnDescription colonne : listeColonnes) {
			if(colonne.isPrimaryKey()){
				if(colonne.isForeignKey()){
					// On récupére le nom du champ de la classe
					String nomPropriete = colonne.getPropertyName();
					String nomColonne = colonne.getColumnName().toLowerCase();
					String[] champs = new String[2];
					champs[0] = nomPropriete;
					champs[1] = nomColonne;
					// On récupére le nom de la clef primaire de la table étrangére
					clefsPrimaire.add(StringUtils.join(champs,SEPARATEUR));
				} else {
					clefsPrimaire.add(colonne.getColumnName().toLowerCase());
				}
			}
		}


		String valeur = "";
		if(clefsPrimaire.size()==1){
			if(clefsPrimaire.get(0).contains(SEPARATEUR)){
				String[] composantsClefs = StringUtils.split(clefsPrimaire.get(0),SEPARATEUR);
				Field champ = classe.getDeclaredField(composantsClefs[0]);
				champ.setAccessible(true);
				Object tableEtrangere = champ.get(enregistrement);
				Class<?> classeTableEtrangere = tableEtrangere.getClass();
				Field champTableEtrangere = classeTableEtrangere.getDeclaredField(composantsClefs[1]);
				champTableEtrangere.setAccessible(true);
				valeur = (String)champTableEtrangere.get(tableEtrangere);
			} else {
				Field champ = classe.getDeclaredField(clefsPrimaire.get(0));
				champ.setAccessible(true);
				Object valeurNonTypee = champ.get(enregistrement);
				if(valeurNonTypee instanceof Date ){
					Date date = (Date) valeurNonTypee;
					SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
					valeur = sdf.format(date);
				} else {
					valeur = (String) champ.get(enregistrement);
				}
			}
		} else if(clefsPrimaire.size()>1){
			List<String> valeurs = new ArrayList<>();
			for (String clefPrimaire : clefsPrimaire) {
				if(clefPrimaire.contains(SEPARATEUR)){
					String[] composantsClefs = StringUtils.split(clefPrimaire,SEPARATEUR);
					Field champ = classe.getDeclaredField(composantsClefs[0]);
					champ.setAccessible(true);
					Object tableEtrangere = champ.get(enregistrement);
					Class<?> classeTableEtrangere = tableEtrangere.getClass();
					Field champTableEtrangere = classeTableEtrangere.getDeclaredField(composantsClefs[1]);
					champTableEtrangere.setAccessible(true);
					valeurs.add((String)champTableEtrangere.get(tableEtrangere));

				} else {
					Field champ = classe.getDeclaredField(clefPrimaire);		// Retourne le champ précisé, qu'il soit public ou non
					champ.setAccessible(true);									// Rend le champ accessible, bien qu'il soit privé
					// Ajout Mlacoste le 13/10/2015
					Object valeurNonTypee = champ.get(enregistrement);
					if(valeurNonTypee instanceof Date ){
						Date date = (Date) valeurNonTypee;
						SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);	// Pour formater une date suivant le format FORMAT_PARAMETRES
						valeurs.add((String) sdf.format(date));							// Formatte la date et ajoute le résultat au String valeurs
					} else {
						valeurs.add((String) champ.get(enregistrement));
					}
					//valeurs.add((String) champ.get(enregistrement));
				}
			}

			valeur = StringUtils.join(valeurs,SEPARATEUR);

		}

		return valeur;
	}

	@Override
	public void envoyerNotificationCreationSimple(String identifiant, String typeObjet) {
		this.envoiNotificationDido(identifiant, typeObjet, TYPE_CREATION, null);
	}

	@Override
	public void envoyerNotificationModificationSimple(String identifiant, String typeObjet) {
		this.envoiNotificationDido(identifiant, typeObjet, TYPE_MODIFICATION, null);
	}

	/**
	 * Verifie que la table en question est diffusable.
	 * Si c'est le cas on peut envoyer une notification
	 * @return boolean
	 */
	private boolean verifierDiffusionTable(String table){
		for (int i = 0; i < ParaneoConstantes.TABLES_NOTIFIEES.length; i++) {
			if(table.equals(ParaneoConstantes.TABLES_NOTIFIEES[i].getName())){
				return true;
			}
		}
		return false;
	}
}
