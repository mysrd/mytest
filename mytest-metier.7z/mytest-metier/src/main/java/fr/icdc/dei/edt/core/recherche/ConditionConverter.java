package fr.icdc.dei.edt.core.recherche;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import fr.icdc.dei.edt.core.converter.ConverterException;
import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;

public class ConditionConverter {

	/**
	 * Transforme un formulaire de recherche en une liste de conditions.
	 */
	public static List<Condition> formToCondition(Map<String, Object> formulaire, TableDescription table) throws ConverterException {

		List<Condition> conditions = new ArrayList<Condition>();

//		Iterator it = formulaire.entrySet().iterator();

		List<String> keysTraites = new ArrayList<String>();
		
		
		for (Map.Entry<String,Object> pairs : formulaire.entrySet()) {

		//while (it.hasNext()) {

			//Map.Entry pairs = (Map.Entry) it.next();

			String key = (String) pairs.getKey();

			int deuxPoints = key.indexOf(':');

			String columnName = key.substring(0, deuxPoints);

			if (!keysTraites.contains(columnName)) {

				keysTraites.add(columnName);


				String valueKey = columnName + ":value";
				String value1Key = columnName + ":value1";
				String searchOptionKey = columnName + ":search_opt";
				String notKey = columnName + ":not";

				String valueString = (String) formulaire.get(valueKey);

				if (valueString != null){
					valueString = valueString.trim();
				}

				String value1String = (String) formulaire.get(value1Key);
				if (value1String != null){
					value1String = value1String.trim();
				}

				Object value = null;
				Object value1 = null;
				String propertyName = null;

				ColumnDescription columnDescription = (ColumnDescription)table.getColumnNameColumnDescriptionMap().get(columnName);

				if(columnDescription.isForeignKey()){

					TableDescription foreignTable = columnDescription.getForeignTableDescription();

					ColumnDescription foreignColumnDescription = null;
					if (foreignTable.isCompositeId()){
						//Cas impossible à réaliser avec hibernate
						return null;
					}
					else {
						foreignColumnDescription = (ColumnDescription) foreignTable.getPropertyNameColumnDescriptionMap().get(foreignTable.getIdName());	
					}

					if (foreignColumnDescription != null){
						//Converter converter = foreignColumnDescription.getConfiguration().getConverter();

						String foreignPropertyName =  foreignColumnDescription.getPropertyName();

						propertyName =  columnDescription.getPropertyName() + "." + foreignPropertyName;

						//value = converter.getAsObject(valueString);
						//value1 =converter.getAsObject(value1String);
					}

				}
				//Colonne normale
				else {
					//Converter converter = columnDescription.getConfiguration().getConverter();
					propertyName = columnDescription.getPropertyName();
					//value = converter.getAsObject(valueString);
					//value1 = converter.getAsObject(value1String);
				}


				String searchOption = (String) formulaire.get(searchOptionKey);
				String notValue = (String) formulaire.get(notKey);

				boolean not = false;

				if (notValue != null && notValue.equalsIgnoreCase("on")) {
					not = true;
				}

				Condition condition = new Condition();
				condition.setPropertyName(propertyName);
				condition.setValue(value);
				condition.setValue1(value1);
				condition.setNot(not);
				condition.setSearchOption(searchOption);

				conditions.add(condition);
			}
		}
		return conditions;
	}

}
