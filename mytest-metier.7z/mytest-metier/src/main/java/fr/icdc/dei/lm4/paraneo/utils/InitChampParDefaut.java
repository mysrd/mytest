package fr.icdc.dei.lm4.paraneo.utils;

import java.lang.reflect.Field;

import org.apache.log4j.Logger;

import fr.icdc.dei.lm4.paraneo.entite.transverse.Horodatage;
import fr.icdc.dei.lm4.paraneo.entite.transverse.HorodatageCalendrier;
import fr.icdc.dei.lm4.paraneo.entite.transverse.HorodatageEffet;
import fr.icdc.dei.lm4.paraneo.entite.transverse.HorodatageEffetDevise;
import fr.icdc.dei.lm4.paraneo.entite.transverse.HorodatageFermeture;
import fr.icdc.dei.lm4.paraneo.entite.transverse.HorodatageOuvertureFermeture;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaComplementStructureBanqLmtay890;

public class InitChampParDefaut {

	private static final Logger LOGGER = Logger.getLogger(InitChampParDefaut.class);

	public InitChampParDefaut() {
	}

	/**
	 * Initialise des données :
	 * <ul>
	 * 	<li>Mise à 0 des champs de type Integer</li>
	 * <li>Horodatage</li>
	 * 	<li>HorodatageEffetDevise</li>
	 * <li>HorodatageEffet</li>
	 * <li>HorodatageCalendrier</li>
	 * <li>HorodatageFermeture</li>
	 * <li>HorodatageOuvertureFermeture</li>
	 * <li>TaComplementStructureBanqLmtay890</li>
	 * </ul>
	 * @param objetAInitialiser
	 */
	public void initialiser(Object objetAInitialiser, String nomUtilisateur) {
		Class descriptionDeLObjet = objetAInitialiser.getClass();			// Description de l'objet à initialiser (ses propriétés, ses méthodes, ...)
		Field[] listeDesChamps = descriptionDeLObjet.getDeclaredFields();	// Récupération de tous les champs de l'objet (public ou pas)
		if(objetAInitialiser instanceof Horodatage) {
			Horodatage enregistrement = (Horodatage) objetAInitialiser;
			enregistrement.initialiserDateCreation();
			enregistrement.mettreAJourDateModification();
			enregistrement.definirUtilisateur(nomUtilisateur);
			enregistrement.initialiserDateCloture();
		}

		if(objetAInitialiser instanceof HorodatageEffetDevise) {
			HorodatageEffetDevise enregistrement = (HorodatageEffetDevise) objetAInitialiser;
			enregistrement.initialiserDateDebutEffetDevise();
			enregistrement.initialiserDateFinEffetDevise();
			enregistrement.initialiserDateIn();
		}

		if(objetAInitialiser instanceof HorodatageEffet) {
			HorodatageEffet enregistrement = (HorodatageEffet) objetAInitialiser;
			enregistrement.initialiserDateDebutEffet();
			enregistrement.initialiserDateFinEffet();
		}

		if(objetAInitialiser instanceof HorodatageCalendrier) {
			HorodatageCalendrier enregistrement = (HorodatageCalendrier) objetAInitialiser;
			enregistrement.initialiserJourFerie();
			enregistrement.initialiserDateCreation();
			enregistrement.definirUtilisateur(nomUtilisateur);
		}

		if(objetAInitialiser instanceof HorodatageFermeture) {
			HorodatageFermeture enregistrement = (HorodatageFermeture) objetAInitialiser;
			enregistrement.initialiserDateFermeture();
		}

		if(objetAInitialiser instanceof HorodatageOuvertureFermeture) {
			HorodatageOuvertureFermeture enregistrement = (HorodatageOuvertureFermeture) objetAInitialiser;
			enregistrement.initialiserDateOuverture();
			enregistrement.initialiserDateFermeture();
		}

		if (objetAInitialiser instanceof TaComplementStructureBanqLmtay890) {
			TaComplementStructureBanqLmtay890 enregistrement = (TaComplementStructureBanqLmtay890) objetAInitialiser;
			enregistrement.initialiserCatptg("0");
			enregistrement.initialiserCdserv("00");
		}

		for (int i = 0; i < listeDesChamps.length; i++) {
			Field champ = listeDesChamps[i];
			if (champ.getType().equals(Integer.class)) {
				try {
					champ.setAccessible(true);				// Rend accessible ce champ bien qu'il soit privé (on en a besoin pour l'initialiser)
					champ.set(objetAInitialiser, 0);		// Initialisation à 0 du champ Integer
				} catch (IllegalArgumentException e) {
					LOGGER.error(e);
				} catch (IllegalAccessException e) {
					LOGGER.error(e);
				} finally {									// S'exécute, qu'il y ait une exception ou pas
					champ.setAccessible(false);
				}
			}
		}
	}
}
