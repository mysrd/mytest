/**
 * 
 */
package fr.icdc.dei.edt.core.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette classe permet de spécifier les données additionnelles concernant la table.
 * Elle comprend : 
 * - L'alias de la table : Nom afficher à l'utilisateur
 * - La pagination : nombre de ligne affichées lors de l'affichage par liste 
 * - L'identifiant du bean de validation
 * 
 * Cette annotation est facultative, si cette dernière n'est pas présente, le nom affiché sera
 * celui de la table en base, la pagination sera définie suivant un valeur par défaut, et aucun 
 * bean de validation ne sera attaché.
 * 
 * @author ffernandez-e
 *
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface TableMetaData {
	/**
	 * Nom désignant la table affiché à l'utilisateur
	 * @return
	 */
    String alias();
    
    /**
     * Nombre de ligne affiché dans l'affichage par liste
     * @return
     */
    int pagination();
    
    /**
     * Identifiant Spring du bean de validation attaché
     * @return
     */
    String validationBean();
}
