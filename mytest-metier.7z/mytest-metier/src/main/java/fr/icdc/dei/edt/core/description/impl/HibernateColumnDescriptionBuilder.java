package fr.icdc.dei.edt.core.description.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.Enumerated;

import org.hibernate.mapping.Column;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.SimpleValue;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.ColumnDescriptionBuilder;
import fr.icdc.dei.edt.core.description.TableDescription;

public class HibernateColumnDescriptionBuilder implements ColumnDescriptionBuilder {

	private Property property;

	private boolean isPrimaryKey;

	private TableDescription table;

	private boolean isCompositeId;

	private String idPropertyName;

	private Property parentProperty;

	private Set<String> classesNames;

	public HibernateColumnDescriptionBuilder(Property property, boolean isPrimaryKey, boolean isCompositeId, Property parentProperty, TableDescription table,
			Set<String> classes) {
		this.property = property;
		this.parentProperty = parentProperty;
		this.isPrimaryKey = isPrimaryKey;
		this.isCompositeId = isCompositeId;
		this.table = table;
		this.classesNames = classes;
	}

	public ColumnDescription build() {

		boolean autoPrimaryKey = false;

		String propertyName = null;

		String columnName = null;

		int length = 0;

		boolean nullable = false;

		Class<?> returnedClass = property.getType().getReturnedClass();
		String className = returnedClass.getName();

		propertyName = property.getName();

		if (isPrimaryKey) {
			SimpleValue v = (SimpleValue) property.getValue();
			idPropertyName = property.getName();
			String strategy = v.getIdentifierGeneratorStrategy();
			if (!(strategy == null || strategy.equals("assigned"))) {
				autoPrimaryKey = true;
			}

			if (isCompositeId) {
				propertyName = property.getName();
				idPropertyName = property.getName();
			}

		}

		Iterator<?> iterator = property.getColumnIterator();

		while (iterator.hasNext()) {
			org.hibernate.mapping.Column column = (org.hibernate.mapping.Column) iterator.next();
			columnName = column.getName();
			length = column.getLength();
			nullable = column.isNullable();
		}

		boolean isForeignKey = false;
		if (classesNames.contains(className)) {
			isForeignKey = true;
		}

		ColumnDescription columnDescription = new ColumnDescription(columnName, className, length, nullable, isPrimaryKey, autoPrimaryKey, isForeignKey,
				propertyName, idPropertyName, table, null, false);

		/*
		 * Converter converter = configuration.getConverter();
		 * 
		 * if(converter == null){ converter =
		 * createConverter(className,columnDescription ); }
		 */
		// columnDescription.getConfiguration().setConverter(converter);

		return columnDescription;
	}

	/**
	 * @return une liste de ColumnDescription.
	 * @throws NoSuchFieldException
	 * @throws ClassNotFoundException
	 * @throws SecurityException
	 */
	public List<ColumnDescription> build2() throws SecurityException, NoSuchFieldException {

		List<ColumnDescription> columnDescriptionList = new ArrayList<ColumnDescription>();

		String propertyName = null;

		Class<?> retunedClass = property.getType().getReturnedClass();

		String className = retunedClass.getName();

		propertyName = property.getName();

		boolean autoPrimaryKey = false;

		Iterator<?> iterator = property.getColumnIterator();

		// FIXME ici il y a un problàme à cause de Hibernate :
		// Si la propriété est de type component ou une clé étrangère composée
		// ...
		while (iterator.hasNext()) {
			org.hibernate.mapping.Column column = (org.hibernate.mapping.Column) iterator.next();
			columnDescriptionList.add(createColumDescription(column, propertyName, className, autoPrimaryKey));
		}

		return columnDescriptionList;
	}

	private ColumnDescription createColumDescription(Column column, String propertyName, String className, boolean autoPrimaryKey) throws SecurityException,
			NoSuchFieldException {

		Class<?> clazz = property.getPersistentClass().getMappedClass();
		Enumerated enumeratedAnnotation = getAnnotation(clazz, propertyName, Enumerated.class);

		boolean isEnumerated = Boolean.FALSE;

		if (enumeratedAnnotation != null) {
			isEnumerated = Boolean.TRUE;
		}

		// Utiliser à la place OneToManyType
		boolean isForeignKey = classesNames.contains(className);

		boolean nullable = column.isNullable();

		String name = column.getName();

		int length = column.getLength();

		ColumnDescription columnDescription = new ColumnDescription(name, className, length, nullable, isPrimaryKey, autoPrimaryKey, isForeignKey,
				propertyName, idPropertyName, table, null, isEnumerated);

		/*
		 * Converter converter = configuration.getConverter();
		 * 
		 * if(converter == null){ converter = createConverter(className,
		 * columnDescription); }
		 */

		// columnDescription.getConfiguration().setConverter(converter);

		return columnDescription;
	}

	/*
	 * public static Converter createConverter(String targetClass,
	 * ColumnDescription columnDescription) { Converter converter = null; String
	 * label = columnDescription.getConfiguration().getLabel(); if
	 * (columnDescription.isForeignKey()){ //TODO code incomplet converter =
	 * null; }
	 * 
	 * else if ("java.lang.Integer".equals(targetClass) ) { converter = new
	 * IntegerConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.math.BigDecimal".equals(targetClass) ) { converter = new
	 * BigDecimalConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Boolean".equals(targetClass) ) { converter = new
	 * BooleanConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Byte".equals(targetClass) ) { converter = new
	 * ByteConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Character".equals(targetClass) ) { converter = new
	 * CharacterConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.util.Date".equals(targetClass) ) { converter = new
	 * DateTimeConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Double".equals(targetClass) ) { converter = new
	 * DoubleConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Float".equals(targetClass) ) { converter = new
	 * FloatConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Integer".equals(targetClass) ) { converter = new
	 * IntegerConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Long".equals(targetClass) ) { converter = new
	 * LongConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Number".equals(targetClass) ) { converter = new
	 * NumberConverter(); converter.setLabel(label); }
	 * 
	 * else if ("java.lang.Short".equals(targetClass) ) { converter = new
	 * NumberConverter(); converter.setLabel(label); } else { converter = new
	 * DefaultConverter(); converter.setLabel(label); } return converter; }
	 */

	private <T, U extends java.lang.annotation.Annotation> U getAnnotation(Class<T> clazz, String propertyName, Class<U> annotationClazz)
			throws SecurityException, NoSuchFieldException {
		Field property = clazz.getDeclaredField(propertyName);
		return (U) property.getAnnotation(annotationClazz);
	}

}
