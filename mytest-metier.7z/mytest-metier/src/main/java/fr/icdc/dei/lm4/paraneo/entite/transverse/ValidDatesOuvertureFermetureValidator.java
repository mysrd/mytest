package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidDatesOuvertureFermetureValidator implements ConstraintValidator<ValidDatesOuvertureFermeture, Object>{

	@Override
	public void initialize(ValidDatesOuvertureFermeture constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if(value instanceof HorodatageOuvertureFermeture){
			HorodatageOuvertureFermeture valeurCastee = (HorodatageOuvertureFermeture) value;
			Date dateOuverture = valeurCastee.getYdo000();
			Date dateFermeture = valeurCastee.getYdf000();
			if (dateOuverture.after(dateFermeture)){
				return false;
			}
			else{
				return true;
			}
		}
		return false;
	}

}
