package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.math.BigDecimal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
* Verifie que l'entier (décimal avec fraction dans la BDD) est composé uniquement des caractères autorisés quelle que soit la zone de saisie
* @author porsini
*
*/
public class CaracAutorisesDecimalAvecFractionValidator implements ConstraintValidator<CaracAutorisesDecimalAvecFraction, BigDecimal> {

	private int nbMax;
	private int nbDec;

	@Override
    public void initialize(CaracAutorisesDecimalAvecFraction constraintAnnotation) {
 	   this.nbMax = constraintAnnotation.nbMax();
 	   this.nbDec= constraintAnnotation.nbDec();
    }

    @Override
    public boolean isValid(BigDecimal value, ConstraintValidatorContext context) {
    	if(value==null){
    		return false;
    	}
    	String monIntEnString = String.valueOf(value);
    	if (monIntEnString != null) {
    		monIntEnString = monIntEnString.trim();
    	   if (monIntEnString.length() > 0) {
    		   int precision = value.precision();
    		   int nbScale = value.scale();
    		   if ((precision - nbScale) >= (nbMax - nbDec)) {		// Partie entière trop grande
    			   return false;
    		   }
    		   if (nbScale > nbDec) {								// Nb de décimales trop grand
    			   return false;
    		   }
    		   return true;
    	   }
    	   else{
    		   return false;
    	   }
    	}
    	else{
    	   return false;
    	}
    }
}
