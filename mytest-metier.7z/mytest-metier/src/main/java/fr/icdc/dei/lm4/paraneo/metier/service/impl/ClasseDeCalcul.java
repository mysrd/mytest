package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;


public interface ClasseDeCalcul {

	String calculer(String parametre) throws BusinessServiceException;
}
