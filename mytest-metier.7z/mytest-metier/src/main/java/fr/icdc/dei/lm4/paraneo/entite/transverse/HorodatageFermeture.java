package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

public abstract class HorodatageFermeture extends Horodatage {

	public abstract Date getYdf000();

	public abstract void setYdf000(Date ydf000);

	public void initialiserDateFermeture(){
		this.setYdf000(ParaneoUtils.obtenirDateMaximum());
	}


	@XmlElement(name="ydf000")
	public String getDateFermeture(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdf000());

	}

}
