package fr.icdc.dei.lm4.paraneo.metier.service;

public interface MailService {
	public void envoyerMail(String objet, String texte);
	public void envoyerMailAvecPieceJointe(String objet, String texte, byte[] pieceJointe, String nomPieceJointe);
}
