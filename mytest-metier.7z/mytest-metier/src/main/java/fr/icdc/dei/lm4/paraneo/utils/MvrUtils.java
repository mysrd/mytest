package fr.icdc.dei.lm4.paraneo.utils;

import java.util.List;

/**
 * @author ffernandez-e
 *
 */
public class MvrUtils {



	/**
	 * M�thode utilitaire de liste pour récupérer l'objet de la liste en
	 * fonction d'un objet de référence
	 *
	 * @param <T>
	 *            Type des objets de la liste
	 * @param objects
	 *            liste d'objets de type T
	 * @param objectRef
	 * @return l'objet de la liste correspondant
	 * @throws IndexOutOfBoundsException
	 */
	public static <T> T getObjectInList(List<T> objects, T objectRef) throws IndexOutOfBoundsException {
		int objectIndex = objects.indexOf(objectRef);
		return objects.get(objectIndex);
	}


}

