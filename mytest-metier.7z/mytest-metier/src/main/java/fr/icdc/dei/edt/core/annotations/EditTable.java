/**
 * 
 */
package fr.icdc.dei.edt.core.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette annotation permet de marquer une entité comme étant gérée par EditTable.
 * Si cette annotation n'est pas présente sur l'entité déclarée, cette dernière ne sera
 * pas affichée dans la liste de tables.
 * @author ffernandez-e
 *
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface EditTable {

}
