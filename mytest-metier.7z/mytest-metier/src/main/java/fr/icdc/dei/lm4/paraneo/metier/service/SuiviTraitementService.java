package fr.icdc.dei.lm4.paraneo.metier.service;

import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

/**
 * Service fournissant des méthodes pour suivre la progression d'un traitement
 * @author porsini mlacoste
 *
 */
public interface SuiviTraitementService {
	/**
	 * Signale le début d'un traitement ayant le code fourni
	 * La date de début correspondra à la date système au moment de l'appel
	 * Retourne la date de début
	 * @param codeTraitement
	 * @return
	 * @throws BusinessServiceException
	 */
	public Integer signalerDebutTraitement(String codeTraitement, String empreinte) throws BusinessServiceException;
	
	/**
	 * Signale que le traitement avec le code et la date de debut fourni est terminé
	 * La date de fin du traitement correspondra à la date système au moment de l'appel
	 * @param codeTraitement
	 * @param dateDeDebut
	 * @throws BusinessServiceException
	 */
	public void signalerFinTraitement(String codeTraitement, Integer identifiantTraitement, EtatTraitement etatTraitement) throws BusinessServiceException;
	
	/**
	 * Retourne true si un traitement est en cours pour le code traitement fourni
	 * Retourne false s'il n'y a pas de traitement en cours pour le code fourni
	 * @param codeTraitement
	 * @return
	 */
	public boolean isTraitementEnCours(String codeTraitement) throws BusinessServiceException;

	/**
	 * Retourne true si le fichier a deja ete traite auparavant
	 * @param empreinte
	 * @return
	 */
	public boolean isEmpreinteDejaTraitee(String codeTraitement, String empreinte);

}
