package fr.icdc.dei.edt.persistance.service;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.core.recherche.Condition;
import fr.icdc.dei.edt.core.recherche.OrderBy;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesInputAjax;

/**
 * Persistence Service g�n�rique.
 *
 * @author abdennebi
 * @author daboulkheir-e
 *
 */
public interface GenericPersistenceService{

	/**
	 * Récupère la liste des tables disponibles.
	 *
	 * @return Collection d'objets <code>TableDescription</code>, si il n'y a
	 *         aucun élément elle retourne une liste vide.
	 */
	List<TableDescription> selectListTables() throws BusinessServiceException;

	/**
	 * Trouve tous les enregistrements d'une table.
	 */
	List<Object> findAll(String className) throws BusinessServiceException;

	/**
	 * Trouve un enregistrement en fonction de son id.
	 */
	Object findById(Class<?> clazz, Serializable id) throws BusinessServiceException;

	/**
	 * Crée un objet persistant.
	 */
	void create(Object obj) throws BusinessServiceException;

	/**
	 * Supprime un objet persistant.
	 */
	void delete(Object obj) throws BusinessServiceException;

	/**
	 * Met à jour un objet persistant.
	 */
	void update(Object obj) throws BusinessServiceException;

	List<Object> findAll(Class<?> clazz, int firstResult, int maxResults) throws BusinessServiceException;

	/**
	 *
	 * @param persistentClass L'entité à rechercher
	 * @return Le nombre total des objets.
	 * @throws BusinessServiceException
	 *             si un problème lié la persistance se produit
	 */
	int count(Class<?> persistentClass) throws BusinessServiceException;

	int countForConditions(Class<?> persistentClass, List<Condition> conditions) throws BusinessServiceException;

	/**
	 *
	 * @param persistentClass L'entité à rechercher
	 * @param conditions Liste d'objets
	 *            {@link fr.icdc.dei.edt.core.recherche.Condition}
	 * @param firstResult L'index de début de la recherche
	 * @param maxResults Le nombre d'objets à chercher
	 * @param orderByList TODO
	 * @see fr.icdc.dei.edt.core.recherche.Condition
	 * @return Liste de objets correspondants
	 * @throws BusinessServiceException
	 *             si un problème lié la persistance se produit
	 */
	List<Object> findAll(Class<?> persistentClass, List<Condition> conditions, int firstResult,
			Integer maxResults, List<OrderBy> orderByList) throws BusinessServiceException;

	/**
	 *
	 * @param className L'entité à rechercher
	 * @param conditionsListe d'objets
	 *            {@link fr.icdc.dei.edt.core.recherche.Condition}
	 * @return Liste de objets correspondants
	 * @throws BusinessServiceException
	 */
	List<Object> findAll(String className, List<Condition> conditions) throws BusinessServiceException;

	List<String> getColumnsOrder(String tableName);

	List<TaLibelleColonneTable> getAllLibelleColonneTable() throws BusinessServiceException;

	Object findByMultiCriteria(Class<?> classeEntite,List<String> clefsPrimaire, List<Object> valeurs);

	boolean verifUniciteJourFerieLegal(Date dateRecherchee);

	boolean verifUniciteJourFerieLegal602(String nomTableTestee, Date dateRecherchee);

	boolean verifUniciteCodePays501(String cpay, String valeurDuChamp, String nomChamp);

	boolean verifUniciteCodeDeviseIsoNum502(String cdev, String valeurDuChamp);

	boolean verifUniciteCoupleCodesBureauEtService(String cung, String cburo, String cdserv);

	boolean verifUniciteCodePole(String cung, String cpole);

	List<Object> requeteDatatables(Integer draw, Integer start, Integer length, DatatablesInputAjax parametresStructures, String table) throws BusinessServiceException;

	Integer countDatatableFiltre(Class<?> class1, DatatablesInputAjax parametresStructures, TableDescription descriptionTable);

	public byte[] getStreamingMYSQLResult(String className,List<String> enTetesCode, Map<String,String> enTetesCodeEtLibelle,List<String> listeFetch ) throws IllegalArgumentException, IllegalAccessException, NoSuchMethodException, SecurityException, InvocationTargetException, IOException;

	int countActif(Class<?> clazz) throws BusinessServiceException;

	int countClos(Class<?> clazz) throws BusinessServiceException;

}
