/**
 * 
 */
package fr.icdc.dei.edt.core.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette annotation permet de spécifier le nom du bean de convertion utilisé pour les 
 * transformation String <-> Objet
 * @author ffernandez-e
 *
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ColumnConverter {
	/**
	 * Identifiant spring du bean à utiliser pour réaliser la convertion
	 * @return
	 */
	String converterBean();
}
