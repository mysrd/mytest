package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;

/**
* Verifie que le couple code bureau et code service saisi n'existe pas deja dans la table
* @author porsini
*
*/
public class UniciteCoupleCodesBureauEtService890Validator extends DatabaseAccess implements ConstraintValidator<UniciteCoupleCodesBureauEtService890, TaComplementStructureBanqLmtay890> {
	@Autowired
	private ReferentielBusinessService referentielService;

	@Override
    public void initialize(UniciteCoupleCodesBureauEtService890 constraintAnnotation) {
    }

    @Override
    public boolean isValid(TaComplementStructureBanqLmtay890 classeValidee, ConstraintValidatorContext context) {

    	String cburo = null;
    	String cdserv = null;
   		cburo = classeValidee.getCburo();
   		cdserv = classeValidee.getCdserv();
   		if (StringUtils.isBlank(cburo) && "00".equals(cdserv)){		// Le champ CBURO peut être à blanc et le champ CDSERV peut être égal à "00". Dans ce cas, on ne les teste pas.
   			return true;
   		}

    	return this.referentielService.verifUniciteCoupleCodesBureauEtService(classeValidee.getCung(), cburo, cdserv);
    }
}
