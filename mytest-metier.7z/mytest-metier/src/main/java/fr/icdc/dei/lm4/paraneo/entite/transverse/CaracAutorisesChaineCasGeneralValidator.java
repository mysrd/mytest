package fr.icdc.dei.lm4.paraneo.entite.transverse;
import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Verifie que le string est compose uniquement des caracteres autorises quelle que soit la zone de saisie
 * @author porsini
 *
 */
public class CaracAutorisesChaineCasGeneralValidator implements ConstraintValidator<CaracAutorisesChaineCasGeneral, String> {

	@Override
	public void initialize(CaracAutorisesChaineCasGeneral constraintAnnotation) {
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
        List<Character> valeursAutorisees = new ArrayList<>();
        valeursAutorisees.add('A');
        valeursAutorisees.add('B');
        valeursAutorisees.add('C');
        valeursAutorisees.add('D');
        valeursAutorisees.add('E');
        valeursAutorisees.add('F');
        valeursAutorisees.add('G');
        valeursAutorisees.add('H');
        valeursAutorisees.add('I');
        valeursAutorisees.add('J');
        valeursAutorisees.add('K');
        valeursAutorisees.add('L');
        valeursAutorisees.add('M');
        valeursAutorisees.add('N');
        valeursAutorisees.add('O');
        valeursAutorisees.add('P');
        valeursAutorisees.add('Q');
        valeursAutorisees.add('R');
        valeursAutorisees.add('S');
        valeursAutorisees.add('T');
        valeursAutorisees.add('U');
        valeursAutorisees.add('V');
        valeursAutorisees.add('W');
        valeursAutorisees.add('X');
        valeursAutorisees.add('Y');
        valeursAutorisees.add('Z');
        valeursAutorisees.add('0');
        valeursAutorisees.add('1');
        valeursAutorisees.add('2');
        valeursAutorisees.add('3');
        valeursAutorisees.add('4');
        valeursAutorisees.add('5');
        valeursAutorisees.add('6');
        valeursAutorisees.add('7');
        valeursAutorisees.add('8');
        valeursAutorisees.add('9');
        valeursAutorisees.add(' ');
        valeursAutorisees.add('\'');
        valeursAutorisees.add('-');
        valeursAutorisees.add('.');
        valeursAutorisees.add(',');
        valeursAutorisees.add('/');
        valeursAutorisees.add('_');
        valeursAutorisees.add('(');
        valeursAutorisees.add(')');

		for (int i = 0; i < value.length(); i++) {
            if(!valeursAutorisees.contains(value.charAt(i))){
				return false;
			}
		}
		return true;
	}

}
