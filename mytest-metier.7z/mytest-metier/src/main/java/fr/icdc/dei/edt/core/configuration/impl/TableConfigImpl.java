package fr.icdc.dei.edt.core.configuration.impl;

import java.io.Serializable;
import java.util.List;

/**
 * Objet qui contient la configuration d'une table issue du fichier XML.
 * 
 * @author M Abdennebi
 * @version 1.0
 * @since 1.0
 */
public class TableConfigImpl implements Serializable {

	private boolean addNewRecordOp;

	private boolean deleteRecordOp;

	private boolean editRecordOp;

	private boolean viewRecordOp;

	/**
	 * Le nom physique de la table.
	 */
	private String name;

	/**
	 * Le nom de la table tel qu'il sera afffiché.
	 */
	private String label;

	/**
	 * Le nombre de ligne par page qu'on souhaite afficher.
	 */
	private int pagination;

	//private Class entityClass;

	/**
	 * @return the entityClass
	 */
	/*public Class getEntityClass() {
		return entityClass;
	}*/

	/**
	 * @param entityClass
	 *            the entityClass to set
	 */
	/*public void setEntityClass(Class entityClass) {
		this.entityClass = entityClass;
	}*/

	private List<String> validationFiles;

	private String validationFormName;

	// ~~ Constructeur
	public TableConfigImpl() {

	}

	// ~~ Getters & Setters
	/*
	 * (non-Javadoc)
	 * 
	 * @see fr.icdc.dei.edt.core.configuration.TableConfiguration#getLabel()
	 */
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	/*
	 * (non-Javadoc)s
	 * 
	 * @see fr.icdc.dei.edt.core.configuration.TableConfiguration#getName()
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPagination(int pagination) {
		this.pagination = pagination;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * fr.icdc.dei.edt.core.configuration.TableConfiguration#getPagination()
	 */
	public int getPagination() {
		return pagination;
	}

	public void setValidationFiles(List<String> validationFiles) {
		this.validationFiles = validationFiles;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * fr.icdc.dei.edt.core.configuration.TableConfiguration#getValidationFiles
	 * ()
	 */
	public List<String> getValidationFiles() {
		return validationFiles;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * fr.icdc.dei.edt.core.configuration.TableConfiguration#getValidationFormName
	 * ()
	 */
	public String getValidationFormName() {
		return this.validationFormName;
	}

	public void setValidationFormName(String validationFormName) {
		this.validationFormName = validationFormName;
	}

	public Object clone() {
		TableConfigImpl clone = new TableConfigImpl();

		clone.label = label;
		clone.name = name;
		clone.pagination = pagination;

		clone.addNewRecordOp = addNewRecordOp;
		clone.deleteRecordOp = deleteRecordOp;
		clone.editRecordOp = editRecordOp;
		clone.viewRecordOp = viewRecordOp;

		clone.setValidationFiles(validationFiles);
		clone.setValidationFormName(validationFormName);

		return clone;
	}

	public boolean getAddNewRecordOp() {
		return addNewRecordOp;
	}

	public void setAddNewRecordOp(boolean addNewRecordOp) {
		this.addNewRecordOp = addNewRecordOp;
	}

	public boolean getDeleteRecordOp() {
		return deleteRecordOp;
	}

	public void setDeleteRecordOp(boolean deleteRecordOp) {
		this.deleteRecordOp = deleteRecordOp;
	}

	public boolean getEditRecordOp() {
		return editRecordOp;
	}

	public void setEditRecordOp(boolean editRecordOp) {
		this.editRecordOp = editRecordOp;
	}

	public boolean getViewRecordOp() {
		return viewRecordOp;
	}

	public void setViewRecordOp(boolean viewRecordOp) {
		this.viewRecordOp = viewRecordOp;
	}

}
