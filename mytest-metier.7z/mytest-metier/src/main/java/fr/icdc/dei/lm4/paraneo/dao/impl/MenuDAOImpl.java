package fr.icdc.dei.lm4.paraneo.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import fr.icdc.dei.lm4.paraneo.critere.CritereRechercheMenu;
import fr.icdc.dei.lm4.paraneo.dao.MenuDAO;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Menu;
import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;

/**
 * @author adhieb-e
 *
 */
@SuppressWarnings("unchecked")
@Repository("menuDAO")
public class MenuDAOImpl extends AbstractDAOBase<Menu, String> implements MenuDAO {

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * fr.icdc.dei.mv1.mvr.dao.MenuDAO#buildMenus(fr.icdc.dei.mv1.mvr.critere
	 * .CritereRechercheMenu)
	 */
	@Override
	public List<Menu> buildMenus(CritereRechercheMenu critere) {
		Session session = this.getSessionFactory().getCurrentSession();

		// Liste des paramétres de la requete
		HashMap<String, String> parameters = new HashMap<String, String>();

		// Constructeur de la requete
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("select distinct menu from Menu as menu left join menu.parent as noeudParent left join fetch menu.noeudsEnfants as noeuds");
		queryBuilder.append(" where noeudParent.codeMenu = '" + ParaneoConstantes.CODE_MENU_SERVICES + "' and menu.valide = true");

		session.enableFilter("valideFilter").setParameter("valide", Boolean.TRUE);

		// Si un critére de strcuture est renseigné
		if (StringUtils.isNotBlank(critere.getStructure())) {
			String structure = "%" + critere.getStructure() + "%";
			queryBuilder.append(" and menu.structures like (:structure)");

			session.enableFilter("structuresFilter").setParameter("structure", structure);

			// TODO : Tester sans le paramétre
			parameters.put("structure", structure);
		}

		queryBuilder.append(" order by menu.ordre asc");

		Query q = session.createQuery(queryBuilder.toString());

		// Ajout des paramétres
		for (Map.Entry<String, String> entry : parameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}

		List<Menu> result = q.list();
		return result;

	}
}
