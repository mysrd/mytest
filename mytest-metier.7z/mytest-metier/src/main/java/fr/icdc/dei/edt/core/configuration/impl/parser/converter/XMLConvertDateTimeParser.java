package fr.icdc.dei.edt.core.configuration.impl.parser.converter;

import org.dom4j.Node;

import fr.icdc.dei.edt.core.configuration.parser.converter.ConvertDateTimeParser;

public class XMLConvertDateTimeParser implements ConvertDateTimeParser {

	private final Node converterNode;
	
	public XMLConvertDateTimeParser(Node converterNode) {
		this.converterNode = converterNode;
	}
	
	public String getDateStyle() {
		return converterNode.valueOf("@dateStyle");
	}

	public String getLocale() {
		return converterNode.valueOf("@locale");
	}

	public String getPattern() {
		return converterNode.valueOf("@pattern");
	}

	public String getTimeZone() {
		return converterNode.valueOf("@timeZone");
	}

	public String getType() {
		return converterNode.valueOf("@type");
	}

}
