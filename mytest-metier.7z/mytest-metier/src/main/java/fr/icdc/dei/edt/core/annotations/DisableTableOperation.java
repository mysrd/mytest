/**
 * 
 */
package fr.icdc.dei.edt.core.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette annotation permet de prohiber des opérations relatives à la table.
 * Les opérations sont énumérées dans fr.icdc.dei.edt.core.annotations.TableOperationsEnum
 * 
 * @author ffernandez-e
 *
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface DisableTableOperation {
	/**
	 * Liste des opération prohibées
	 * @return
	 */
	TableOperationsEnum[] operations();
}
