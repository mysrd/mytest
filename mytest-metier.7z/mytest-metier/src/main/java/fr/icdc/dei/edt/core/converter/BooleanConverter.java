package fr.icdc.dei.edt.core.converter;

public class BooleanConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.BooleanConverter";

	public BooleanConverter() {
	}

	public Object getAsObject(String value) {

		if (value != null) {
			value = value.trim();
			if (value.length() > 0) {
				//try {
					return Boolean.valueOf(value);
				/*} catch (Exception e) {
					throw new ConverterException(CONVERSION_MESSAGE_ID, e);
				}*/
			}
		}
		return null;
	}

	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}
		//try {
			return ((Boolean) value).toString();
		/*} catch (Exception e) {
			throw new ConverterException(e);
		}*/
	}

	private String label;

	public void setLabel(String label) {
		this.label = label;
	}
}
