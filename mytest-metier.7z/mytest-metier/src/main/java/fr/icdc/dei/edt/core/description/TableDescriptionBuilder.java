package fr.icdc.dei.edt.core.description;

public interface TableDescriptionBuilder {

	TableDescription build() throws SecurityException, NoSuchFieldException;
}
