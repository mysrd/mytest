package fr.icdc.dei.edt.core.converter;

public class DefaultConverter implements Converter {

	public Object getAsObject(String value) throws ConverterException {
		return value;
	}

	public String getAsString(Object value) throws ConverterException {
		if (value == null) return "";
		return value.toString();
	}
	
	private String label;
	
	public void setLabel(String label) {
		this.label = label;	
	}

}
