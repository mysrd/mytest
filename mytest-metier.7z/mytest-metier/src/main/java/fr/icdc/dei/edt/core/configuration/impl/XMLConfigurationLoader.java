package fr.icdc.dei.edt.core.configuration.impl;

import java.io.FileNotFoundException;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;

import fr.icdc.dei.edt.core.configuration.ConfigurationException;
import fr.icdc.dei.edt.core.configuration.ConfigurationLoader;
import fr.icdc.dei.edt.core.configuration.impl.parser.AnnotationTableParser;
import fr.icdc.dei.edt.core.configuration.impl.parser.Dom4jUtil;
import fr.icdc.dei.edt.core.configuration.impl.parser.XMLTableConfigurationParser;
import fr.icdc.dei.edt.core.configuration.parser.TableConfigParser;
import fr.icdc.dei.edt.core.exception.EditTableException;

/**
 * Cette classe permet de charger toute la configuration XML.
 * 
 * @author abdennebi
 * 
 */
public class XMLConfigurationLoader implements ConfigurationLoader {

	private final TableConfigParser tableConfigurationParser;

	/**
	 * Représente le fichier XML global (edittables-conf.xml).
	 */
	private final Document editTablesConfDocument;

	/**
	 * Constructeur package protected.
	 * 
	 * @param filename
	 *            Le chemin complet vers le fichier de configuration principal
	 *            de EditTables.
	 * @throws EditTableException
	 */
	public XMLConfigurationLoader(String filename) throws EditTableException {
		try {
			editTablesConfDocument = Dom4jUtil.parse(filename);
		} catch (FileNotFoundException e) {
			throw new ConfigurationException(e);
		} catch (DocumentException e) {
			throw new ConfigurationException(e);
		}

		tableConfigurationParser = new XMLTableConfigurationParser(editTablesConfDocument);

		Node tablesNode = this.editTablesConfDocument.selectSingleNode("//tables");

		String className = tablesNode.valueOf("@defaultConfig");

		Class defaultConfigurationClass;
		try {
			defaultConfigurationClass = Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new ConfigurationException("Cannot find default configuration class : '" + className + "'", e);
		}

		AnnotationTableParser parser = new AnnotationTableParser(FileNotFoundException.class);

		AnnotationTableParser.setDefaultConfig(defaultConfigurationClass);

	}

	public Map<String, TableConfigImpl> getTableConfigurations() {
		return tableConfigurationParser.getTableConfigurations();
	}
}
