package fr.icdc.dei.lm4.paraneo.utils;

import java.util.Collection;
import java.util.List;

public class DatatablesOutputAjax {
	/**
	 * Contient les enregistrements sous forme d'entite Hibernate
	 */
	private List<Object> enregistrementsBruts;
	
	/**
	 * Decoule des enregistrements bruts
	 * Contient les enregistrements alimentes meme pour les clefs etrangeres
	 */
	private List<Collection<Object>> enregistrementsAlimentes;

	public List<Object> getEnregistrementsBruts() {
		return enregistrementsBruts;
	}

	public void setEnregistrementsBruts(List<Object> enregistrementsBruts) {
		this.enregistrementsBruts = enregistrementsBruts;
	}

	public List<Collection<Object>> getEnregistrementsAlimentes() {
		return enregistrementsAlimentes;
	}

	public void setEnregistrementsAlimentes(
			List<Collection<Object>> enregistrementsAlimentes) {
		this.enregistrementsAlimentes = enregistrementsAlimentes;
	}
	
	
	
}
