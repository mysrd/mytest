package fr.icdc.dei.edt.core.description;

import java.io.Serializable;

/**
 * Objet qui représente les informations d'une propriété (attribut d'une entité
 * persistante)
 *
 * @author abdennebi
 *
 */

public class ColumnDescription implements Serializable, Comparable {

	/**
	 * Le nom physique de la colonne.
	 *
	 * Exemple : id_utilisateur
	 */
	private String columnName;

	/**
	 * Le nom de la propriété du POJO.
	 *
	 * Exemple : id
	 */
	private String propertyName;

	/**
	 * Le nom de la classe qui correspond à la propriété.
	 *
	 * Exemple : Pour une clé simple : java.lang.Integer Pour une clé composée :
	 * fr.icdc.sample.entities.UtilisateurId
	 */
	private String className;

	/**
	 * La taille de la colonne.
	 */
	private int length;

	/**
	 * La colonne est une clé primaire ou elle fait partie d'une clé primaire
	 * composée.
	 */
	private boolean primaryKey;

	/**
	 * La clé primaire est générée automatiquement.
	 */
	private boolean autoPrimaryKey;

	/**
	 * Le nom de la propriété si elle faisait partie de la clé composée. Elle
	 * est sous le pattern suivant : nomProprieteParent.nomPropriete
	 *
	 * Exemple : utilisateurId.nom UtilisateurId.prenom
	 *
	 * utilisateurId est la propriété parent nom est la propriété
	 */
	private String idPropertyName;

	private String idRealName;

	/**
	 * Permet de dire si cette propriété est nullable.
	 */
	private boolean nullable;

	/**
	 * Permet de dire si cette propriété est une clé étrangère.
	 */
	private boolean foreignKey;

	/**
	 * Permet de dire si la colonne est une Enum ou non.
	 */
	private boolean enumeration;

	/**
	 * TableDescription à laquelle appartient cet objet.
	 */
	private TableDescription table;

	/**
	 * Si cette colonne est une clé étrangère, c'est la table représentant cette
	 * clé étrangère.
	 */
	private TableDescription foreignTableDescription;

	/**
	 * La configuration XML de cette colonne.
	 */
	// private ColumnConfigImpl configuration;

	public ColumnDescription() {

	}

	public ColumnDescription(String columnName, String className, int length, boolean nullable, boolean isPrimaryKey, boolean autoPrimaryKey,
			boolean foreignKey, String propertyName, String idPropertyName, TableDescription table, String idRealName, boolean isEnumerated) {

		// this.configuration = configuration;

		this.columnName = columnName;

		this.primaryKey = isPrimaryKey;

		this.className = className;

		this.length = length;

		this.nullable = nullable;

		this.table = table;

		this.propertyName = propertyName;

		this.idPropertyName = idPropertyName;

		this.autoPrimaryKey = autoPrimaryKey;

		this.foreignKey = foreignKey;

		this.idRealName = idRealName;

		this.enumeration = isEnumerated;
	}

	/**
	 * @return the columnName
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * @param columnName
	 *            the columnName to set
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * @return the propertyName
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * @param propertyName
	 *            the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	/**
	 * @return the className
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * @param className
	 *            the className to set
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 * @return the length
	 */
	public int getLength() {
		return length;
	}

	/**
	 * @param length
	 *            the length to set
	 */
	public void setLength(int length) {
		this.length = length;
	}

	/**
	 * @return the primaryKey
	 */
	public boolean isPrimaryKey() {
		return primaryKey;
	}

	/**
	 * @param primaryKey
	 *            the primaryKey to set
	 */
	public void setPrimaryKey(boolean primaryKey) {
		this.primaryKey = primaryKey;
	}

	/**
	 * @return the autoPrimaryKey
	 */
	public boolean isAutoPrimaryKey() {
		return autoPrimaryKey;
	}

	/**
	 * @param autoPrimaryKey
	 *            the autoPrimaryKey to set
	 */
	public void setAutoPrimaryKey(boolean autoPrimaryKey) {
		this.autoPrimaryKey = autoPrimaryKey;
	}

	/**
	 * @return the idPropertyName
	 */
	public String getIdPropertyName() {
		return idPropertyName;
	}

	/**
	 * @param idPropertyName
	 *            the idPropertyName to set
	 */
	public void setIdPropertyName(String idPropertyName) {
		this.idPropertyName = idPropertyName;
	}

	/**
	 * @return the idRealName
	 */
	public String getIdRealName() {
		return idRealName;
	}

	/**
	 * @param idRealName
	 *            the idRealName to set
	 */
	public void setIdRealName(String idRealName) {
		this.idRealName = idRealName;
	}

	/**
	 * @return the nullable
	 */
	public boolean isNullable() {
		return nullable;
	}

	/**
	 * @param nullable
	 *            the nullable to set
	 */
	public void setNullable(boolean nullable) {
		this.nullable = nullable;
	}

	/**
	 * @return the foreignKey
	 */
	public boolean isForeignKey() {
		return foreignKey;
	}

	/**
	 * @param foreignKey
	 *            the foreignKey to set
	 */
	public void setForeignKey(boolean foreignKey) {
		this.foreignKey = foreignKey;
	}

	/**
	 * @return the enumeration
	 */
	public boolean isEnumeration() {
		return enumeration;
	}

	/**
	 * @param enumeration the enumeration to set
	 */
	public void setEnumeration(boolean enumeration) {
		this.enumeration = enumeration;
	}

	/**
	 * @return the table
	 */
	public TableDescription getTable() {
		return table;
	}

	/**
	 * @param table
	 *            the table to set
	 */
	public void setTable(TableDescription table) {
		this.table = table;
	}

	/**
	 * @return the foreignTableDescription
	 */
	public TableDescription getForeignTableDescription() {
		return foreignTableDescription;
	}

	/**
	 * @param foreignTableDescription
	 *            the foreignTableDescription to set
	 */
	public void setForeignTableDescription(TableDescription foreignTableDescription) {
		this.foreignTableDescription = foreignTableDescription;
	}

	@Override
	public int compareTo(Object o) {
		ColumnDescription otherColumn = (ColumnDescription) o;
		if(o.equals(this))
			return 0;
		return this.getColumnName().compareTo(otherColumn.getColumnName());
	}

	/**
	 * @return the configuration
	 */
	/*
	 * public ColumnConfigImpl getConfiguration() { return configuration; }
	 */

	/**
	 * @param configuration
	 *            the configuration to set
	 */
	/*
	 * public void setConfiguration(ColumnConfigImpl configuration) {
	 * this.configuration = configuration; }
	 */

}
