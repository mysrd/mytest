package edt.presentation;

public class MockDestination implements javax.jms.Destination {

}
