package acceptation;
import java.util.Map;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay719plus.xml")
@FailFast
public class Lmtay719plusFixture extends AbstractFixture {

    public Tuyau  insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String valeur1, String valeur2,
    											int valeur3JJ, String valeur3MM, String valeur3SSAA, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try {
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_correspondance_metier_role_lmtay719");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taMetierOperationnelTiersLmtay787");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taRoleDeTiersLmtay778");
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydfeff");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_correspondance_metier_role_lmtay719");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4, String champ5, String valeur1, String valeur2,
			int valeur3JJ, String valeur3MM, String valeur3SSAA, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try {
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_correspondance_metier_role_lmtay719");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taMetierOperationnelTiersLmtay787");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taRoleDeTiersLmtay778");
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



    public Tuyau  modificationAvecMajTroisDates(String champ1, String champ2, String champ3, String champ4, String champ5,
    											String valeur1, String valeur2, int valeur3JJ, String valeur3MM, String valeur3SSAA, int valeur4JJ, String valeur4MM, String valeur4SSAA,
    											int valeur5JJ, String valeur5MM, String valeur5SSAA) {
    	try {
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
		    DetailsTablePage consulterTable = listeTables.consultation("ta_correspondance_metier_role_lmtay719");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydfeff");
			editerEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_correspondance_metier_role_lmtay719");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}



	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public boolean enAnomalie;

	}
}
