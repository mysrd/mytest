package acceptation.page;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AccueilPage {

    private static final int TEMPS_ATTENTE = 10;

	protected WebDriver driver;

    @FindBy(id="lien_EDITTABLES")
    protected WebElement lienListeTables;

    @FindBy(id="lien_HEXAPOSTE")
    protected WebElement lienHexaposte;
    
    public AccueilPage(WebDriver driver) {
        this.driver = driver;
    }

    public ListeTablesPage voirListeTables() {
    	try {
    		WebDriverWait wait = new WebDriverWait(driver, TEMPS_ATTENTE);
    		wait.until(ExpectedConditions.visibilityOf(lienListeTables));
    		lienListeTables.click();
    	} catch(NoSuchElementException | TimeoutException ex){
    		CaptureEcranUtil.prendreCaptureEcran(driver);
            throw ex;
    	}
    	return PageFactory.initElements(driver, ListeTablesPage.class);
    }


    public TraitementHexapostePage voirTraitementHexaposte() {
    	try {
			WebDriverWait wait = new WebDriverWait(driver, TEMPS_ATTENTE);
			wait.until(ExpectedConditions.visibilityOf(lienHexaposte));
			System.out.println("Clic sur le lien traitement Hexaposte");
			lienHexaposte.click();
			return PageFactory.initElements(driver, TraitementHexapostePage.class);
		} catch(NoSuchElementException | TimeoutException ex){
			CaptureEcranUtil.prendreCaptureEcran(driver);
	        throw ex;
		}

    }
    
    public boolean detecterMessageErreur() {

		try {
			WebElement champRecapitulatif = driver.findElement(By.id("creationEnregistrement.errors"));
			return true;
		} catch (NoSuchElementException exception2) {}

    	List<WebElement> champs = driver.findElements(By.className("control-group"));

    	for (WebElement champ : champs) {
			if(champ.getAttribute("class").contains("error")){
				return true;
			}
		}

    	return false;
    }

    public boolean detecterExceptionMetier(){
        try {
            WebElement erreur = driver.findElement(By.id("creationEnregistrement.errors"));
            return true;
        } catch (NoSuchElementException exception){
            throw exception;
        }
    }
}
