package acceptation.page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AbstractUpsert {
	protected WebDriver driver;

	@FindBy(className="buttonLink")
	protected WebElement boutonValider;

	public void selectionnerDate(int jour , String mois, String annee, String nomDate){
		WebElement champClot = driver.findElement(By.name(nomDate));
		champClot.click();
		WebElement dateWidget = driver.findElement(By.id("ui-datepicker-div"));
		Select selectMois = new Select(driver.findElement(By.className("ui-datepicker-month")));
		selectMois.selectByVisibleText(mois); // Pi�ge : des fois il y a un point � la fin
		Select selectAnnee = new Select(driver.findElement(By.className("ui-datepicker-year")));
		selectAnnee.selectByVisibleText(annee);
		List<WebElement> columns=dateWidget.findElements(By.tagName("td"));

		for (WebElement cell: columns){
		   if (cell.getText().equals(Integer.toString(jour))){
		      WebElement jourChoisi = cell.findElement(By.linkText(Integer.toString(jour)));
		      jourChoisi.click();
		      break;
		 }
		}
	}

	public void remplirChamp(String nomChamp, String valeur){
		WebElement champARemplir = driver.findElement(By.name(nomChamp.toLowerCase()));
		champARemplir.clear();
		champARemplir.sendKeys(valeur);

	}

	/**
	 * Retourne vrai quand la valeur fournie est dans la liste déroulante
	 * @param valeur
	 * @return
	 */
	public boolean verifierPresenceValeurListeDeroulante(String valeur, String nomChamp){
		Select champListe = new Select(driver.findElement(By.name(nomChamp)));
		List<WebElement> elements = champListe.getOptions();
		for (WebElement cell: elements){
			   if (cell.getText().equals(valeur)){
				      return true;
			      }
			}
		return false;
		}

	public String recupererValeurChamp(String nomChamp){
		WebElement champAExaminer = driver.findElement(By.name(nomChamp.toLowerCase()));
		return champAExaminer.getText();
	}


	public void selectionnerValeurListeDéroulante(String valeur, String nomChamp){
		Select champListe = new Select(driver.findElement(By.name(nomChamp)));
		champListe.selectByVisibleText(valeur);
	}

	public ListeTablesPage enregistrer(){
		boutonValider.click();
		DetailsTablePage pageDetails = PageFactory.initElements(driver, DetailsTablePage.class);
		return pageDetails.retournerALaListeDesTables();
	}

	public void enregistrerBloquant(){
		boutonValider.click();
	}

	public AccueilPage enregistrerErreur(){
		WebDriverWait wait = new WebDriverWait(driver, 500);
		wait.until(ExpectedConditions.visibilityOf(boutonValider));
		boutonValider.click();
		return PageFactory.initElements(driver, AccueilPage.class);

	}


	public boolean selectionnerChampEnAnomalie(String nomChamp){
		WebElement divChamp = driver.findElement(By.name(nomChamp.toUpperCase()));
		String classe = divChamp.getAttribute("class");
		if(classe.contains("error")){
			return true;
		}
		return false;
	}

}
