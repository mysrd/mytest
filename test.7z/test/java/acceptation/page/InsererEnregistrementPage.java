package acceptation.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;



public class InsererEnregistrementPage extends AbstractUpsert {

	public InsererEnregistrementPage(WebDriver driver) {
		this.driver = driver;
	}


}
