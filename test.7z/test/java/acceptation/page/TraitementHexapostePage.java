package acceptation.page;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class TraitementHexapostePage {

	protected WebDriver driver;

	@FindBy(id="fichierHexaposte")
	protected WebElement fileInput;

	@FindBy(id="submitHexaposte")
	protected WebElement boutonEnvoi;

	public TraitementHexapostePage(WebDriver driver) {
		this.driver = driver;
	}


	 public static String FICHIER_VIDE = "fichiervide.tri";
	 public static String FICHIER_MAUVAISE_EXTENSION = "fichierhexaposte.tro";
	 public static String FICHIER_TROP_PEU_DE_LIGNES = "fichierhexaposte.tri";
	 public static String FICHIER_DOUBLONNAGE = "fichierhexaposte_doublonnage.tri";
	 public static String FICHIER_1 = "hx2fvnn65.tri";
	 public static String FICHIER_2 = "fichierhexaposte_2.tri";
	 public static String FICHIER_CREATION = "fichier_hexaposte_creation.tri";
	 public static String FICHIER_MODIFICATION= "fichier_hexaposte_modification.tri";
	 public static String FICHIER_CLOTURE = "fichier_hexaposte_cloture.tri";

	/**
	 * Envoye un fichier a travers l'ecran du traitement Hexaposte
	 * @param nomFichier
	 * @return le message de succes ou d'erreur reçu en retour
	 */
	public String envoyerFichier(String nomFichier){
		File fichier = new File(getClass().getClassLoader().getResource("acceptation/fichier/"+nomFichier).getFile());
		fileInput.sendKeys(fichier.getAbsolutePath());
		boutonEnvoi.submit();

		try {
			WebElement messageErreur = driver.findElement(By.cssSelector("div.textAlerte.red.space_b"));
			System.out.println(messageErreur.getText());
			return messageErreur.getText();
		} catch(NoSuchElementException e){
			WebElement messageSucces = driver.findElement(By.cssSelector("div.textAlerte.green.space_b"));
			System.out.println(messageSucces.getText());
			return messageSucces.getText();
		}

	}

}
