package acceptation.page;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class DetailsTablePage {
	protected WebDriver driver;

	private Map<String,Map<String,String>> donneesEnCache;

	@FindBy(id="lien_EDITTABLES")
	private WebElement lienListeTables;
	
	public DetailsTablePage(WebDriver driver) {
		this.driver = driver;
	}

	public EditerEnregistrementPage editer(String identifiantEnregistrement) {

		WebElement ligne = driver.findElement(By.xpath("//td[@title='"+identifiantEnregistrement+"']"));
		ligne.click();
		WebDriverWait wait = new WebDriverWait(driver, 25);
		WebElement parent = ligne.findElement(By.xpath(".."));
		List<WebElement> select = parent.findElements(By.xpath(".//a"));
		wait.until(ExpectedConditions.visibilityOf(select.get(1)));
		select.get(1).click();

		return PageFactory.initElements(driver, EditerEnregistrementPage.class);
	}

	public ListeTablesPage supprimer(String identifiantEnregistrement){
		WebElement ligne = driver.findElement(By.xpath("//td[@title='"+identifiantEnregistrement+"']"));
		ligne.click();
		WebDriverWait wait = new WebDriverWait(driver, 25);
		WebElement parent = ligne.findElement(By.xpath(".."));
		List<WebElement> select = parent.findElements(By.xpath(".//a"));
		wait.until(ExpectedConditions.visibilityOf(select.get(1)));
		select.get(1).click();
		return this.retournerALaListeDesTables();
	}

	public Collection<Map<String, String>> obtenirDonnees(){
		viderCache();
		if(this.donneesEnCache==null){
			Map<String,Map<String,String>> listeDonnees = new HashMap<>();

			List<WebElement> enTetesHTML = driver.findElements(By.tagName("th"));

			WebElement boutonDeplier = isTableauDepliable(enTetesHTML);
			if(boutonDeplier!=null){
				return obtenirDonneesDetaillees(boutonDeplier);
			} else {
				WebElement table = driver.findElement(By.tagName("tbody"));
				List<WebElement> lignes = table.findElements(By.tagName("tr"));

				for (WebElement ligne : lignes) {
					List<WebElement> cellules = ligne.findElements(By.tagName("td"));
					Map<String,String> donnees = new HashMap<>();
					int colonne = 0;
					for (WebElement cellule : cellules) {
						if(!cellule.getText().equals("Configure")){
							donnees.put(enTetesHTML.get(colonne).getAttribute("name"), cellule.getText());
							colonne++;
						}
					}

					listeDonnees.put(donnees.get(enTetesHTML.get(0).getAttribute("name")),donnees);
				}
				this.donneesEnCache = listeDonnees;
				return listeDonnees.values();
			}
		} else {
			return this.donneesEnCache.values();
		}
	}

	public int obtenirNombreLignes(){
		return obtenirDonnees().size();
	}

	public void viderCache(){
		this.donneesEnCache = null;
	}
	public Map<String,String> obtenirDonneesParIdentifiant(String identifiant) {
		viderCache();
		obtenirDonnees();
		return this.donneesEnCache.get(identifiant);
	}


	public ListeTablesPage retournerALaListeDesTables(){
		lienListeTables.click();
		return PageFactory.initElements(driver, ListeTablesPage.class);
	}



	public Collection<Map<String, String>> obtenirDonneesDetaillees(WebElement boutonDeplier) {
			Map<String,Map<String,String>> listeDonnees = new HashMap<>();

			Map<String, String> dernieresDonneesTraitees = null;
			List<WebElement> enTetesHTML = driver.findElements(By.tagName("th"));

			WebElement spanBoutonPlus = boutonDeplier.findElement(By.xpath(".//span"));
			spanBoutonPlus.click();


			WebDriverWait wait = new WebDriverWait(driver, 25);

			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@class='info_row']")));
			} catch(TimeoutException e){
				CaptureEcranUtil.prendreCaptureEcran(driver);
				throw e;
			}
			WebElement table = driver.findElement(By.tagName("tbody"));

			List<WebElement> lignes = table.findElements(By.tagName("tr"));


			for (WebElement ligne : lignes) {
				Map<String,String> donnees = new HashMap<>();
				//c'est une ligne classique (elle dispose d'une classe) : faire le déroulement classique
				if(!ligne.getAttribute("class").isEmpty() && !ligne.getAttribute("class").contains("info_row")){
					List<WebElement> cellules = ligne.findElements(By.tagName("td"));
					int colonne = 0;
					for (WebElement cellule : cellules) {
						if(!cellule.getText().equals("Configure")){
							donnees.put(enTetesHTML.get(colonne).getAttribute("name"), cellule.getText());
							colonne++;
						}
					}

					String clef = enTetesHTML.get(1).getAttribute("name");
					listeDonnees.put(donnees.get(clef),donnees);
					dernieresDonneesTraitees = donnees;

				}
				//la ligne que j'examine est liée à la précédente (elle n'a pas de classe) : faire un déroulement alternatif
				else {
					List<WebElement> lignesInternes = ligne.findElements(By.xpath(".//div[@class='row']"));
					for (WebElement ligneInterne : lignesInternes) {
						WebElement label = ligneInterne.findElement(By.xpath(".//label")) ;
						WebElement paragrapheValeur = ligneInterne.findElement(By.xpath(".//p"));
						donnees.put(label.getAttribute("name"), paragrapheValeur.getText());
					}
					String clef = enTetesHTML.get(1).getAttribute("name");
					donnees.putAll(dernieresDonneesTraitees);
					listeDonnees.put(donnees.get(clef),donnees);

				//parcourir les div de la classe "row"
				//pour chaque div de class "row", récupérer <label> (libellé de la zone) et <p> (valeur de la zone)
				}

			}
			this.donneesEnCache = listeDonnees;
			return listeDonnees.values();
	}

	/**
	 * Determine si le tableau de la page est depliable
	 * Retourne le bouton pour deplier ou null si le tableau n'est pas depliable
	 * @param enTetesHTML
	 * @return
	 */
	private WebElement isTableauDepliable(List<WebElement> enTetesHTML) {
		WebElement enTeteBoutonPlus = null;
		for (WebElement enTete : enTetesHTML) {
			if(enTete.getText().equals("Plus d'informations")){
				enTeteBoutonPlus = enTete;
			}
		}
		return enTeteBoutonPlus;
	}




}
