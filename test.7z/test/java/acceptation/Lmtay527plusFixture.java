package acceptation;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay527plus.xml")
@FailFast
public class Lmtay527plusFixture extends AbstractFixture {

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String valeur1, String valeur2) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_qualite_normal_qualite_polites_lmtay527");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taQualiteNormaliseeLmtay520");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taQualitePolitesseLmtay526");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  creationRechercheValeurCloseListeDeroulante(String champ1, String champ2, String valeur1, String valeur2, int noCas) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_qualite_normal_qualite_polites_lmtay527");
			boolean estPresent = false ;
			switch (noCas)
			{
			case 2:
				 estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur1,"taQualiteNormaliseeLmtay520");
				insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taQualitePolitesseLmtay526");
				break;
			case 3:
				insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taQualiteNormaliseeLmtay520");
				 estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur2,"taQualitePolitesseLmtay526");
				break;
			default:
				break;
			}

			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }



	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public boolean enAnomalie;

	}
}
