package acceptation;

import java.util.Map;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay509plus.xml")

public class Lmtay509plusFixture extends AbstractFixture {


    public Tuyau  insertionCasNominal(String champ1, int valeur1JJ, String valeur1MM, String valeur1SSAA, String valeur1) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_jour_ferie_poste_lmtay509");
			insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "ydjfer");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_jour_ferie_poste_lmtay509");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, int valeur1JJ, String valeur1MM, String valeur1SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_jour_ferie_poste_lmtay509");
			insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "ydjfer");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  suppression(String champ1, String valeur1) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_jour_ferie_poste_lmtay509");
			listeTables = detailsTable.supprimer(valeur1);
			DetailsTablePage detailsTable2 = listeTables.consultation("ta_jour_ferie_poste_lmtay509");
			Map<String,String> donnees = detailsTable2.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if (donnees==null){
	 			t.champ1="supprimé";
	 		} else {
	 			t.champ1 ="non supprimée";
	 		}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}



    public Tuyau insertionDateDejaExistanteDansAutreCalendrier(String champ1, int valeur1JJ, String valeur1MM, String valeur1SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_jour_ferie_poste_lmtay509");
			insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "ydjfer");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			}
				else {
					t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
			}catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

	public class Tuyau {
		public String champ1;
		public String champ2;
		public boolean enAnomalie;
	}
}
