package acceptation;

import java.util.Map;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay948.xml")
@FailFast
public class Lmtay948Fixture extends AbstractFixture{

    public Tuyau  consultationLigne(String valeur1, String champ1, String champ2, String champ3, String champ4, String champ5) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_zone_geographique_pr_ratios_re_lmtay948");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
	}
}
