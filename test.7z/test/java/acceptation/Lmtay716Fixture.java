package acceptation;
import java.text.ParseException;

import java.util.Map;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay716.xml")

public class Lmtay716Fixture extends AbstractFixture {

    public Tuyau  insertionCasNominalAvecMajDatesEffet(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7,
    												   String valeur1, String valeur2,String valeur3, String valeur4,int valeur5JJ, String valeur5MM, String valeur5SSAA,int valeur6JJ, String valeur6MM, String valeur6SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_convention_fiscale_france_lmtay716");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydfeff");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_convention_fiscale_france_lmtay716");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);

			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  creationRechercheValeurAbsenteListeDeroulante(String champ1, String valeur1) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_convention_fiscale_france_lmtay716");
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur1,"taPaysLmtay501");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="dans la liste déroulante, la valeur n'est pas présente";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau  insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4, String valeur1, String valeur2,String valeur3, String valeur4, int noCas) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_convention_fiscale_france_lmtay716");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
	    	switch (noCas)
			{
			case 3 :
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ4);
				break;
			case 6 :
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
				break;
			default:
				break;
			}
	    	this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;

			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau  insertionCasDatesEffetInvalides(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7,
			   									  String valeur1, String valeur2,String valeur3, String valeur4,int valeur5JJ, String valeur5MM, String valeur5SSAA,int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_convention_fiscale_france_lmtay716");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterExceptionMetier();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4,
    										   String valeur1, String valeur2,String valeur3, String valeur4) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_convention_fiscale_france_lmtay716");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  insertionCasSaisieEnDouble(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7,
			   String valeur1, String valeur2,String valeur3, String valeur4,int valeur5JJ, String valeur5MM, String valeur5SSAA,int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_convention_fiscale_france_lmtay716");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau modificationTauxInteret(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String valeur1, String valeur4){
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		DetailsTablePage consulterTable = listeTables.consultation("ta_convention_fiscale_france_lmtay716");
    		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
    		editerEnregistrement.remplirChamp(champ4, valeur4);
    		listeTables = editerEnregistrement.enregistrer();
    		DetailsTablePage detailsTable = listeTables.consultation("ta_convention_fiscale_france_lmtay716");
    		Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
    		this.fermetureSelenium();
    		Tuyau t = new Tuyau();
    		t.champ1 = donnees.get(champ1);
    		t.champ2 = donnees.get(champ2);
    		t.champ3 = donnees.get(champ3);
    		t.champ4 = donnees.get(champ4);
    		t.champ5 = donnees.get(champ5);
    		t.champ6 = donnees.get(champ6);
    		t.champ7 = donnees.get(champ7);
    		return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau modificationDateDebutEffet(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String valeur1, int valeur5JJ, String valeur5MM, String valeur5SSAA){
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		DetailsTablePage consulterTable = listeTables.consultation("ta_convention_fiscale_france_lmtay716");
    		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
    		editerEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "yddeff");
    		listeTables = editerEnregistrement.enregistrer();
    		DetailsTablePage detailsTable = listeTables.consultation("ta_convention_fiscale_france_lmtay716");
    		Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
    		this.fermetureSelenium();
    		Tuyau t = new Tuyau();
    		t.champ1 = donnees.get(champ1);
    		t.champ2 = donnees.get(champ2);
    		t.champ3 = donnees.get(champ3);
    		t.champ4 = donnees.get(champ4);
    		t.champ5 = donnees.get(champ5);
    		t.champ6 = donnees.get(champ6);
    		t.champ7 = donnees.get(champ7);
    		return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau modificationTauxInteretIncorrecte(String champ1, String champ2, String valeur1, String valeur2){
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		DetailsTablePage consulterTable = listeTables.consultation("ta_convention_fiscale_france_lmtay716");
    		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
    		editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
				estEnAnomalie= editerEnregistrement.selectionnerChampEnAnomalie(champ2);
	    	this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;

			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public boolean enAnomalie;
	}
}
