package acceptation;
import java.util.Map;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay891plus.xml")
@FailFast
public class Lmtay891plusFixture extends AbstractFixture {

    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String champ4, String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_lieu_de_compensation_lmtay891");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
	 		insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}


    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public boolean enAnomalie;

	}
}
