package acceptation;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay403plus.xml")
@FailFast
public class Lmtay403plusFixture extends AbstractFixture {

    public Tuyau  insertionCasNominalAvecMajTroisDates(String champ1, String champ2, String champ4,String champ5,String champ6, String valeur1, String valeur2,
    											int valeur1JJ, String valeur1MM, String valeur1SSAA,
    											int valeur2JJ, String valeur2MM, String valeur2SSAA,
    											int valeur3JJ, String valeur3MM, String valeur3SSAA, int noCas) throws ParseException {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
			t.champ7 = donnees.get("YDC000");       //date de création
	        t.champ8 = donnees.get("YDDMAJ");       //date de dernière mise à jour
	        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ4);
			Date dateFinEffet = sdf.parse(t.champ5);
			Date dateCloture = sdf.parse(t.champ6);
			Date dateCreation = sdf.parse(t.champ7);
			Date dateDerniereMaj = sdf.parse(t.champ8);
			switch (noCas)
			{
			case 1: case 3:
				t.testDate1 = dateDebutEffet.before(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.equals(dateDerniereMaj);
				break;
			case 4: case 5: case 7:
				t.testDate1 = dateDebutEffet.after(dateCreation);
				t.testDate2 = dateDebutEffet.after(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.equals(dateDerniereMaj);
				break;
			case 8:
				t.testDate1 = dateDebutEffet.before(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.before(dateCreation);
				t.testDate4 = dateFinEffet.before(dateDerniereMaj);
				t.testDate5 = dateCloture.before(dateCreation);
				t.testDate6 = dateCloture.before(dateDerniereMaj);
				t.testDate7 = dateCreation.equals(dateDerniereMaj);
				break;
			default:
				break;
			}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  insertionCasNominalAvecMajDeuxDates(String champ1, String champ2, String champ4,String champ5,String champ6, String valeur1, String valeur2,
												int valeur1JJ, String valeur1MM, String valeur1SSAA,
												int valeur2JJ, String valeur2MM, String valeur2SSAA, int noCas) throws ParseException {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			switch (noCas)
			{
			case 6:
				insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
				insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
				break;
			default:
				break;
			}
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
			t.champ7 = donnees.get("YDC000");       //date de création
			t.champ8 = donnees.get("YDDMAJ");       //date de dernière mise à jour
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ4);
			Date dateFinEffet = sdf.parse(t.champ5);
			Date dateCloture = sdf.parse(t.champ6);
			Date dateCreation = sdf.parse(t.champ7);
			Date dateDerniereMaj = sdf.parse(t.champ8);
			switch (noCas)
			{
			case 6:
				t.testDate1 = dateDebutEffet.after(dateCreation);
				t.testDate2 = dateDebutEffet.after(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.equals(dateDerniereMaj);
				break;
			default:
				break;
			}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  insertionCasNominalAvecMajUneDate(String champ1, String champ2, String champ4,String champ5,String champ6, String valeur1, String valeur2,
										int valeur1JJ, String valeur1MM, String valeur1SSAA,int noCas) throws ParseException {
		try {
			LoginPage loginPage = initialisationSelenium();
	    	AccueilPage accueil = loginPage.login("admin", "password");
	    	ListeTablesPage listeTables = accueil.voirListeTables();
	    	InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
	    	insererEnregistrement.remplirChamp(champ1, valeur1);
	    	insererEnregistrement.remplirChamp(champ2, valeur2);
	    	switch (noCas)
			{
			case 2:
				insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
				break;
			default:
				break;
			}
	    	listeTables = insererEnregistrement.enregistrer();
	    	DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
	    	Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

	    	this.fermetureSelenium();
	    	Tuyau t = new Tuyau();
	    	t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
	    	t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
			t.champ7 = donnees.get("YDC000");       //date de création
			t.champ8 = donnees.get("YDDMAJ");       //date de dernière mise à jour
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ4);
			Date dateFinEffet = sdf.parse(t.champ5);
			Date dateCloture = sdf.parse(t.champ6);
			Date dateCreation = sdf.parse(t.champ7);
			Date dateDerniereMaj = sdf.parse(t.champ8);
			switch (noCas)
			{
			case 2:
			t.testDate1 = dateDebutEffet.after(dateCreation);
			t.testDate2 = dateDebutEffet.after(dateDerniereMaj);
			t.testDate3 = dateFinEffet.after(dateCreation);
			t.testDate4 = dateFinEffet.after(dateDerniereMaj);
			t.testDate5 = dateCloture.after(dateCreation);
			t.testDate6 = dateCloture.after(dateDerniereMaj);
			t.testDate7 = dateCreation.equals(dateDerniereMaj);
				break;
			default:
				break;
			}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2 ) {
		try {
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2, int noCas) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
	    	switch (noCas)
			{
			case 10:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
				break;
			case 12:
				estEnAnomalie = insererEnregistrement.selectionnerChampEnAnomalie(champ2);
					break;
			default:
				break;
			}
	    	this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau  insertionCasSaisieTropLongue(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2 ) {
		try {
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  insertionCasDatesEffetInvalidesAvecMajTroisDates(String champ1, String champ2, String champ4,String champ5,String champ6, String valeur1, String valeur2,
    											int valeur1JJ, String valeur1MM, String valeur1SSAA,
    											int valeur2JJ, String valeur2MM, String valeur2SSAA,
    											int valeur3JJ, String valeur3MM, String valeur3SSAA) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterExceptionMetier();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  insertionCasDatesEffetInvalidesAvecMajDeuxDates(String champ1, String champ2, String champ4,String champ5,String champ6, String valeur1, String valeur2,
															int valeur1JJ, String valeur1MM, String valeur1SSAA,
															int valeur2JJ, String valeur2MM, String valeur2SSAA, int noCas) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			switch (noCas)
			{
			case 16:
				insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
				insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
				break;
			case 17:
				insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
				insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydclot");
				break;
			default :
				break;
			}
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterExceptionMetier();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau modificationCasNominalAvecMajTroisDates(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2,
													int valeur1JJ, String valeur1MM, String valeur1SSAA,
													int valeur2JJ, String valeur2MM, String valeur2SSAA,
													int valeur3JJ, String valeur3MM, String valeur3SSAA, int noCas) throws ParseException{
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			switch (noCas)
			{
			case 24: case 28:
			editerEnregistrement.remplirChamp(champ2, valeur2);
				break;
			default:
				break;
			}
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
			t.champ7 = donnees.get("YDC000");       //date de création
	        t.champ8 = donnees.get("YDDMAJ");       //date de dernière mise à jour
	        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ4);
			Date dateFinEffet = sdf.parse(t.champ5);
			Date dateCloture = sdf.parse(t.champ6);
			Date dateCreation = sdf.parse(t.champ7);
			Date dateDerniereMaj = sdf.parse(t.champ8);
			switch (noCas)
			{
			case 21:
				t.testDate1 = dateDebutEffet.after(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			case 24: case 28:
				t.testDate1 = dateDebutEffet.after(dateCreation);
				t.testDate2 = dateDebutEffet.after(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			case 27:
				t.testDate1 = dateDebutEffet.before(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.before(dateCreation);
				t.testDate4 = dateFinEffet.before(dateDerniereMaj);
				t.testDate5 = dateCloture.before(dateCreation);
				t.testDate6 = dateCloture.before(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			default:
				break;
			}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau modificationCasNominalAvecMajDeuxDates(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1,
													int valeur1JJ, String valeur1MM, String valeur1SSAA,
    												int valeur2JJ, String valeur2MM, String valeur2SSAA, int noCas) throws ParseException{
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			switch (noCas)
			{
			case 23:
			editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "ydfeff");
			editerEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydclot");
			break;
			default:
			break;
			}
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
			t.champ7 = donnees.get("YDC000");       //date de création
			t.champ8 = donnees.get("YDDMAJ");       //date de dernière mise à jour
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ4);
			Date dateFinEffet = sdf.parse(t.champ5);
			Date dateCloture = sdf.parse(t.champ6);
			Date dateCreation = sdf.parse(t.champ7);
			Date dateDerniereMaj = sdf.parse(t.champ8);
			switch (noCas)
			{
			case 23:
				t.testDate1 = dateDebutEffet.equals(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			default:
				break;
			}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau modificationCasNominalAvecMajUneDate(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2,
													int valeur1JJ, String valeur1MM, String valeur1SSAA, int noCas) throws ParseException{
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			switch (noCas)
			{
			case 22:
				editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
				break;
			case 25:
				editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "ydclot");
				break;
			case 26:
				editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
				editerEnregistrement.remplirChamp(champ2, valeur2);
				break;
			default:
				break;
			}
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
			t.champ7 = donnees.get("YDC000");       //date de création
			t.champ8 = donnees.get("YDDMAJ");       //date de dernière mise à jour
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ4);
			Date dateFinEffet = sdf.parse(t.champ5);
			Date dateCloture = sdf.parse(t.champ6);
			Date dateCreation = sdf.parse(t.champ7);
			Date dateDerniereMaj = sdf.parse(t.champ8);
			switch (noCas)
			{
			case 22:
				t.testDate1 = dateDebutEffet.before(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			case 25:
				t.testDate1 = dateDebutEffet.after(dateCreation);
				t.testDate2 = dateDebutEffet.after(dateDerniereMaj);
				t.testDate3 = dateFinEffet.after(dateCreation);
				t.testDate4 = dateFinEffet.after(dateDerniereMaj);
				t.testDate5 = dateCloture.before(dateCreation);
				t.testDate6 = dateCloture.before(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			case 26:
				t.testDate1 = dateDebutEffet.before(dateCreation);
				t.testDate2 = dateDebutEffet.before(dateDerniereMaj);
				t.testDate3 = dateFinEffet.before(dateCreation);
				t.testDate4 = dateFinEffet.before(dateDerniereMaj);
				t.testDate5 = dateCloture.after(dateCreation);
				t.testDate6 = dateCloture.after(dateDerniereMaj);
				t.testDate7 = dateCreation.before(dateDerniereMaj);
				break;
			default:
				break;
			}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  modificationCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String valeur1, String valeur2) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = editerEnregistrement.selectionnerChampEnAnomalie(champ2);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;

			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau  modificationCasSaisieTropLongue(String champ1, String champ2, String valeur1, String valeur2 ) {
		try {
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  modificationCasDatesEffetInvalidesAvecMajTroisDates(String champ1, String champ4,String champ5, String champ6, String valeur1,
    															int valeur1JJ, String valeur1MM, String valeur1SSAA,
    															int valeur2JJ, String valeur2MM, String valeur2SSAA,
    															int valeur3JJ, String valeur3MM, String valeur3SSAA) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterExceptionMetier();
	 		this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  modificationCasDatesEffetInvalidesAvecMajUneDate(String champ1, String champ4,String champ5, String champ6, String valeur1,
																int valeur1JJ, String valeur1MM, String valeur1SSAA) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterExceptionMetier();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2 ) {
		try {
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  modificationCasCaractereNonAutorise(String champ1, String champ2, String valeur1, String valeur2 ) {
		try {
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public boolean enAnomalie;
		public boolean testDate1;
		public boolean testDate2;
		public boolean testDate3;
		public boolean testDate4;
		public boolean testDate5;
		public boolean testDate6;
		public boolean testDate7;

	}
}
