package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay830.xml")

public class Lmtay830Fixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
    											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, int valeur10JJ, String valeur10MM, String valeur10SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_contrepartie_bic_lmtay830");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taFamilleFiscaleLmtay934");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taCodeAgentFinancier");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			insererEnregistrement.selectionnerDate(valeur10JJ, valeur10MM, valeur10SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_contrepartie_bic_lmtay830");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			String valeur1, String valeur2, String valeur3, String valeur4, String valeur7, String valeur8, int valeur10JJ, String valeur10MM, String valeur10SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_contrepartie_bic_lmtay830");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			insererEnregistrement.selectionnerDate(valeur10JJ, valeur10MM, valeur10SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_contrepartie_bic_lmtay830");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, int valeur10JJ, String valeur10MM, String valeur10SSAA) {
    	try{
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_contrepartie_bic_lmtay830");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taFamilleFiscaleLmtay934");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taCodeAgentFinancier");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			insererEnregistrement.selectionnerDate(valeur10JJ, valeur10MM, valeur10SSAA, "ydclot");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();

	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, int valeur10JJ, String valeur10MM, String valeur10SSAA, int noCas) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_contrepartie_bic_lmtay830");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taFamilleFiscaleLmtay934");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taCodeAgentFinancier");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			insererEnregistrement.selectionnerDate(valeur10JJ, valeur10MM, valeur10SSAA, "ydclot");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			switch (noCas)
				{
				case 3:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
				break;
				case 4:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
				break;
				default:
				break;
				}
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
				}
			else {
				t.champ1 ="non bloquante.";
				}
			t.enAnomalie = estEnAnomalie;
			return t;
			}
    		catch (Exception e){
    			this.fermetureSelenium();
    			throw e;
				}
	}


    public Tuyau insertionCasNominalSansMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_contrepartie_bic_lmtay830");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taFamilleFiscaleLmtay934");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taCodeAgentFinancier");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_contrepartie_bic_lmtay830");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

							this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
												String valeur1, String valeur2, String valeur3, String valeur4, String valeur7, String valeur8, int valeur10JJ, String valeur10MM, String valeur10SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_contrepartie_bic_lmtay830");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			insererEnregistrement.selectionnerDate(valeur10JJ, valeur10MM, valeur10SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
													String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,
													int valeur9JJ, String valeur9MM, String valeur9SSAA,
													int valeur10JJ, String valeur10MM, String valeur10SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_de_contrepartie_bic_lmtay830");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taCodeRegroupementCategorieBic");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taCodeRegroupementCategorieClientFed");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taFamilleFiscaleLmtay934");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taCodeAgentFinancier");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taCodeAgentEcoSistre");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodificationReglementaireLmtay997");
			editerEnregistrement.selectionnerDate(valeur9JJ, valeur9MM, valeur9SSAA, "ydf000");
			editerEnregistrement.selectionnerDate(valeur10JJ, valeur10MM, valeur10SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_contrepartie_bic_lmtay830");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  modificationCasSaisieTropLongue(String champ1, String champ2, String champ9,String valeur1, String valeur2,int valeur9JJ, String valeur9MM, String valeur9SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_de_contrepartie_bic_lmtay830");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerDate(valeur9JJ, valeur9MM, valeur9SSAA, "ydf000");
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}






	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public String champ10;
		public boolean enAnomalie;

	}
}
