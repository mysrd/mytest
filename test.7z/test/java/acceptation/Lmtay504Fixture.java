package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay504.xml")

public class Lmtay504Fixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4,
    											String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nature_juridique_ficoba_lmtay504");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_nature_juridique_ficoba_lmtay504");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4,
															String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA, int noCas) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nature_juridique_ficoba_lmtay504");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			switch (noCas)
				{
				case 2:
					estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
					break;
				case 3:
					estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
					break;
				case 4:
					estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ3);
					break;
				default:
					break;
				}
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4,
											  String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nature_juridique_ficoba_lmtay504");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4,
			  										String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		DetailsTablePage consulterTable = listeTables.consultation("ta_nature_juridique_ficoba_lmtay504");
    		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
    		editerEnregistrement.remplirChamp(champ2, valeur2);
    		editerEnregistrement.remplirChamp(champ3, valeur3);
    		editerEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
    		ListeTablesPage listeTables2 = editerEnregistrement.enregistrer();
    		DetailsTablePage detailsTable2 = listeTables2.consultation("ta_nature_juridique_ficoba_lmtay504");
    		Map<String,String> donnees = detailsTable2.obtenirDonneesParIdentifiant(valeur1);
    		this.fermetureSelenium();
    		Tuyau t = new Tuyau();
    		t.champ1 = donnees.get(champ1);
    		t.champ2 = donnees.get(champ2);
    		t.champ3 = donnees.get(champ3);
    		t.champ4 = donnees.get(champ4);
    		return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau  modificationCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4,
												  String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_nature_juridique_ficoba_lmtay504");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
    		editerEnregistrement.remplirChamp(champ3, valeur3);
    		editerEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4,
												String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nature_juridique_ficoba_lmtay504");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public boolean enAnomalie;

	}
}
