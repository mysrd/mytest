package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay547.xml")

public class Lmtay547Fixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4,
    											String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_region_administrative_lmtay547");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_region_administrative_lmtay547");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4,
															String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA,
															int noCas) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_region_administrative_lmtay547");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			switch (noCas)
				{
				case 2:
					estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
					break;
				case 3:
					estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
					break;
				default:
					break;
				}
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
		if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
			} catch (Exception e){
				this.fermetureSelenium();
				throw e;
		}
	}


    public Tuyau insertionCasErreurSaisieTropLongue(String champ1, String champ2, String champ3, String champ4,
													String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_region_administrative_lmtay547");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante";
			} else {
			t.champ1 ="non bloquante";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4,
												String valeur1, String valeur2, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_region_administrative_lmtay547");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_region_administrative_lmtay547");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4,
													String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_region_administrative_lmtay547");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taRegion2016");
			editerEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_region_administrative_lmtay547");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			return t;
    	} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
}


    public Tuyau  modificationCasErreurSaisieTropLongue(String champ1, String champ2, String champ4,
														String valeur1, String valeur2, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_region_administrative_lmtay547");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
	 		accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante";
			} else {
			t.champ1 ="non bloquante";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ4,
    											String valeur1, String valeur2, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_region_administrative_lmtay547");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante";
			} else {
			t.champ1 ="non bloquante";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

	}


    public Tuyau  creationRechercheValeurCloseListeDeroulanteTaRegionAdministrative2016(String champ1, String champ2, String champ3, String champ4,
																						String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_region_administrative_lmtay547");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "ydclot");
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur3,"taRegion2016");
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estPresent){
			t.champ1="Cette valeur est présente dans la liste.";
			} else {
			t.champ1 ="La valeur n'est pas présente dans la liste.";
			}
			t.enAnomalie = estPresent;

			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}




    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public boolean enAnomalie;

	}
}
