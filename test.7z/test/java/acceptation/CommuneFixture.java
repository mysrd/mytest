package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_commune.xml")

public class CommuneFixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDatesEffet(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
    												  String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
    												  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
    												  String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA, String valeur18) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_commune_insee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taDepartement");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.remplirChamp(champ8, valeur8);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
			insererEnregistrement.remplirChamp(champ10, valeur10);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
			insererEnregistrement.remplirChamp(champ12, valeur12);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
			insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_commune_insee");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  modificationCasNominalAvecMajToutesDates(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			  												String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
			  												String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
			  												String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA,
			  												int valeur17JJ, String valeur17MM, String valeur17SSAA, String valeur18) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_commune_insee");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
			editerEnregistrement.remplirChamp(champ7, valeur7);
			editerEnregistrement.remplirChamp(champ8, valeur8);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
			editerEnregistrement.remplirChamp(champ10, valeur10);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
			editerEnregistrement.remplirChamp(champ12, valeur12);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
			editerEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
			editerEnregistrement.selectionnerDate(valeur17JJ, valeur17MM, valeur17SSAA, "ydclot");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_commune_insee");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
		throw e;
		}
	}



    public Tuyau  modificationCasNominalAvecMajDatesEffet(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
														  String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
														  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
														  String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA,
														  String valeur18) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_commune_insee");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
			editerEnregistrement.remplirChamp(champ7, valeur7);
			editerEnregistrement.remplirChamp(champ8, valeur8);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
			editerEnregistrement.remplirChamp(champ10, valeur10);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
			editerEnregistrement.remplirChamp(champ12, valeur12);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
			editerEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_commune_insee");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }




    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
    														String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
    														String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
    														String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA,
    														String valeur18, int noCas) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_commune_insee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taDepartement");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.remplirChamp(champ8, valeur8);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
			insererEnregistrement.remplirChamp(champ10, valeur10);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
			insererEnregistrement.remplirChamp(champ12, valeur12);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
			insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			switch (noCas)
				{
				case 8:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
				break;
				case 13:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ10);
				break;
				case 15:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ12);
				break;
				default:
				break;
				}
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
				}
			else {
				t.champ1 ="non bloquante.";
				}
			t.enAnomalie = estEnAnomalie;
			return t;
			}
    		catch (Exception e){
    			this.fermetureSelenium();
    			throw e;
				}
	}







    public Tuyau insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
											  String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
											  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
											  String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA,
											  String valeur18) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_commune_insee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taDepartement");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.remplirChamp(champ8, valeur8);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
			insererEnregistrement.remplirChamp(champ10, valeur10);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
			insererEnregistrement.remplirChamp(champ12, valeur12);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
			insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}



    public Tuyau insertionCasSaisieTropCourte(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			  								  String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
			  								  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
			  								  String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA,
			  								  String valeur18) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_commune_insee");
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taDepartement");
    		insererEnregistrement.remplirChamp(champ2, valeur2);
    		insererEnregistrement.remplirChamp(champ7, valeur7);
    		insererEnregistrement.remplirChamp(champ8, valeur8);
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
    		insererEnregistrement.remplirChamp(champ10, valeur10);
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
    		insererEnregistrement.remplirChamp(champ12, valeur12);
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
    		insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
    		insererEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
    		insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
    		accueil = insererEnregistrement.enregistrerErreur();
    		boolean estEnAnomalie = accueil.detecterMessageErreur();
    		this.fermetureSelenium();
    		Tuyau t = new Tuyau();
    		if(estEnAnomalie){
    			t.champ1="bloquante.";
    		} else {
    			t.champ1 ="non bloquante.";
    		}
    		t.enAnomalie = estEnAnomalie;
    		return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau insertionCasSaisieDatesEffetInvalides(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
    										  String champ11,String champ12,String champ13,String champ14,String champ15,String champ16,String champ17,String champ18,
    										  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8,String valeur9,String valeur10,
    										  String valeur11, String valeur12, String valeur14, int valeur15JJ, String valeur15MM, String valeur15SSAA, int valeur16JJ, String valeur16MM, String valeur16SSAA,
    										  String valeur18) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_commune_insee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTopDecoupageCommuneCantons");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taTopChefLieu");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taRegion2016");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taDepartement");
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.remplirChamp(champ8, valeur8);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taArticleMajuscule");
			insererEnregistrement.remplirChamp(champ10, valeur10);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taArticleTypographieRiche");
			insererEnregistrement.remplirChamp(champ12, valeur12);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taIdentifiantCommune");
			insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur16JJ, valeur16MM, valeur16SSAA, "ydfeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taTypeDeNomEnClair");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterExceptionMetier();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}













    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
													String valeur1, String valeur2, String valeur3, String valeur4, int valeur5JJ, String valeur5MM, String valeur5SSAA, int valeur6JJ, String valeur6MM, String valeur6SSAA,String valeur8, String valeur9, String valeur10) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_comptable_elementaire_gmtamo06");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.remplirChamp(champ3, valeur3);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCindmg");
			editerEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydfeff");
			editerEnregistrement.remplirChamp(champ8, valeur8);
			editerEnregistrement.remplirChamp(champ9, valeur9);
			editerEnregistrement.remplirChamp(champ10, valeur10);
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_comptable_elementaire_gmtamo06");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  modificationCasSaisieTropLongue(String champ1, String champ2, String valeur1, String valeur2) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_comptable_elementaire_gmtamo06");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4, String valeur1, String valeur2, String valeur3, String valeur4) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_comptable_elementaire_gmtamo06");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taChoixOuiNonByCindmg");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixCdcepCdcfi");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
				} else {
				t.champ1 ="non bloquante.";
				}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}



    public Tuyau  modificationCasSaisieDatesInvalides(String champ1, String champ2, String champ3, String valeur1, int valeur2JJ, String valeur2MM, String valeur2SSAA, int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_code_comptable_elementaire_gmtamo06");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydfeff");
			accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterExceptionMetier();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}



	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public String champ10;
		public String champ11;
		public String champ12;
		public String champ13;
		public String champ14;
		public String champ15;
		public String champ16;
		public String champ17;
		public String champ18;
		public boolean enAnomalie;

	}
}
