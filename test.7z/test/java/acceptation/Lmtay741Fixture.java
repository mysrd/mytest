package acceptation;

import java.util.Map;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay741.xml")

public class Lmtay741Fixture extends AbstractFixture {


    public Tuyau  insertionCasNominal(String champ1, String champ2, String valeur1, int valeur2JJ, String valeur2MM, String valeur2SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_jour_ferie_cambiste_pays_lmtay741");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydjfer");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_jour_ferie_cambiste_pays_lmtay741");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String valeur1, int valeur2JJ, String valeur2MM, String valeur2SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_jour_ferie_cambiste_pays_lmtay741");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taPaysLmtay501");
			insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydjfer");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  suppression(String champ1, String valeur1) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_jour_ferie_cambiste_pays_lmtay741");
			listeTables = detailsTable.supprimer(valeur1);
			DetailsTablePage detailsTable2 = listeTables.consultation("ta_jour_ferie_cambiste_pays_lmtay741");
			Map<String,String> donnees = detailsTable2.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if (donnees==null){
	 			t.champ1=" ";
	 		} else {
	 			t.champ1 ="non supprimée";
	 		}
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}



	public class Tuyau {
		public String champ1;
		public String champ2;
		public boolean enAnomalie;
	}
}
