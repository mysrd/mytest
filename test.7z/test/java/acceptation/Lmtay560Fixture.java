package acceptation;
import java.util.Map;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay560.xml")
public class Lmtay560Fixture extends AbstractFixture {

    public Tuyau  insertionCasNominalSansMajDate(String champ1, String champ2, String champ3, String valeur1, String valeur2) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_lien_categ_client_deposant_lmtay560");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taCategorieDeClientLmtay523");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taCategorieDeDeposantLmtay525");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_lien_categ_client_deposant_lmtay560");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String valeur1, String valeur2) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_lien_categ_client_deposant_lmtay560");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taCategorieDeClientLmtay523");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taCategorieDeDeposantLmtay525");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  modificationAvecMajDate(String champ1, String champ3, String valeur1, int valeur3JJ, String valeur3MM, String valeur3SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
		    DetailsTablePage consulterTable = listeTables.consultation("ta_lien_categ_client_deposant_lmtay560");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_lien_categ_client_deposant_lmtay560");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ3 = donnees.get(champ3);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  creationRechercheValeurCloseListeDeroulante(String champ1, String champ2, String valeur1, String valeur2) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_lien_categ_client_deposant_lmtay560");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taCategorieDeClientLmtay523");
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur2,"taCategorieDeDeposantLmtay525");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public boolean enAnomalie;

	}
}
