package fr.icdc.dei.lm4.paraneo.utils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaApparentementCdcLmtay538;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaArticleMajuscule;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaArticleTypographieRiche;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCommuneInsee;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDepartement;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFormeJuridiqueDgiLmtay518;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaIdentifiantCommune;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNomenclatureDeClienteleLmtay774;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegionAdministrativeLmtay547;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTerritorialiteFicobaLmtay508;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTierCorrespInseeNomfaLmtay999;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopChefLieu;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopDecoupageCommuneCantons;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeDeNomEnClair;

public class IntrospectionUtilsTest {

	@Test
	public void testGetPrimaryKeysNameAndValuesLmtay538() throws Exception {
		TaApparentementCdcLmtay538 value = new TaApparentementCdcLmtay538();
		value.setCuser("admin");
		value.setLcapr("B");
		value.setYc0apr("A");
		value.setYdc000(new Date());
		value.setYdclot(new Date());
		value.setYddmaj(new Date());
		value.setYl0apr("BOB");

		TableDescription description = new TableDescription();

		ArrayList<ColumnDescription> colonnes = new ArrayList<ColumnDescription>();

		ColumnDescription colonneId = new ColumnDescription();
		colonneId.setAutoPrimaryKey(false);
		colonneId.setPrimaryKey(true);
		colonneId.setClassName("java.lang.String");
		colonneId.setColumnName("YC0APR");
		colonneId.setForeignKey(false);
		colonneId.setIdPropertyName("yc0apr");
		colonneId.setPropertyName("yc0apr");

		ColumnDescription colonneNonId = new ColumnDescription();
		colonneNonId.setAutoPrimaryKey(false);
		colonneNonId.setPrimaryKey(false);
		colonneNonId.setClassName("java.lang.String");
		colonneNonId.setColumnName("TEST");
		colonneNonId.setForeignKey(false);
		colonneNonId.setIdPropertyName("test");
		colonneNonId.setPropertyName("test");

		colonnes.add(colonneNonId);
		colonnes.add(colonneId);
		description.setColumnList(colonnes);

		description.setEntityClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaApparentementCdcLmtay538");

		Map<String, Object> resultatAttendu = new HashMap<String,Object>();
		resultatAttendu.put("yc0apr", "A");

		assertEquals(resultatAttendu,IntrospectionUtils.getPrimaryKeysNameAndValues(value, description));
	}

	@Test
	public void testGetPrimaryKeysNameAndValuesLmtay999() throws Exception {
		//Table avec deux colonnes clefs primaires qui sont également des clefs étrangéres
		TaTierCorrespInseeNomfaLmtay999 value = new TaTierCorrespInseeNomfaLmtay999();
		TaFormeJuridiqueDgiLmtay518 taFormeJuridiqueDgiLmtay518 = new TaFormeJuridiqueDgiLmtay518();
		taFormeJuridiqueDgiLmtay518.setYc0fjd("A");
		value.setTaFormeJuridiqueDgiLmtay518(taFormeJuridiqueDgiLmtay518);
		TaNomenclatureDeClienteleLmtay774 taNomenclatureDeClienteleLmtay774 = new TaNomenclatureDeClienteleLmtay774();
		taNomenclatureDeClienteleLmtay774.setYcncli("B");
		value.setTaNomenclatureDeClienteleLmtay774(taNomenclatureDeClienteleLmtay774);

		TableDescription description = new TableDescription();

		ArrayList<ColumnDescription> colonnes = new ArrayList<ColumnDescription>();

		ColumnDescription colonneId = new ColumnDescription();
		colonneId.setAutoPrimaryKey(false);
		colonneId.setPrimaryKey(true);
		colonneId.setClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaFormeJuridiqueDgiLmtay518");
		colonneId.setColumnName("YC0FJD" );
		colonneId.setForeignKey(true);
		colonneId.setIdPropertyName("taFormeJuridiqueDgiLmtay518" );
		colonneId.setPropertyName("taFormeJuridiqueDgiLmtay518");
		colonnes.add(colonneId);

		ColumnDescription colonneId2 = new ColumnDescription();
		colonneId2.setAutoPrimaryKey(false);
		colonneId2.setPrimaryKey(true);
		colonneId2.setClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaNomenclatureDeClienteleLmtay774");
		colonneId2.setColumnName("YCNCLI");
		colonneId2.setForeignKey(true);
		colonneId2.setIdPropertyName("taNomenclatureDeClienteleLmtay774" );
		colonneId2.setPropertyName("taNomenclatureDeClienteleLmtay774");
		colonnes.add(colonneId2);

		ColumnDescription colonneNonId = new ColumnDescription();
		colonneNonId.setAutoPrimaryKey(false);
		colonneNonId.setPrimaryKey(false);
		colonneNonId.setClassName("java.lang.String");
		colonneNonId.setColumnName("TEST");
		colonneNonId.setForeignKey(false);
		colonneNonId.setIdPropertyName("test");
		colonneNonId.setPropertyName("test");
		colonnes.add(colonneNonId);


		description.setColumnList(colonnes);

		description.setEntityClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaTierCorrespInseeNomfaLmtay999");

		Map<String, Object> resultatAttendu = new HashMap<String,Object>();
		resultatAttendu.put("taFormeJuridiqueDgiLmtay518.yc0fjd", "A");
		resultatAttendu.put("taNomenclatureDeClienteleLmtay774.ycncli", "B");
		assertEquals(resultatAttendu,IntrospectionUtils.getPrimaryKeysNameAndValues(value, description));
	}

	@Test
	public void testGetPrimaryKeysNameAndValuesTaRegion2016() throws Exception{
		//Table non LMTAY en suffixe
		TaRegion2016 value = new TaRegion2016();
		value.setRegion("PACA");

		TableDescription description = new TableDescription();

		ArrayList<ColumnDescription> colonnes = new ArrayList<ColumnDescription>();
		ColumnDescription colonneId = new ColumnDescription();
		colonneId.setAutoPrimaryKey(false);
		colonneId.setPrimaryKey(true);
		colonneId.setClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016");
		colonneId.setColumnName("REGION" );
		colonneId.setForeignKey(false);
		colonneId.setIdPropertyName("region" );
		colonneId.setPropertyName("region");
		colonnes.add(colonneId);

		ColumnDescription colonneNonId = new ColumnDescription();
		colonneNonId.setAutoPrimaryKey(false);
		colonneNonId.setPrimaryKey(false);
		colonneNonId.setClassName("java.lang.String");
		colonneNonId.setColumnName("TEST");
		colonneNonId.setForeignKey(false);
		colonneNonId.setIdPropertyName("test");
		colonneNonId.setPropertyName("test");
		colonnes.add(colonneNonId);

		description.setColumnList(colonnes);

		description.setEntityClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016");

		Map<String, Object> resultatAttendu = new HashMap<String,Object>();
		resultatAttendu.put("region", "PACA");
		assertEquals(resultatAttendu,IntrospectionUtils.getPrimaryKeysNameAndValues(value, description));
	}

	@Test
	public void testGetPrimaryKeysNameAndValuesTaCommuneInsee() throws Exception {
		//Table avec deux colonnes clefs primaires dont une est clef étrangère avec un autre nom
		TaCommuneInsee value = new TaCommuneInsee();
		TaTerritorialiteFicobaLmtay508 taTerritorialiteFicobaLmtay508 = new TaTerritorialiteFicobaLmtay508();
		taTerritorialiteFicobaLmtay508.setCte("A");
		TaRegion2016 taRegion2016 = new TaRegion2016();
		taRegion2016.setRegion("01");
		TaRegionAdministrativeLmtay547 taRegionAdministrativeLmtay547 = new TaRegionAdministrativeLmtay547();
		taRegionAdministrativeLmtay547.setYc0rgi("10");
		taRegionAdministrativeLmtay547.setTaRegion2016(taRegion2016);
		TaDepartement taDepartement = new TaDepartement();
		taDepartement.setYc0dep("101");
		taDepartement.setTaRegion2016(taRegion2016);
		taDepartement.setTaRegionAdministrativeLmtay547(taRegionAdministrativeLmtay547);
		taDepartement.setTaTerritorialiteFicobaLmtay508(taTerritorialiteFicobaLmtay508);
		TaArticleMajuscule taArticleMajuscule = new TaArticleMajuscule();
		taArticleMajuscule.setArtmaj("AAAAA");
		TaArticleTypographieRiche taArticleTypographieRiche = new TaArticleTypographieRiche();
		taArticleTypographieRiche.setArtmin("aaaaa");
		TaTypeDeNomEnClair taTypeDeNomEnClair = new TaTypeDeNomEnClair();
		taTypeDeNomEnClair.setTncc("A");
		TaTopDecoupageCommuneCantons taTopDecoupageCommuneCantons = new TaTopDecoupageCommuneCantons();
		taTopDecoupageCommuneCantons.setCdc("B");
		TaTopChefLieu taTopChefLieu = new TaTopChefLieu();
		taTopChefLieu.setTchefl("C");
		TaIdentifiantCommune taIdentifiantCommune = new TaIdentifiantCommune();
		taIdentifiantCommune.setIdcom("MET");
		value.setTaDepartement(taDepartement);
		value.setCom("888");
		value.setTaArticleMajuscule(taArticleMajuscule);
		value.setTaArticleTypographieRiche(taArticleTypographieRiche);
		value.setTaIdentifiantCommune(taIdentifiantCommune);
		value.setTaRegion2016(taRegion2016);
		value.setTaRegionAdministrativeLmtay547(taRegionAdministrativeLmtay547);
		value.setTaTopChefLieu(taTopChefLieu);
		value.setTaTypeDeNomEnClair(taTypeDeNomEnClair);
		value.setTaTopDecoupageCommuneCantons(taTopDecoupageCommuneCantons);


		TableDescription description = new TableDescription();

		ArrayList<ColumnDescription> colonnes = new ArrayList<ColumnDescription>();

		ColumnDescription colonneId1 = new ColumnDescription();
		colonneId1.setAutoPrimaryKey(false);
		colonneId1.setPrimaryKey(true);
		colonneId1.setClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaDepartement");
		colonneId1.setColumnName("YC0DEP" );
		colonneId1.setForeignKey(true);
		colonneId1.setIdPropertyName("taDepartement" );
		colonneId1.setPropertyName("taDepartement");
		colonnes.add(colonneId1);

		ColumnDescription colonneId2 = new ColumnDescription();
		colonneId2.setAutoPrimaryKey(false);
		colonneId2.setPrimaryKey(true);
		colonneId2.setClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaCommuneInsee");
		colonneId2.setColumnName("COM");
		colonneId2.setForeignKey(false);
		colonneId2.setIdPropertyName("com" );
		colonneId2.setPropertyName("com");
		colonnes.add(colonneId2);

		ColumnDescription colonneNonId = new ColumnDescription();
		colonneNonId.setAutoPrimaryKey(false);
		colonneNonId.setPrimaryKey(false);
		colonneNonId.setClassName("java.lang.String");
		colonneNonId.setColumnName("TEST");
		colonneNonId.setForeignKey(false);
		colonneNonId.setIdPropertyName("test");
		colonneNonId.setPropertyName("test");
		colonnes.add(colonneNonId);


		description.setColumnList(colonnes);

		description.setEntityClassName("fr.icdc.dei.lm4.paraneo.entite.transverse.TaCommuneInsee");

		Map<String, Object> resultatAttendu = new HashMap<String,Object>();
		resultatAttendu.put("taDepartement.yc0dep", "101");
		resultatAttendu.put("com", "888");
		assertEquals(resultatAttendu,IntrospectionUtils.getPrimaryKeysNameAndValues(value, description));
	}

}
