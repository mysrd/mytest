package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import java.lang.annotation.Annotation;
import java.math.BigDecimal;

import javax.validation.Payload;

import org.junit.Test;

public class CaracAutorisesDecimalAvecFractionValidatorTest {

	private void initTestDecimal(CaracAutorisesDecimalAvecFractionValidator validator) {
		CaracAutorisesDecimalAvecFraction annotation = new CaracAutorisesDecimalAvecFraction() {

			@Override
			public Class<? extends Annotation> annotationType() {
				return null;
			}

			@Override
			public Class<? extends Payload>[] payload() {
				return null;
			}

			@Override
			public int nbMax() {				// La zone saisie contient au plus 5 caractères
				return 5;
			}

			@Override
			public int nbDec() {				// La zone saisie contient 2 décimales
				return 2;
			}

			@Override
			public String message() {
				return null;
			}

			@Override
			public Class<?>[] groups() {
				return null;
			}
		};
		validator.initialize(annotation);
	}

	@Test
	public void test1(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(new BigDecimal("1"), null));

	}

	@Test
	public void test2(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
//		assertEquals(true, validator.isValid(new BigDecimal(1.4, new MathContext(2)), null));
		assertEquals(true, validator.isValid(new BigDecimal("1.4"), null));

	}

	@Test
	public void test3(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(new BigDecimal("1.43"), null));

	}

	@Test
	public void test4(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(new BigDecimal("12"), null));

	}

	@Test
	public void test5(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(new BigDecimal("12.4"), null));

	}

	@Test
	public void test6(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(new BigDecimal("12.42"), null));

	}

	@Test
	public void test7(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid(new BigDecimal("123"), null));

	}

	@Test
	public void test8(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid(new BigDecimal("123456"), null));

	}

	@Test
	public void test9() {
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid(new BigDecimal("1.127"), null));
	}

	@Test
	public void test10(){
		CaracAutorisesDecimalAvecFractionValidator validator = new CaracAutorisesDecimalAvecFractionValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid(new BigDecimal("0"), null));

	}

}
