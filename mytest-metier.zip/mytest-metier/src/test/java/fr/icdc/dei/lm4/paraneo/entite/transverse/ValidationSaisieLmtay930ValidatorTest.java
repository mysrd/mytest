package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidationSaisieLmtay930ValidatorTest {

	@Test
	public void testBlancEtOui(){
		ValidationSaisieLmtay930Validator validator = new ValidationSaisieLmtay930Validator();
		TaCategorieEconomiqueLmtay930 valeur = genererDonnees(" ","O");
		assertEquals(false,validator.isValid(valeur, null));
	}


	@Test
	public void testBlancEtNon(){
		ValidationSaisieLmtay930Validator validator = new ValidationSaisieLmtay930Validator();
		TaCategorieEconomiqueLmtay930 valeur = genererDonnees(" ","N");
		assertEquals(true,validator.isValid(valeur, null));

	}

	@Test
	public void testDifferentDeBlancEtOui(){
		ValidationSaisieLmtay930Validator validator = new ValidationSaisieLmtay930Validator();
		TaCategorieEconomiqueLmtay930 valeur = genererDonnees("XX","O");
		assertEquals(true,validator.isValid(valeur, null));
	}


	@Test
	public void testDifferentDeBlancEtNon(){
		ValidationSaisieLmtay930Validator validator = new ValidationSaisieLmtay930Validator();
		TaCategorieEconomiqueLmtay930 valeur = genererDonnees("XX","N");
		assertEquals(false,validator.isValid(valeur, null));

	}
	@Test
	public void mauvaisType(){
		ValidationSaisieLmtay930Validator validator = new ValidationSaisieLmtay930Validator();
		assertEquals(false,validator.isValid("Babar", null));

	}

	private TaCategorieEconomiqueLmtay930 genererDonnees(String valeurBlanc, String valeurOuiNon) {
		TaCategorieEconomiqueLmtay930 valeur = new TaCategorieEconomiqueLmtay930();

		TaChoixOuiNon taChoixOuiNonByYtopta = new TaChoixOuiNon();
		taChoixOuiNonByYtopta.setCodeChoixOuiNon(valeurOuiNon);
		valeur.setTaChoixOuiNonByYtopta(taChoixOuiNonByYtopta);

		TaFamilleDeCatgEcoAnalyseLmtay530 taFamilleDeCatgEcoAnalyseLmtay530 = new TaFamilleDeCatgEcoAnalyseLmtay530();
		taFamilleDeCatgEcoAnalyseLmtay530.setCfceco(valeurBlanc);
		valeur.setTaFamilleDeCatgEcoAnalyseLmtay530(taFamilleDeCatgEcoAnalyseLmtay530);
		return valeur;
	}



}
