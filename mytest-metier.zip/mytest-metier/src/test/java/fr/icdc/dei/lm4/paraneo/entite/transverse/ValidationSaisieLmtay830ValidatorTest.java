package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidationSaisieLmtay830ValidatorTest {

	@Test
	public void test999EtBlanc(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		TaCategorieDeContrepartieBicLmtay830 valeur = genererDonnees("999"," ");
		assertEquals(true,validator.isValid(valeur, null));
	}

	@Test
	public void test999Et00(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		TaCategorieDeContrepartieBicLmtay830 valeur = genererDonnees("999","00 ");
		assertEquals(true,validator.isValid(valeur, null));
	}

	@Test
	public void test999EtNon00EtNonBlanc(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		TaCategorieDeContrepartieBicLmtay830 valeur = genererDonnees("999","01");
		assertEquals(false,validator.isValid(valeur, null));

	}

	@Test
	public void testNon999EtBlanc(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		TaCategorieDeContrepartieBicLmtay830 valeur = genererDonnees("125"," ");
		assertEquals(false,validator.isValid(valeur, null));

	}

	@Test
	public void testNon999Et00(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		TaCategorieDeContrepartieBicLmtay830 valeur = genererDonnees("998","00 ");
		assertEquals(false,validator.isValid(valeur, null));

	}

	@Test
	public void testNon999EtNon00EtNonBlanc(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		TaCategorieDeContrepartieBicLmtay830 valeur = genererDonnees("998","01");
		assertEquals(true,validator.isValid(valeur, null));

	}

	@Test
	public void mauvaisType(){
		ValidationSaisieLmtay830Validator validator = new ValidationSaisieLmtay830Validator();
		assertEquals(false,validator.isValid("Babar", null));

	}

	private TaCategorieDeContrepartieBicLmtay830 genererDonnees(String valeurCagbic, String valeurCagsis) {
		TaCategorieDeContrepartieBicLmtay830 valeur = new TaCategorieDeContrepartieBicLmtay830();

		TaCodeAgentEcoSistre taCodeAgentEcoSistre = new TaCodeAgentEcoSistre();
		taCodeAgentEcoSistre.setCagsis(valeurCagsis);
		valeur.setTaCodeAgentEcoSistre(taCodeAgentEcoSistre);
		valeur.setCagbic(valeurCagbic);
		return valeur;
	}

}
