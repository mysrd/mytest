package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import org.junit.Test;

import fr.icdc.dei.lm4.paraneo.entite.transverse.LigneHexaposte;
import fr.icdc.dei.lm4.paraneo.metier.service.HexaposteService;
import fr.icdc.dei.lm4.paraneo.metier.service.impl.HexaposteServiceImpl;
import static org.junit.Assert.*;

public class TraitementHexaposteTest {

	@Test
	public void testDecomposerLigneHexaposteLignePartielle()  {
		HexaposteService service = new HexaposteServiceImpl();
		final String ligneDeTest = "38336 98756UA HUKA                               1MUA HUKA                               98744VAIPAEE                               9875622223";
		LigneHexaposte ligneHexaposte = service.decomposerLigneHexaposte(ligneDeTest);
		
		assertEquals("Identifiant","38336 ", ligneHexaposte.getIdentifiant());
		assertEquals("Code INSEE","98756", ligneHexaposte.getCodeINSEE());
		assertEquals("Libelle commune","UA HUKA                               ",ligneHexaposte.getLibelle());
		assertEquals("Pluridistribution","1", ligneHexaposte.getIndicateurDePluridistribution());
		assertEquals("Type code postal","M", ligneHexaposte.getTypeCodePostal());
		assertEquals("Libelle ligne 5","UA HUKA                               ",ligneHexaposte.getLibelleLigne5());
		assertEquals("Code postal","98744", ligneHexaposte.getCodePostal());
		assertEquals("Libelle acheminement","VAIPAEE                         ",ligneHexaposte.getLibelleAcheminement());
		assertEquals("Code INSEE ancienne commune","     ",ligneHexaposte.getCodeINSEEAncienneCommune());
		assertEquals("Code de mise a jour"," ",ligneHexaposte.getCodeDeMiseAJour());
		assertEquals("CEA","9875622223",ligneHexaposte.getCEA());
	}

	@Test
	public void testDecomposerLigneHexaposteLigneArmee() {
		HexaposteService service = new HexaposteServiceImpl();
		final String ligneDeTest = "547830                                           0C                                      00272ARMEES                                          ";
		LigneHexaposte ligneHexaposte = service.decomposerLigneHexaposte(ligneDeTest);
		assertEquals("Identifiant","547830", ligneHexaposte.getIdentifiant());
		assertEquals("Code INSEE","     ", ligneHexaposte.getCodeINSEE());
		assertEquals("Libelle commune","                                      ",ligneHexaposte.getLibelle());
		assertEquals("Pluridistribution","0", ligneHexaposte.getIndicateurDePluridistribution());
		assertEquals("Type code postal","C", ligneHexaposte.getTypeCodePostal());
		assertEquals("Libelle ligne 5","                                      ",ligneHexaposte.getLibelleLigne5());
		assertEquals("Code postal","00272", ligneHexaposte.getCodePostal());
		assertEquals("Libelle acheminement","ARMEES                          ",ligneHexaposte.getLibelleAcheminement());
		assertEquals("Code INSEE ancienne commune","     ",ligneHexaposte.getCodeINSEEAncienneCommune());
		assertEquals("Code de mise a jour"," ",ligneHexaposte.getCodeDeMiseAJour());
		assertEquals("CEA","          ",ligneHexaposte.getCEA());

		
	}
	
	@Test
	public void testDecomposerLigneHexaposteLigneComplete(){
		HexaposteService service = new HexaposteServiceImpl();
		final String ligneDeTest ="1303  24168PLAISANCE                             0MFALGUEYRAT                            24560PLAISANCE                       24173 241682229Y";
		LigneHexaposte ligneHexaposte = service.decomposerLigneHexaposte(ligneDeTest);
		assertEquals("Identifiant","1303  ", ligneHexaposte.getIdentifiant());
		assertEquals("Code INSEE","24168", ligneHexaposte.getCodeINSEE());
		assertEquals("Libelle commune","PLAISANCE                             ",ligneHexaposte.getLibelle());
		assertEquals("Pluridistribution","0", ligneHexaposte.getIndicateurDePluridistribution());
		assertEquals("Type code postal","M", ligneHexaposte.getTypeCodePostal());
		assertEquals("Libelle ligne 5","FALGUEYRAT                            ",ligneHexaposte.getLibelleLigne5());
		assertEquals("Code postal","24560", ligneHexaposte.getCodePostal());
		assertEquals("Libelle acheminement","PLAISANCE                       ",ligneHexaposte.getLibelleAcheminement());
		assertEquals("Code INSEE ancienne commune","24173",ligneHexaposte.getCodeINSEEAncienneCommune());
		assertEquals("Code de mise a jour"," ",ligneHexaposte.getCodeDeMiseAJour());
		assertEquals("CEA","241682229Y",ligneHexaposte.getCEA());

	}
}
