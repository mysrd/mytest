package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import fr.icdc.dei.lm4.paraneo.metier.service.MailService;

@Service("mailService")
public class MailServiceImpl implements MailService {
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	@Qualifier("destinataires")
	private String destinaires;
	
	private static final Logger LOGGER = Logger.getLogger(MailServiceImpl.class);

	public void envoyerMail(String objet, String texte ){
		try {
			MimeMessage msg = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(msg,true); // true car piece jointe
			helper.setTo(obtenirDestinataires(destinaires));
			helper.setSubject(objet);
			helper.setText(texte);
			mailSender.send(msg);
		} catch(MailException | MessagingException e){
			LOGGER.debug(e);
		}

	}

	public void envoyerMailAvecPieceJointe(String objet, String texte, byte[] pieceJointe, String nomPieceJointe){
		try {
			MimeMessage msg = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(msg,true); // true car piece jointe
			helper.setTo(obtenirDestinataires(destinaires));
			helper.setSubject(objet);
			helper.setText(texte);
			
			helper.addAttachment(nomPieceJointe, new ByteArrayResource(pieceJointe));
			mailSender.send(msg);
		} catch(MailException | MessagingException e){
			LOGGER.debug(e);
		}

	}
	
	private String[] obtenirDestinataires(String destinataires){
		return destinaires.split(";");
	}


}
