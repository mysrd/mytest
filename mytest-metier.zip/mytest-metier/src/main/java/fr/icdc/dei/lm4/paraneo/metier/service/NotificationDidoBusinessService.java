package fr.icdc.dei.lm4.paraneo.metier.service;

import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

public interface NotificationDidoBusinessService {

	public void envoyerNotificationCreationSimple(String identifiant, String typeObjet);
	
	public void envoyerNotificationModificationSimple(String identifiant, String typeObjet);
	
	public void envoyerNotificationCreation(Object enregistrement,TableDescription description) throws BusinessServiceException;

	public void envoyerNotificationModification(Object enregistrement,TableDescription description) throws BusinessServiceException;

	public void envoyerNotificationSuppression(Object enregistrement,TableDescription description) throws BusinessServiceException;

}
