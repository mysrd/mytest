package fr.icdc.dei.edt.core.converter;

import java.math.BigInteger;

public class BigIntegerConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.BigIntegerConverter";

	public BigIntegerConverter() {
	}

	public Object getAsObject(String value) throws ConverterException {

		if (value != null) {
			value = value.trim();
			if (value.length() > 0) {
				try {
					return new BigInteger(value.trim());
				} catch (NumberFormatException e) {
					throw new ConverterException(CONVERSION_MESSAGE_ID, e);
				}
			}
		}
		return null;
	}

	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}
		return ((BigInteger) value).toString();
	}

	private String label;

	public void setLabel(String label) {
		this.label = label;
	}
}
