package fr.icdc.dei.edt.core.converter;

public class CharacterConverter implements Converter {

	//private static final String CONVERSION_MESSAGE_ID = "edittables.converter.CharacterConverter";
	
	public CharacterConverter() {
	}

	public Object getAsObject(String value) throws ConverterException {

		if (value != null) {
			value = value.trim();
			if (value.length() > 0) {
				return new Character(value.charAt(0));
			}
		}
		return null;
	}

	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}
		return ((Character) value).toString();
	}

	private String label;
	
	public void setLabel(String label) {
		this.label = label;	
	}
}
