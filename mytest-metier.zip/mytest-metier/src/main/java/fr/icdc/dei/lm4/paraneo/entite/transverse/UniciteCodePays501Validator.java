package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;

/**
* Verifie que le code pays ISO 2 saisi n'existe pas deja dans la table
* @author porsini
*
*/
public class UniciteCodePays501Validator extends DatabaseAccess implements ConstraintValidator<UniciteCodePays501, TaPaysLmtay501> {
	@Autowired
	private ReferentielBusinessService referentielService;

	private ChampsValidables501 nomChamp;	// Nom du champ testé

	@Override
    public void initialize(UniciteCodePays501 constraintAnnotation) {
		this.nomChamp = constraintAnnotation.nomChamp();
    }

    @Override
    public boolean isValid(TaPaysLmtay501 classeValidee, ConstraintValidatorContext context) {

    	String valeurDuChamp = null;
    	if(nomChamp.name().equals("CNPAYA")){
    		valeurDuChamp = classeValidee.getCnpaya();
    		if (StringUtils.isBlank(valeurDuChamp)){		// Le champ CNPAYA peut être à blanc. Dans ce cas, on ne le teste pas.
    			return true;
    		}
    	} else if(nomChamp.name().equals("CPAYI2")) {
    		valeurDuChamp = classeValidee.getCpayi2();
    	}

    	return this.referentielService.verifUniciteCodePays501(classeValidee.getCpay(),valeurDuChamp, nomChamp.name());
    }
}
