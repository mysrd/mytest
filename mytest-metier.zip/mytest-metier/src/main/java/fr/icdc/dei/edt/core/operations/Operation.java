package fr.icdc.dei.edt.core.operations;

import java.io.Serializable;
import java.util.List;

public interface Operation extends Serializable {

	boolean isEnabled();
	
	List<String> getRoles();
}
