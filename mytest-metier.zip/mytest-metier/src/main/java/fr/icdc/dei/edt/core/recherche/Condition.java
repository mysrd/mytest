package fr.icdc.dei.edt.core.recherche;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Classe qui représente une condition de recherche.
 * @author mabdennebi-e
 *
 */
public class Condition implements Serializable {

	public static final String CONTAINS = "CONTAINS";

	public static final String EQUALS = "EQUALS";

	public static final String STARTS_WITH = "STARTS_WITH";

	public static final String MORE_THAN = "MORE_THAN";

	public static final String LESS_THAN = "LESS_THAN";

	public static final String EQUALS_OR_MORE_THAN = "EQUALS_OR_MORE_THAN";

	public static final String EQUALS_OR_LESS_THAN = "EQUALS_OR_LESS_THAN";

	public static final String BETWEEN = "BETWEEN";

	public static final String EMPTY = "EMPTY";

	private boolean not;

	private String propertyName;

	private String searchOption;

	private Object value;

	private Object value1;

	public boolean isNot() {
		return not;
	}

	public void setNot(boolean not) {
		this.not = not;
	}

	public String getSearchOption() {
		return searchOption;
	}

	//lève une exception si le type de l'opération n'est pas supportée
	// IllegalArgumentException
	public void setSearchOption(String operationType) {
		this.searchOption = operationType;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Object getValue1() {
		return value1;
	}

	public void setValue1(Object value1) {
		this.value1 = value1;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return new ToStringBuilder(this).append("propertyName",
				this.propertyName).append("searchOption", this.searchOption)
				.append("value", this.value).append("not", this.not).append(
						"value1", this.value1).toString();
	}



}
