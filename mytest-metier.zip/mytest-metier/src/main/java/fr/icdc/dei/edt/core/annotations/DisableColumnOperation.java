/**
 * 
 */
package fr.icdc.dei.edt.core.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette annotation permet de prohiber des opérations relatives aux colonnes.  
 * @author ffernandez-e
 *
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface DisableColumnOperation {
	/**
	 * Liste des opérations prohibées
	 * @return
	 */
	ColumnOperationsEnum[] operations();
}
