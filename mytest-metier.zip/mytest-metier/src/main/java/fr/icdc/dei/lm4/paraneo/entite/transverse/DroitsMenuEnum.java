package fr.icdc.dei.lm4.paraneo.entite.transverse;

public enum DroitsMenuEnum {

	/**
	 * Consultation.
	 */
	CONSULTATION(1, "Consultation", "Consultation"),

	/**
	 * Suivi
	 */
	SUIVI(2, "Suivi", "Suivi"),

	/**
	 * Administration
	 */
	ADMINISTRATION(4, "Administration", "Administration"),

	/**
	 * Référentiel
	 */
	REFERENTIEL(8, "Référentiel", "Referentiel"),

	/**
	 * Bancaire
	 */
	BANCAIRE(16, "Bancaire", "Bancaire");

	private Integer code;
	private String libelle;
	private String gideCode;

	private DroitsMenuEnum(Integer code, String libelle, String gideCode) {
		this.code = code;
		this.libelle = libelle;
		this.gideCode = gideCode;
	}

	public Integer getCode() {
		return code;
	}

	public String getLibelle() {
		return this.libelle;
	}

	/**
	 * @param gideCode
	 *            the gideCode to set
	 */
	public void setGideCode(String gideCode) {
		this.gideCode = gideCode;
	}

	/**
	 * @return the gideCode
	 */
	public String getGideCode() {
		return gideCode;
	}

}
