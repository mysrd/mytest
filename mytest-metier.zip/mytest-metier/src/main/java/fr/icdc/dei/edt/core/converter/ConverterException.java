package fr.icdc.dei.edt.core.converter;

import fr.icdc.dei.edt.core.exception.EditTableException;


public class ConverterException extends EditTableException {

	private static final long serialVersionUID = 8668056061177480197L;
	
	private Object[] value;

	private EditTableException error;

	public ConverterException() {
		super();
	}

	public ConverterException(String message) {
		super(message);
	}
	
	public ConverterException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public ConverterException(String message, Object[] value) {
		super(message);
		if (value != null) {
			this.value = value.clone();
		} else {
			this.value = null;
		}		
	}

	public ConverterException(String message, Throwable cause, Object[] value) {
		super(message, cause);
		if (value != null) {
			this.value = value.clone();
		} else {
			this.value = null;
		}
	}

	public ConverterException(Throwable cause) {
		super(cause);
	}

	public Object[] getValue() {
		if (value != null) {
			return value.clone();
		} else {
			return null;
		}
	}

	public EditTableException getError() {
		return error;
	}

}
