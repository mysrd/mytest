package fr.icdc.dei.lm4.paraneo.metier.service;

public enum EtatTraitement {
	
	OK("OK"),
	KO("KO");
	
	private final String valeur;
	
	private EtatTraitement(String valeur) {
		this.valeur = valeur;
	}
	
	public String getValeur(){
		return this.valeur;
	}

}
