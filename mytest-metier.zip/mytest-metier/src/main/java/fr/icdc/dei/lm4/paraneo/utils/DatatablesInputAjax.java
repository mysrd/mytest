package fr.icdc.dei.lm4.paraneo.utils;

import java.util.Map;


public class DatatablesInputAjax {
	private Map<String,DatatablesColumnAjax> columns;
	
	private DatatablesSearchAjax search;

	public Map<String, DatatablesColumnAjax> getColumns() {
		return columns;
	}

	public void setColumns(Map<String, DatatablesColumnAjax> columns) {
		this.columns = columns;
	}

	public DatatablesSearchAjax getSearch() {
		return search;
	}

	public void setSearch(DatatablesSearchAjax search) {
		this.search = search;
	}
	
	
	
}
