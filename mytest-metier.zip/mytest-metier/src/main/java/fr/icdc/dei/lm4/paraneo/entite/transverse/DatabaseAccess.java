package fr.icdc.dei.lm4.paraneo.entite.transverse;

/**
 * A heriter par les classes de validation souhaitant acceder a la base
 * @author porsini
 *
 */

public abstract class DatabaseAccess {

//	@Resource(name = "editTablesBusinessService")
//	ReferentielBusinessService referentielService;
}
