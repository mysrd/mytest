package fr.icdc.dei.edt.core.description;

public interface ColumnDescriptionBuilder {

	ColumnDescription build();
}
