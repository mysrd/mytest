package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Horodatage;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;

@Component
public class CompteurClosCalcul implements ClasseDeCalcul {

	@Resource(name = "editTablesBusinessService")
	private ReferentielBusinessService service;

	
	@Override
	@Transactional
	public String calculer(String parametre) throws BusinessServiceException {
		try {
			String nomClasse = IntrospectionUtils.getClassNameFromTableName(service.getTableList(), parametre);
			if(Horodatage.class.isAssignableFrom(Class.forName(nomClasse))){
				return String.valueOf(service.countClos(nomClasse));
			} else {
				return "N/A";
			}
		} catch(ClassNotFoundException e){
			throw new BusinessServiceException(e);
		}
	}

}
