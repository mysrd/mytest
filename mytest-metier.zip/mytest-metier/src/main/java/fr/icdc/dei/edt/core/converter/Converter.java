package fr.icdc.dei.edt.core.converter;

import java.io.Serializable;

public interface Converter extends Serializable {
	
	/**
	 * Crée un objet à partir d'une String.
	 */
	Object getAsObject(String value) throws ConverterException;

	/**
	 * Retourne l'objet sous forme de String.
	 */
	String getAsString(Object value) throws ConverterException;

	/**
	 * @param label Le nom du champ à convertir.
	 */
	void setLabel(String label);
}
