package fr.icdc.dei.edt.core.converter;


public class IntegerConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.IntegerConverter";
	public IntegerConverter() {
	}

	public Object getAsObject(String value) throws ConverterException {

		if (value != null) {
			value = value.trim();
			if (value.length() > 0) {
				try {
					return Integer.valueOf(value);
				} catch (NumberFormatException e) {
					throw new ConverterException(CONVERSION_MESSAGE_ID, e);
				}
			}
		}
		return null;
	}

	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}
		return Integer.toString(((Number) value).intValue());
	}
	
	private String label;
	
	public void setLabel(String label) {
		this.label = label;	
	}
}
