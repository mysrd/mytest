package fr.icdc.dei.edt.core.recherche;

import java.io.Serializable;

/**
 * OrderBy est une classe qui stock les régles de tri : le nom de la colonne
 * et la direction du tier : ascendant ou desendant.
 * 
 * @author abdennebi 25 aout 2009
 *
 */
public class OrderBy implements Serializable{

	private static final long serialVersionUID = 3957622687230507613L;

	/**
	 * nom de la colonne sur laquelle effectuer le tri.
	 */
	private String columnName;
	
	/**
	 * Direction du tri : asc ou desc.
	 */
	private String direction;
	
	public OrderBy(String columnName, String direction) {
		this.columnName = columnName;
		this.direction = direction;
	}

	public String getColumnName() {
		return columnName;
	}

	public String getDirection() {
		return direction;
	}	
}
