package fr.icdc.dei.lm4.paraneo.utils;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;

@Component("localizationUtil")
public class LocalizationUtil {
	@Autowired
	private ReloadableResourceBundleMessageSource messageSource;

	public String obtenirLibelle(String code) {
		return messageSource.getMessage(code, null, Locale.FRENCH);
	}

}
