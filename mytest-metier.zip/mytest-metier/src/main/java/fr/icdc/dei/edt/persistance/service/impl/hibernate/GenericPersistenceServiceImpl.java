package fr.icdc.dei.edt.persistance.service.impl.hibernate;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.TransactionException;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;

import fr.icdc.dei.edt.core.Auditable;
import fr.icdc.dei.edt.core.ConfigurationService;
import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.core.recherche.Condition;
import fr.icdc.dei.edt.core.recherche.OrderBy;
import fr.icdc.dei.edt.persistance.service.GenericPersistenceService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesColumnAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesInputAjax;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;

/**
 * Implémentation Hibernate du service de persistance
 * <code>ReferentielPersistenceService</code>.
 *
 * @author abdennebi
 * @author daboulkheir-e
 */
@Service("editTablesPersistanceService")
public class GenericPersistenceServiceImpl implements GenericPersistenceService {

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	private List<TaLibelleColonneTable> libellesColonneTable;
	
	private Map<String,List<String>> ordreColonnes = new HashMap<String, List<String>>();
	
	private static final Logger LOGGER = Logger.getLogger(GenericPersistenceServiceImpl.class);

	public List<TableDescription> selectListTables() throws BusinessServiceException {
		List<TableDescription> result;

		result = configurationService.getTableList();

		return result;
	}

	public Object findById(Class<?> clazz, Serializable id) throws BusinessServiceException {
		try {
			return sessionFactory.getCurrentSession().get(clazz, id);
		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Object> findAll(String className) throws BusinessServiceException {

		List<Object> liste = new ArrayList<Object>();
		try {
			liste = sessionFactory.getCurrentSession().createQuery("select ent FROM " + className + " as ent").list();
		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
		return liste;
	}

	public void create(Object entity) throws BusinessServiceException {
		this.sessionFactory.getCurrentSession().save(entity);
	}

	public void update(Object entity) throws BusinessServiceException {
		try {
			this.sessionFactory.getCurrentSession().update(entity);
			if (entity instanceof Auditable) {
				Auditable auditable = (Auditable) entity;
				auditable.setPrincipal(((Auditable) entity).getPrincipal());
			}

		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
	}

	public void delete(Object obj) throws BusinessServiceException {

		try {
			sessionFactory.getCurrentSession().delete(obj);
		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
	}

	public int count(Class<?> persistentClass) throws BusinessServiceException {

		try {
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(persistentClass);
			Long count =  (Long) criteria.setProjection(Projections.rowCount()).uniqueResult();
			return count.intValue();
		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
	}

	public int countForConditions(Class<?> persistentClass, List<Condition> conditions) throws BusinessServiceException {

		try {

			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(persistentClass);
			Integer count = (Integer) addConditionsToCriteria(criteria, conditions).setProjection(Projections.rowCount()).uniqueResult();

			return count.intValue();

		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Object> findAll(Class<?> clazz, int firstResult, int maxResults) throws BusinessServiceException {

		if (firstResult < 0)
			throw new IllegalArgumentException("La valeur de firstResult doit être au moins égale à zero");
		if (maxResults < 1)
			throw new IllegalArgumentException("La valeur de maxResults doit être au moins égale à un");

		List<Object> enregistrements;
		try {
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(clazz);
			criteria.setFirstResult(firstResult);
			criteria.setMaxResults(maxResults);
			enregistrements = criteria.list();

			return enregistrements;

		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}
	}


	@SuppressWarnings("unchecked")
	public List<Object> findAll(Class<?> clazz, List<Condition> conditions, int firstResult, Integer maxResults, List<OrderBy> orderByList)
			throws BusinessServiceException {

		if (firstResult < 0)
			throw new IllegalArgumentException("La valeur de firstResult doit �tre au moins �gale � zero");
		if (maxResults != null && maxResults < 1)
			throw new IllegalArgumentException("La valeur de maxResults doit �tre au moins �gale � un");

		List<Object> enregistrements;
		try {
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(clazz);
			criteria.setFirstResult(firstResult);

			if(maxResults != null){
				criteria.setMaxResults(maxResults);
			}

			if (orderByList != null) {

				for (OrderBy orderby : orderByList) {

					String columnName = orderby.getColumnName();
					String direction = orderby.getDirection();

					if (columnName != null && direction != null) {
						Order order;
						if ("asc".equals(direction)) {
							order = Order.asc(columnName);
						} else {
							order = Order.desc(columnName);
						}
						criteria.addOrder(order);
					}
				}
			}

			enregistrements = addConditionsToCriteria(criteria, conditions).list();

			return enregistrements;

		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> findAll(String className, List<Condition> conditions)
	throws BusinessServiceException {
		List<Object> liste = new ArrayList<Object>();
		Map<String, Object> parameters = new HashMap<String, Object>();

		try {
			String queryString = "select ent FROM " + className + " as ent";
			for(int i=0; i< conditions.size(); i++){
				if(i==0){
					queryString += " where ";
				} else {
					queryString += " and ";
				}
				Condition condition = conditions.get(i);

				String property = condition.getPropertyName();

				Object value = condition.getValue();

				String searchOption = condition.getSearchOption();

				if (value == null || ((value instanceof String) && ((String) value).trim().equals(""))) {
					if (searchOption.equals(Condition.EMPTY)) {
						boolean isNot = condition.isNot();
						if (isNot) {
							queryString += "ent." +property + " is not null";
						} else {
							queryString += "ent." +property + " is null";
						}
					}
				} else {

					Object value1 = condition.getValue1();

					if (searchOption.equals(Condition.BETWEEN)) {

						if (value1 != null) {
							queryString += "ent." +property + " between "+ ":param"+i +" and " + ":param"+i+"1";
							parameters.put("param"+i, value);
							parameters.put("param"+i+"1", value1);

						}
					}

					if (searchOption.equals(Condition.EMPTY)) {

						queryString += "ent." + property + " is null";

					}
					if (searchOption.equals(Condition.EQUALS)) {

						queryString += "ent." + property + " = " + value;
					}
					if (searchOption.equals(Condition.EQUALS_OR_LESS_THAN)) {

						queryString += "ent." + property + " <= " + value;
					}
					if (searchOption.equals(Condition.EQUALS_OR_MORE_THAN)) {

						queryString += "ent." + property + " >= " + value;
					}
					if (searchOption.equals(Condition.LESS_THAN)) {

						queryString += "ent." + property + " < " + value;
					}
					if (searchOption.equals(Condition.MORE_THAN)) {

						queryString += "ent." + property + " > " + value;
					}
					if (searchOption.equals(Condition.STARTS_WITH)) {
						queryString += "ent." + property + " = " + value + "%";
					}
					if (searchOption.equals(Condition.CONTAINS)) {
						queryString += "ent." + property + " = %" + value+ "%";
					}
				}
			}
			Query q = sessionFactory.getCurrentSession().createQuery(queryString);
			//Ajout des paramètres
			for(Entry<String, Object> entry : parameters.entrySet()){
				q.setParameter(entry.getKey(), entry.getValue());
			}
			liste = q.list();
		} catch (TransactionException tEx) {
			throw new BusinessServiceException(tEx);
		}

		return liste;

}


	/**
	 * Ajoute une liste de conditions à l'objet Hibernate Criteria.
	 */
	@SuppressWarnings("rawtypes")
	private Criteria addConditionsToCriteria(Criteria criteria, List<Condition> conditions) throws TransactionException {

		if (conditions == null)
			return criteria;

		else
			for (Iterator iter = conditions.iterator(); iter.hasNext();) {

				Condition condition = (Condition) iter.next();

				String property = condition.getPropertyName();

				Object value = condition.getValue();

				String searchOption = condition.getSearchOption();

				boolean isNot = condition.isNot();

				Criterion criterion = null;

				if (value == null || ((value instanceof String) && ((String) value).trim().equals(""))) {
					if (searchOption.equals(Condition.EMPTY)) {
						if (isNot) {
							criterion = Restrictions.isNotNull(property);
						} else {
							criterion = Restrictions.isNull(property);
						}
					}
				}

				else {

					Object value1 = condition.getValue1();

					if (searchOption.equals(Condition.BETWEEN)) {

						if (value1 == null) {
							continue;
						}
						criterion = Restrictions.between(property, value, value1);
					}

					if (searchOption.equals(Condition.EMPTY)) {

						criterion = Restrictions.isNull(property);

					}
					if (searchOption.equals(Condition.EQUALS)) {

						criterion = Restrictions.eq(property, value);
					}
					if (searchOption.equals(Condition.EQUALS_OR_LESS_THAN)) {

						criterion = Restrictions.le(property, value);
					}
					if (searchOption.equals(Condition.EQUALS_OR_MORE_THAN)) {

						criterion = Restrictions.ge(property, value);
					}
					if (searchOption.equals(Condition.LESS_THAN)) {

						criterion = Restrictions.lt(property, value);
					}
					if (searchOption.equals(Condition.MORE_THAN)) {

						criterion = Restrictions.gt(property, value);
					}
					if (searchOption.equals(Condition.STARTS_WITH)) {
						try {
							criterion = Restrictions.ilike(property, (String) value, MatchMode.START);
						} catch (ClassCastException e) {
							// Si il ya ClassCastException ceci constitue un
							// erreur du programmeur
							// car STARTS_WITH et CONTAINS ne s'appliquent que
							// sur les Strings
							throw new RuntimeException(e);
						}
					}
					if (searchOption.equals(Condition.CONTAINS)) {
						try {
							criterion = Restrictions.ilike(property, (String) value, MatchMode.ANYWHERE);
						} catch (ClassCastException e) {
							throw new RuntimeException(e);
						}
					}

					if (isNot) {
						criterion = Restrictions.not(criterion);
					}
				}

				if (criterion != null)
					criteria.add(criterion);
			}

		return criteria;

	}

	public List<String> getColumnsOrder(String tableName) {

		if(ordreColonnes.get(tableName)==null){
			SQLQuery requeteSQL = this.sessionFactory.getCurrentSession().createSQLQuery("select column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='paraneo' and table_name=:tableName");
			requeteSQL.setParameter("tableName", tableName);
			@SuppressWarnings("unchecked")
			List<String> colonnes = requeteSQL.list();
			ordreColonnes.put(tableName, colonnes);
		}

		return ordreColonnes.get(tableName);
	}
/**
 * select global sur la table ta_libelle_colonne_table
 * @return
 */
	@SuppressWarnings("unchecked")
	public List<TaLibelleColonneTable> getAllLibelleColonneTable(){

		if(libellesColonneTable==null){
			Criteria critere = this.sessionFactory.getCurrentSession().createCriteria(TaLibelleColonneTable.class);

			//critere.add(Restrictions.eq("codColonne", codeColonne));
			libellesColonneTable = critere.list();
						
		}
		
		return libellesColonneTable;
		
	}

@Override
public Object findByMultiCriteria(Class<?> classeEntite,List<String> clefsPrimaire, List<Object> valeurs) {
	Criteria critere = this.sessionFactory.getCurrentSession().createCriteria(classeEntite);

	for (int j = 0; j < valeurs.size() ; j++) {
		if(valeurs.get(j)==null){
			critere.add(Restrictions.isNull(clefsPrimaire.get(j)));
		} else {
			critere.add(Restrictions.eq(clefsPrimaire.get(j),valeurs.get(j)));			
		}
	}
	return critere.uniqueResult();
}

@Override
public boolean verifUniciteJourFerieLegal(Date dateRecherchee) {
	String valeurFormatee;
	SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
	valeurFormatee = sdf.format(dateRecherchee);

	String notreRequeteDeBase = "select 1 from ta_jour_ferie_legal_par_pays_lmtay602 where YDJFER = :valeur and CPAY = \"FRA\"";

	SQLQuery requete = sessionFactory.getCurrentSession().createSQLQuery(notreRequeteDeBase);
	requete.setString("valeur", valeurFormatee);

	int nbResultat = requete.list().size();		// Exécution de la requête, récupération du résultat dans une liste, comptabilisation du nb de résultat
	if (nbResultat == 0)
		return true;
	else
		return false;
}

@Override
public boolean verifUniciteJourFerieLegal602(String nomTableTestee, Date dateRecherchee) {
	String valeurFormatee;
	SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
	valeurFormatee = sdf.format(dateRecherchee);

	String notreRequeteDeBase = "select 1 from " + nomTableTestee + " where YDJFER = :valeur";
	SQLQuery requete = sessionFactory.getCurrentSession().createSQLQuery(notreRequeteDeBase);
	requete.setString("valeur", valeurFormatee);

	int nbResultat = requete.list().size();		// Exécution de la requête, récupération du résultat dans une liste, comptabilisation du nb de résultat
	if (nbResultat == 0)
	{
		return true;
	}
	else
		return false;
}

@Override
public boolean verifUniciteCodePays501(String cpay, String valeurDuChamp, String nomChamp) {

	String notreRequeteDeBase = "select 1 from ta_pays_lmtay501 where CPAY != :valeur1";
	notreRequeteDeBase+=" and " + nomChamp + " = :valeur2";

	SQLQuery requete = sessionFactory.getCurrentSession().createSQLQuery(notreRequeteDeBase);
	requete.setString("valeur1", cpay);
	requete.setString("valeur2", valeurDuChamp);

	int nbResultat = requete.list().size();		// Exécution de la requête, récupération du résultat dans une liste, comptabilisation du nb de résultat
	if (nbResultat == 0)
		return true;
	else
		return false;
}

@Override
public boolean verifUniciteCodeDeviseIsoNum502(String cdev, String valeurDuChamp) {

	String notreRequeteDeBase = "select 1 from ta_devise_lmtay502 where CDEV != :valeur1 and CNDEVA = :valeur2";

	SQLQuery requete = sessionFactory.getCurrentSession().createSQLQuery(notreRequeteDeBase);
	requete.setString("valeur1", cdev);
	requete.setString("valeur2", valeurDuChamp);

	int nbResultat = requete.list().size();		// Exécution de la requête, récupération du résultat dans une liste, comptabilisation du nb de résultat
	if (nbResultat == 0)
		return true;
	else
		return false;
}

@Override
public boolean verifUniciteCoupleCodesBureauEtService(String cung, String cburo, String cdserv) {

	String notreRequeteDeBase = "select 1 from ta_complement_structure_banq_lmtay890 where CUNG != :valeur1 and CBURO = :valeur2 and CDSERV = :valeur3";

	SQLQuery requete = sessionFactory.getCurrentSession().createSQLQuery(notreRequeteDeBase);
	requete.setString("valeur1", cung);
	requete.setString("valeur2", cburo);
	requete.setString("valeur3", cdserv);

	int nbResultat = requete.list().size();		// Exécution de la requête, récupération du résultat dans une liste, comptabilisation du nb de résultat
	if (nbResultat == 0)
		return true;
	else
		return false;
}

@Override
public boolean verifUniciteCodePole(String cung, String cpole) {

	String notreRequeteDeBase = "select 1 from ta_complement_structure_banq_lmtay890 where CUNG != :valeur1 and CPOLE = :valeur2";

	SQLQuery requete = sessionFactory.getCurrentSession().createSQLQuery(notreRequeteDeBase);
	requete.setString("valeur1", cung);
	requete.setString("valeur2", cpole);

	int nbResultat = requete.list().size();		// Exécution de la requête, récupération du résultat dans une liste, comptabilisation du nb de résultat
	if (nbResultat == 0)
		return true;
	else
		return false;
}

@Override
public List<Object> requeteDatatables(Integer draw, Integer start, Integer length, DatatablesInputAjax parametresStructures, String table) throws BusinessServiceException {
	try {
		TableDescription descriptionTable = getTableDescriptionFromName(table);
		Class<?> entiteHibernate = IntrospectionUtils.getEntiteFromTableDescription(descriptionTable);
		LOGGER.debug("Début de création des critéres");
		Criteria critere = obtenirCritereConditionsDatatables(entiteHibernate, parametresStructures, descriptionTable);
		LOGGER.debug("Création des critéres terminée");
		critere.setFirstResult(start);
		critere.setMaxResults(length);
		LOGGER.debug("Début lancement requête");
		return critere.list(); 
	} catch(Throwable e){
		LOGGER.error(e);
		throw new BusinessServiceException(e);
	}
}


private TableDescription getTableDescriptionFromName(String table) throws BusinessServiceException{
	List<TableDescription> listeTables = this.selectListTables();
	return IntrospectionUtils.getTableDescriptionFromTableName(listeTables, table);
}

/**
 * Trie les colonnes en se basant sur leur index
 * Necessaire pour le order by ou l'ordre d'ajout est important
 * @param values
 * @return
 */
private Collection<DatatablesColumnAjax> trierColonnes(Collection<DatatablesColumnAjax> values) {
	Collection<DatatablesColumnAjax> valeursTriees = new ArrayList<DatatablesColumnAjax>();
	int indexMax = 0;
	for (DatatablesColumnAjax datatablesColumnAjax : values) {
		if(datatablesColumnAjax.getIndex()>indexMax)
			indexMax = datatablesColumnAjax.getIndex();
	}
	DatatablesColumnAjax[] tableauColonnes = new DatatablesColumnAjax[indexMax+1];
	for (DatatablesColumnAjax datatablesColumnAjax : values) {
		tableauColonnes[datatablesColumnAjax.getIndex()]=datatablesColumnAjax;
	}
	
	for (int i = 0; i < tableauColonnes.length; i++) {
		if(tableauColonnes[i]!=null) {
			valeursTriees.add(tableauColonnes[i]);
		}
	}
	
	return valeursTriees;
	
}


/**
 * A partir des informations fournies par Datatables cree la condition Hibernate correspondante
 * @param entiteHibernate
 * @param parametresStructures
 * @param descriptionTable
 * @return
 */
private Criteria obtenirCritereConditionsDatatables(Class<?> entiteHibernate, DatatablesInputAjax parametresStructures, TableDescription descriptionTable){
	Criteria critere =  this.sessionFactory.getCurrentSession().createCriteria(entiteHibernate);
	Criterion ouConditionsColonnes = null;
	Criterion etConditionsColonnes = null;
	List<Criterion> conditionsColonnesRechercheGlobale = new ArrayList<Criterion>();
	List<Criterion> conditionsColonnes = new ArrayList<Criterion>();

	Collection<DatatablesColumnAjax> colonnesTriees = trierColonnes(parametresStructures.getColumns().values());
	for (DatatablesColumnAjax colonne : colonnesTriees) {
		String nomColonne = "";

		// Si la colonne est une clef etrangere il faut aller cherche le nom de l'autre colonne
		String nomColonneDatatables = colonne.getName().toLowerCase().replace("[","").replace("]", "");
		for (ColumnDescription column : descriptionTable.getColumnList()) {
			if(column.getColumnName().toLowerCase().equals(nomColonneDatatables)){
				if(column.isForeignKey()){
					nomColonne =column.getPropertyName()+"."+column.getColumnName().toLowerCase();
					break;
				} else {
					nomColonne = column.getPropertyName();
					break;
				}

			}

			}
		// Recherche par colonne
		if(!StringUtils.isEmpty(colonne.getSearchValue()) && colonne.isSearchable()){
			if(!nomColonne.startsWith("yd") && !nomColonne.startsWith("horodatage")){
				conditionsColonnes.add(Restrictions.like(nomColonne, "%"+colonne.getSearchValue()+"%"));
			} else {
				String valeurLike = "'%"+colonne.getSearchValue()+"%'";
				conditionsColonnes.add(Restrictions.sqlRestriction("DATE_FORMAT({alias}."+nomColonne+",'%d/%m/%Y') LIKE ("+valeurLike+")"));
			}
		}

		if(!conditionsColonnes.isEmpty()) {
			etConditionsColonnes = Restrictions.and(conditionsColonnes.toArray(new Criterion[0]));
		}

		if(!StringUtils.isEmpty(colonne.getOrderDirection())){
			switch (colonne.getOrderDirection()) {
			case "asc":
				critere.addOrder(Order.asc(nomColonne));
				break;
			case "desc":
				critere.addOrder(Order.desc(nomColonne));
				break;
			}
		}

		if(!StringUtils.isEmpty(parametresStructures.getSearch().getValue())){
				if(colonne.isSearchable()){
					if(!nomColonne.startsWith("yd") && !nomColonne.startsWith("horodatage")) {
						conditionsColonnesRechercheGlobale.add(Restrictions.like(nomColonne, "%"+parametresStructures.getSearch().getValue()+"%"));
					} else {
						String valeurLike = "'%"+parametresStructures.getSearch().getValue()+"%'";

						conditionsColonnesRechercheGlobale.add(Restrictions.sqlRestriction("DATE_FORMAT({alias}."+nomColonne+",'%d/%m/%Y') LIKE ("+valeurLike+")"));
					}
				}

			if(!conditionsColonnesRechercheGlobale.isEmpty()){
				ouConditionsColonnes = Restrictions.or( conditionsColonnesRechercheGlobale.toArray(new Criterion[0]));
			}

		}
	}

	if(ouConditionsColonnes!=null && etConditionsColonnes!=null){
		critere.add(Restrictions.and(ouConditionsColonnes,etConditionsColonnes));
	} else if(ouConditionsColonnes!=null){
		critere.add(ouConditionsColonnes);
	} else if(etConditionsColonnes!=null) {
		critere.add(etConditionsColonnes);
	}
	return critere;

}


@Override
public Integer countDatatableFiltre(Class<?> entiteHibernate, DatatablesInputAjax parametresStructures, TableDescription descriptionTable) {
	Criteria critere = obtenirCritereConditionsDatatables(entiteHibernate, parametresStructures, descriptionTable);
	return ((Long) critere.setProjection(Projections.rowCount()).uniqueResult()).intValue();
}


@Override
public byte[] getStreamingMYSQLResult(String className,List<String> enTetesCode, Map<String,String> enTetesCodeEtLibelle, List<String> listeFetch) throws IllegalArgumentException, IllegalAccessException, NoSuchMethodException, SecurityException, InvocationTargetException, IOException{
	
	Session openSession = this.sessionFactory.openSession();
	String queryString = "select ent FROM " + className + " as ent";
	
	
	for (String foreignKey : listeFetch) {
		queryString+=" inner join fetch ent."+foreignKey;
	}
	
	
	queryString+=" fetch all properties";
	Query query = openSession.createQuery(queryString);
	
	
	query.setReadOnly(true);
	query.setFetchSize(Integer.MIN_VALUE);
	ScrollableResults results = query.scroll(ScrollMode.FORWARD_ONLY);
	try {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet;
		Cell cell;
		Row row;
		sheet = workbook.createSheet(className);
		row = sheet.createRow(0);
		cell = row.createCell(0);
		int index = 0;
		for (String enTeteCode : enTetesCode) {
			cell = row.createCell(index);
			cell.setCellValue(enTeteCode);
			index++;
		}
	
		index = 0;
		row = sheet.createRow(1);
		for (String enTeteLibelle : enTetesCodeEtLibelle.values()) {
			cell = row.createCell(index);
			cell.setCellValue(enTeteLibelle);
			index++;
		}
	
		index = 0;
		int ligne = 2;
		Object enregistrement;
			while(results.next()) {
				enregistrement = results.get()[0];
				Class<?> classeIntrospection = enregistrement.getClass();
				index = 0;
				row = sheet.createRow(ligne);
				for (String code : enTetesCode) {
					cell = row.createCell(index);
					String valeurChamp ="";
					try {
						Field champ = classeIntrospection.getDeclaredField(code.toLowerCase());
						champ.setAccessible(true);
						if(champ.get(enregistrement)==null){
							valeurChamp = "";

						} else {
							valeurChamp = champ.get(enregistrement).toString();

						}
					} catch(NoSuchFieldException exception){
						//Si pas de champ c'est peut être disponible uniquement via un getter
						 Method methode = classeIntrospection.getDeclaredMethod("get"+code.charAt(0)+code.substring(1).toLowerCase());
						 valeurChamp = methode.invoke(enregistrement).toString();
					}
					cell.setCellValue(valeurChamp);
					index++;
				}
				ligne++;
				enregistrement = null;
				if(ligne%5000==0){
					LOGGER.debug("Flush de la session avec "+ligne);
					openSession.clear();
					System.gc();
				}
			}
		ByteArrayOutputStream outBytesStream = new ByteArrayOutputStream();
		workbook.write(outBytesStream);
		byte[] byteArray = outBytesStream.toByteArray();
		results.close();
		return byteArray; 
	} catch(Throwable e){
		throw new IllegalArgumentException(e);
	} 
}

@Override
public int countActif(Class<?> persistentClass) throws BusinessServiceException {
	try {
		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(persistentClass);
		Calendar calendrier = Calendar.getInstance();
		calendrier.add(Calendar.DAY_OF_MONTH, +1);
		Date dateDemain = DateUtils.truncate(calendrier.getTime(), Calendar.DATE);
		
		calendrier.set(Calendar.YEAR, 9999);
		calendrier.set(Calendar.MONTH, Calendar.DECEMBER);
		calendrier.set(Calendar.DATE, 31);
		Date dateMaximum = calendrier.getTime();
		
		
		criteria.add(Restrictions.between("ydclot", dateDemain, dateMaximum));
		Long count =  (Long) criteria.setProjection(Projections.rowCount()).uniqueResult();
		return count.intValue();
	} catch (TransactionException tEx) {
		throw new BusinessServiceException(tEx);
	}	
}

@Override
public int countClos(Class<?> persistentClass) throws BusinessServiceException {
	try {
		Calendar calendrier = Calendar.getInstance();
		Date dateAujourdhui = DateUtils.truncate(calendrier.getTime(), Calendar.DATE);
		
		calendrier.set(Calendar.YEAR, 1);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DATE, 1);
		Date dateDebut = DateUtils.truncate(calendrier.getTime(), Calendar.DATE);

		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(persistentClass);
		criteria.add(Restrictions.between("ydclot", dateDebut,dateAujourdhui));
		Long count =  (Long) criteria.setProjection(Projections.rowCount()).uniqueResult();
		return count.intValue();
	} catch (TransactionException tEx) {
		throw new BusinessServiceException(tEx);
	}
}

}