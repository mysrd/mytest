package fr.icdc.dei.edt.core.converter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Currency;
import java.util.Locale;

public class NumberConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.NumberConverter";

	/**
	 * ISO 4217 currency code, applied only when formatting currencies.
	 */
	private String currencyCode;

	/**
	 * Currency symbol, applied only when formatting currencies.
	 */
	private String currencySymbol;

	/**
	 * Locale whose predefined styles for numbers are used during formatting and
	 * parsing. If not specified, the Locale returned by
	 * FacesContext.getViewRoot().getLocale() will be used. Expressions must
	 * evaluate to a java.util.Locale.
	 */
	// TODO faut-il r�cup�rer le locale du framework
	private Locale locale = Locale.getDefault();

	/**
	 * Maximum number of digits that will be formatted in the fractional portion
	 * of the output. Expressions must evaluate to an int.
	 */
	private int maxFractionDigits;

	/**
	 * Maximum number of digits that will be formatted in the integer portion of
	 * the output. Expressions must evaluate to an int.
	 */
	private int maxIntegerDigits;

	/**
	 * Minimum number of digits that will be formatted in the fractional portion
	 * of the output. Expressions must evaluate to an int.
	 */
	private int minFractionDigits;

	/**
	 * Minimum number of digits that will be formatted in the integer portion of
	 * the output. Expressions must evaluate to an int.
	 */
	private int minIntegerDigits;

	/**
	 * Custom formatting pattern which determins how the number string should be
	 * formatted and parsed.
	 */
	private String pattern;

	/**
	 * Specifies how the number string will be formatted and parsed. Valid
	 * values are "number", "currency", and "percentage". Default value is
	 * "number".
	 */
	private String type = "number";

	/**
	 * Flag specifying whether formatted output will contain grouping
	 * separators. Expressions must evaluate to a boolean. Default value is
	 * true.
	 */
	private boolean groupingUsed = true;

	/**
	 * Flag specifying whether only the integer part of the value will be
	 * formatted and parsed. Expressions must evaluate to a boolean. Default
	 * value is false.
	 */
	private boolean integerOnly = false;

	private boolean maxFractionDigitsSet;

	private boolean maxIntegerDigitsSet;

	private boolean minFractionDigitsSet;

	private boolean minIntegerDigitsSet;

	public NumberConverter() {
	}

	/**
	 * @see fr.icdc.dei.edt.core.converter.Converter#getAsObject(java.lang.String)
	 */
	public Object getAsObject(String value) throws ConverterException {

		if (value != null) {
			value = value.trim();
			if (value.length() > 0) {
				NumberFormat format = getNumberFormat();

				format.setParseIntegerOnly(this.integerOnly);
				try {
					return format.parse(value);
				} catch (ParseException e) {
					throw new ConverterException(CONVERSION_MESSAGE_ID, e);
				}
			}
		}
		return null;
	}

	/**
	 * @see fr.icdc.dei.edt.core.converter.Converter#getAsString(java.lang.Object)
	 */
	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}

		NumberFormat format = getNumberFormat();

		format.setGroupingUsed(this.groupingUsed);
		if (this.maxFractionDigitsSet)
			format.setMaximumFractionDigits(this.maxFractionDigits);
		if (this.maxIntegerDigitsSet)
			format.setMaximumIntegerDigits(this.maxIntegerDigits);
		if (this.minFractionDigitsSet)
			format.setMinimumFractionDigits(this.minFractionDigits);
		if (this.minIntegerDigitsSet)
			format.setMinimumIntegerDigits(this.minIntegerDigits);
		formatCurrency(format);
		try {
			return format.format(value);
		} catch (IllegalArgumentException e) {
			throw new ConverterException(CONVERSION_MESSAGE_ID, e);
		}

	}

	// ============================================================================

	private NumberFormat getNumberFormat() {
		Locale locale = this.locale != null ? this.locale : Locale.getDefault();

		if (this.pattern == null && this.type == null) {
			throw new RuntimeException("Cannot get NumberFormat, either type or pattern needed.");
		}

		// pattern
		if (this.pattern != null) {
			return new DecimalFormat(this.pattern, new DecimalFormatSymbols(locale));
		}

		// type
		if (this.type.equals("number")) {
			return NumberFormat.getNumberInstance(locale);
		} else if (this.type.equals("currency")) {
			return NumberFormat.getCurrencyInstance(locale);
		} else if (this.type.equals("percent")) {
			return NumberFormat.getPercentInstance(locale);
		}
		throw new RuntimeException("Cannot get NumberFormat, illegal type " + this.type);
	}

	private void formatCurrency(NumberFormat format) {
		if (this.currencyCode == null && this.currencySymbol == null) {
			return;
		}

		boolean useCurrencyCode;

		useCurrencyCode = this.currencySymbol == null;

		if (useCurrencyCode) {
			// set Currency
			format.setCurrency(Currency.getInstance(this.currencyCode));
		} else if (format instanceof DecimalFormat)

		{
			DecimalFormat dFormat = (DecimalFormat) format;
			DecimalFormatSymbols symbols = dFormat.getDecimalFormatSymbols();
			symbols.setCurrencySymbol(this.currencySymbol);
			dFormat.setDecimalFormatSymbols(symbols);
		}
	}

	// ============================================================================

	public String getCurrencyCode() {
		return this.currencyCode != null ? this.currencyCode : getDecimalFormatSymbols().getInternationalCurrencySymbol();
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencySymbol() {
		return this.currencySymbol != null ? this.currencySymbol : getDecimalFormatSymbols().getCurrencySymbol();
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public boolean isGroupingUsed() {
		return this.groupingUsed;
	}

	public void setGroupingUsed(boolean groupingUsed) {
		this.groupingUsed = groupingUsed;
	}

	public boolean isIntegerOnly() {
		return this.integerOnly;
	}

	public void setIntegerOnly(boolean integerOnly) {
		this.integerOnly = integerOnly;
	}

	public Locale getLocale() {
		if (this.locale != null)
			return this.locale;
		return Locale.getDefault();
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public int getMaxFractionDigits() {
		return this.maxFractionDigits;
	}

	public void setMaxFractionDigits(int maxFractionDigits) {
		this.maxFractionDigitsSet = true;
		this.maxFractionDigits = maxFractionDigits;
	}

	public int getMaxIntegerDigits() {
		return this.maxIntegerDigits;
	}

	public void setMaxIntegerDigits(int maxIntegerDigits) {
		this.maxIntegerDigitsSet = true;
		this.maxIntegerDigits = maxIntegerDigits;
	}

	public int getMinFractionDigits() {
		return this.minFractionDigits;
	}

	public void setMinFractionDigits(int minFractionDigits) {
		this.minFractionDigitsSet = true;
		this.minFractionDigits = minFractionDigits;
	}

	public int getMinIntegerDigits() {
		return this.minIntegerDigits;
	}

	public void setMinIntegerDigits(int minIntegerDigits) {
		this.minIntegerDigitsSet = true;
		this.minIntegerDigits = minIntegerDigits;
	}

	public String getPattern() {
		return this.pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		// TODO validate type
		this.type = type;
	}

	private DecimalFormatSymbols getDecimalFormatSymbols() {
		return new DecimalFormatSymbols(getLocale());
	}

	public boolean isMaxFractionDigitsSet() {
		return maxFractionDigitsSet;
	}

	public void setMaxFractionDigitsSet(boolean maxFractionDigitsSet) {
		this.maxFractionDigitsSet = maxFractionDigitsSet;
	}

	public boolean isMaxIntegerDigitsSet() {
		return maxIntegerDigitsSet;
	}

	public void setMaxIntegerDigitsSet(boolean maxIntegerDigitsSet) {
		this.maxIntegerDigitsSet = maxIntegerDigitsSet;
	}

	public boolean isMinFractionDigitsSet() {
		return minFractionDigitsSet;
	}

	public void setMinFractionDigitsSet(boolean minFractionDigitsSet) {
		this.minFractionDigitsSet = minFractionDigitsSet;
	}

	public boolean isMinIntegerDigitsSet() {
		return minIntegerDigitsSet;
	}

	public void setMinIntegerDigitsSet(boolean minIntegerDigitsSet) {
		this.minIntegerDigitsSet = minIntegerDigitsSet;
	}

	private String label;

	public void setLabel(String label) {
		this.label = label;
	}
}
