package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

//Propriétés de l'annotation (meta-annotations)
@Retention(RetentionPolicy.RUNTIME)     // Cette nouvelle annotation est vue par la JVM
@Target(ElementType.TYPE)              // Elle s'applique que sur une classe
@Constraint(validatedBy=UniciteCodeDeviseIsoNum502Validator.class)                 // Nom de la classe où sera effectué la vérification
public @interface UniciteCodeDeviseIsoNum502 {
     String message() default "{paraneo.contrainte.codedeviseisonum502dejaexistantenbase}";
  Class<?>[] groups() default { };
  Class<? extends Payload>[] payload() default {};

}
