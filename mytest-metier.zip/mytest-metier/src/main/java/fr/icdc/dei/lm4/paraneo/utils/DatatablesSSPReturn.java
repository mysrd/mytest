package fr.icdc.dei.lm4.paraneo.utils;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * <p>Objet retourne en reponse a un appel Datatables</p>
 * <p><a href="https://www.datatables.net/manual/server-side">Specification disponible ici</a></p>
 * @author porsini
 *
 */
public class DatatablesSSPReturn {
	public Integer draw;
	public Integer recordsTotal;
	public Integer recordsFiltered;
	@JsonSerialize(using=ListSerializer.class)
	public List<Collection<Object>> data;

}


/**
 * Permet d'eviter l'échappement des caracteres HTML.
 * Cela pose probleme car l'on souhaite envoyer du code HTML à Datatables pour les elements qui permettent de deplier une ligne.
 * @author porsini
 *
 */
class ListSerializer extends JsonSerializer<List<List<String>>> {

	@Override
	public void serialize(List<List<String>> value, JsonGenerator jgen, SerializerProvider sp) throws IOException, JsonProcessingException {
		jgen.writeStartArray();
		for (List<String> liste : value) {
			jgen.writeStartArray();
			
			for (String string : liste) {
				jgen.writeString(string);
			}
			
			jgen.writeEndArray();
		}
		
		jgen.writeEndArray();
	}
}
