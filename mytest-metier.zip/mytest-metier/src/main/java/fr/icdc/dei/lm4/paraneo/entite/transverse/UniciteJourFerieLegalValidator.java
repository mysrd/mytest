package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;

/**
* Verifie que la date du jour ferie YDJFER saisie n'existe pas deja en base dans la table ta_jour_ferie_legal_par_pays_lmtay602
* @author porsini
*
*/
public class UniciteJourFerieLegalValidator extends DatabaseAccess implements ConstraintValidator<UniciteJourFerieLegal, Date> {
	@Autowired
	private ReferentielBusinessService referentielService;

	@Override
    public void initialize(UniciteJourFerieLegal constraintAnnotation) {
    }

    @Override
    public boolean isValid(Date value, ConstraintValidatorContext context) {
    	return this.referentielService.verifUniciteJourFerieLegal(value);
    }
}
