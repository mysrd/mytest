package fr.icdc.dei.lm4.paraneo.dao;

import java.util.List;

public interface SecuriteDAO {

	public List<String> obtenirTablesAutoriseesEnConsultation(List<String> groupes);
	public List<String> obtenirTablesAutoriseesEnCreation(List<String> groupes);
	public List<String> obtenirTablesAutoriseesEnModification(List<String> groupes);
	public List<String> obtenirTablesAutoriseesEnSuppression(List<String> groupes);
	public List<String> obtenirTablesAutoriseesEnNotification(List<String> groupes);

}
