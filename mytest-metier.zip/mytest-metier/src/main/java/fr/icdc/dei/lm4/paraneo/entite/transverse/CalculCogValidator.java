package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CalculCogValidator implements ConstraintValidator<CalculCog, TaCommuneInsee>{

	@Override
	public void initialize(CalculCog constraintAnnotation) {

	}

	@Override
	public boolean isValid(TaCommuneInsee classeValidee, ConstraintValidatorContext context) {
		String cogCalculeCoteServeur;
		cogCalculeCoteServeur = classeValidee.getYc0dep().trim() + classeValidee.getCom().trim();
		return cogCalculeCoteServeur.equals(classeValidee.getCog());
	}
}
