package fr.icdc.dei.edt.core.configuration.parser;

import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;

public interface DefaultConfigParser {

	public static final boolean TABLE_LIST_PAGE = true;
	public static final boolean TABLE_EDIT_RECORD = true;
	public static final boolean TABLE_ADD_NEW_RECORD = true;
	public static final boolean TABLE_DELETE_RECORD = true;

	public static final boolean TABLE_VIEW_RECORD = true;
	public static final boolean TABLE_COPY_RECORD = true;
	public static final boolean TABLE_PRINTER_FRIENDLY = true;
	public static final boolean TABLE_EXPORT_PAGE = true;

	public static final int TABLE_PAGINATION = 20;

	public static final boolean COLUMN_LIST = true;
	public static final boolean COLUMN_ADD = true;
	public static final boolean COLUMN_EDIT = true;
	public static final boolean COLUMN_VIEW = true;
	public static final boolean COLUMN_SEARCH = true;
	public static final boolean COLUMN_PRINT = true;
	public static final boolean COLUMN_EXPORT = true;

	public static final boolean COLUMN_SORT = false;
	public static final boolean COLUMN_HIDE_SORT_BUTTONS = false;

	public static final String SORT_ASC = "asc";
	public static final String SORT_DESC = "desc";

	public static final String COLUMN_SORT_INITIAL_DIRECTION = SORT_ASC;

	/**
	 * Appelée par une instance de la classe <code>ConfigurationService</code>.
	 */
	TableConfigImpl getDefaultTableConfiguration();

}