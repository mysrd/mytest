package fr.icdc.dei.lm4.paraneo.metier.service;

import java.util.List;

import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

public interface ChampCalculeService {

	/**
	 * Retourne une liste contenant les colonnes correspondant a des champs calcules
	 * @param enregistrement
	 * @return liste de colonnes
	 * @throws BusinessServiceException 
	 */
	List<String> obtenirColonnes(String nomClasse) throws BusinessServiceException;
	
	/**
	 * Recoit un enregistrement et le retourne avec la valeur des champs calcules alimentee
	 * @param enregistrement
	 * @return enregistrement
	 * @throws BusinessServiceException 
	 */
	void calculerValeurChamps(Object enregistrement) throws BusinessServiceException;
	
}
