package fr.icdc.dei.lm4.paraneo.metier.exception;

public class BusinessServiceException extends Exception {

	private String urlRetour;

	/**
	 * @return the urlRetour
	 */
	public String getUrlRetour() {
		return urlRetour;
	}

	/**
	 * @param pUrlRetour the urlRetour to set
	 */
	public void setUrlRetour(String pUrlRetour) {
		this.urlRetour = pUrlRetour;
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public BusinessServiceException() {
		super();
	}

	public BusinessServiceException(String message) {
		super(message);
	}

	public BusinessServiceException(Throwable cause) {
		super(cause);
	}

	public BusinessServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public BusinessServiceException(String message, String pUrlRetour) {
		super(message);
		this.urlRetour = pUrlRetour;
	}

	public BusinessServiceException(String message, String pUrlRetour, Throwable cause) {
		super(message, cause);
		this.urlRetour = pUrlRetour;
	}
}
