package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidDatesEffetValidator implements ConstraintValidator<ValidDatesEffet, Object>{

	@Override
	public void initialize(ValidDatesEffet constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if(value instanceof HorodatageEffet){
			HorodatageEffet valeurCastee = (HorodatageEffet) value;
			Date dateDebutEffet = valeurCastee.getYddeff();
			Date dateFinEffet = valeurCastee.getYdfeff();
			if (dateDebutEffet.after(dateFinEffet)){
				return false;
			}
			else{
				return true;
			}
		}
		return false;
	}

}
