package fr.icdc.dei.lm4.paraneo.utils;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.hdiv.urlProcessor.LinkUrlProcessor;
import org.hdiv.util.HDIVUtil;

/**
 * Helper utilise pour creer des liens HDIV (avec le jeton HDIV_STATE) a partir d'une URL.
 * Semblable a l'utilisation d'un tag url dans la jsp.
 * @author porsini
 *
 */
public class HDIVWrapper {

	private HttpServletRequest request;

	private ServletContext context;

	public HDIVWrapper(HttpServletRequest request, ServletContext context) {
		super();
		this.request = request;
		this.context = context;
	}

	public String creerLienHDIV(String url){
		LinkUrlProcessor lup = HDIVUtil.getLinkUrlProcessor(context);
		return lup.processUrl(request, url);
	}

}
