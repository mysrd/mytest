package fr.icdc.dei.edt.core.configuration.parser.converter;


public interface BasicConverterParser extends ConverterParser {

	String getId();

	String getClassName();

	
}
