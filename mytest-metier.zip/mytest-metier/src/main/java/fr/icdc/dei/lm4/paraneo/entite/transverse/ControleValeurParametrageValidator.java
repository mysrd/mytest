package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ControleValeurParametrageValidator implements ConstraintValidator<ControleValeurParametrage, TaParametrage> {

	@Override
	public void initialize(ControleValeurParametrage constraintAnnotation) {
	
	}

	@Override
	public boolean isValid(TaParametrage value,	ConstraintValidatorContext context) {
		boolean retour = true;
		switch (value.getCode()) {
			case "LIGNES_HEX":
				try {
					Integer.parseInt(value.getValeur());
				} catch(NumberFormatException e){
					retour = false;
				}
				break;
			default:
				break;
		}
		return retour;
	}
}
