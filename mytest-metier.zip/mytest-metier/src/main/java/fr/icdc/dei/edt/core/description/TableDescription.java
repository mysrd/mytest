package fr.icdc.dei.edt.core.description;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;

/**
 * TableDescription est un objet qui contient des informations concernant une
 * entité et sa table correpondante.
 * 
 * @author M Abdennebi
 * 
 */

public class TableDescription implements Serializable {

	/**
	 * Le nom de la classe qui correspond à l'entité.
	 */
	private String entityClassName;

	/**
	 * Le nom de la table qui correspond à l'entité.
	 */
	private String tableName;

	/**
	 * Le nom de la clé primaire.
	 */
	private String idName;

	/**
	 * Le nom de la classe de la clé primaire.
	 */
	private String idClassName;

	/**
	 * Permet de dire si la clé primaire est composée.
	 */
	private boolean compositeId;

	/**
	 * Liste de colonnes de la table {@link ColumnDescription}.
	 */
	private List<ColumnDescription> columnList;

	/**
	 * Clé : nom de la colonne<br>
	 * Valeur : {@link ColumnDescription}.
	 */
	private Map<String, ColumnDescription> columnNameColumnDescriptionMap;

	/**
	 * Clé : nom de l'attribut<br>
	 * Valeur : {@link ColumnDescription}.
	 */
	private Map<String, ColumnDescription> propertyNameColumnDescriptionMap;

	/**
	 * Configuration de la table.
	 */
	private TableConfigImpl configuration;

	public TableDescription() {
	}

	/**
	 * TableDescription est un objet qui contient des informations concernant
	 * une entité et sa table correpondante.
	 */
	public TableDescription(TableConfigImpl config, String entityClassName, String tableName, String idName, String idClassName, boolean isCompositeId,
			List<ColumnDescription> columnList, Map<String, ColumnDescription> columnNameColumnDescriptionMap,
			Map<String, ColumnDescription> propertyNameColumnDescriptionMap) {

		this.configuration = config;

		this.entityClassName = entityClassName;

		this.tableName = tableName;

		this.columnList = columnList;

		this.idClassName = idClassName;

		this.idName = idName;

		this.compositeId = isCompositeId;

		this.columnNameColumnDescriptionMap = columnNameColumnDescriptionMap;

		this.propertyNameColumnDescriptionMap = propertyNameColumnDescriptionMap;
	}

	/**
	 * @return the entityClassName
	 */
	public String getEntityClassName() {
		return entityClassName;
	}

	/**
	 * @param entityClassName
	 *            the entityClassName to set
	 */
	public void setEntityClassName(String entityClassName) {
		this.entityClassName = entityClassName;
	}

	/**
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param tableName
	 *            the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return the idName
	 */
	public String getIdName() {
		return idName;
	}

	/**
	 * @param idName
	 *            the idName to set
	 */
	public void setIdName(String idName) {
		this.idName = idName;
	}

	/**
	 * @return the idClassName
	 */
	public String getIdClassName() {
		return idClassName;
	}

	/**
	 * @param idClassName
	 *            the idClassName to set
	 */
	public void setIdClassName(String idClassName) {
		this.idClassName = idClassName;
	}

	/**
	 * @return the compositeId
	 */
	public boolean isCompositeId() {
		return compositeId;
	}

	/**
	 * @param compositeId
	 *            the compositeId to set
	 */
	public void setCompositeId(boolean compositeId) {
		this.compositeId = compositeId;
	}

	/**
	 * @return the columnList
	 */
	public List<ColumnDescription> getColumnList() {
		return columnList;
	}

	/**
	 * @param columnList
	 *            the columnList to set
	 */
	public void setColumnList(List<ColumnDescription> columnList) {
		this.columnList = columnList;
	}

	/**
	 * @return the columnNameColumnDescriptionMap
	 */
	public Map<String, ColumnDescription> getColumnNameColumnDescriptionMap() {
		return columnNameColumnDescriptionMap;
	}

	/**
	 * @param columnNameColumnDescriptionMap
	 *            the columnNameColumnDescriptionMap to set
	 */
	public void setColumnNameColumnDescriptionMap(Map<String, ColumnDescription> columnNameColumnDescriptionMap) {
		this.columnNameColumnDescriptionMap = columnNameColumnDescriptionMap;
	}

	/**
	 * @return the propertyNameColumnDescriptionMap
	 */
	public Map<String, ColumnDescription> getPropertyNameColumnDescriptionMap() {
		return propertyNameColumnDescriptionMap;
	}

	/**
	 * @param propertyNameColumnDescriptionMap
	 *            the propertyNameColumnDescriptionMap to set
	 */
	public void setPropertyNameColumnDescriptionMap(Map<String, ColumnDescription> propertyNameColumnDescriptionMap) {
		this.propertyNameColumnDescriptionMap = propertyNameColumnDescriptionMap;
	}

	public TableConfigImpl getConfiguration() {
		return configuration;
	}

	public void setConfiguration(TableConfigImpl config) {
		configuration = config;
	}

}
