package fr.icdc.dei.edt.core.configuration.impl.parser.converter;

import org.dom4j.Node;

import fr.icdc.dei.edt.core.configuration.parser.converter.ConvertNumberParser;

public class XMLConvertNumberParser implements ConvertNumberParser {
	
	private final Node converterNode;
	
	public XMLConvertNumberParser(Node converterNode) {
		this.converterNode = converterNode;
	}

	public String getCurrencyCode() {
		return converterNode.valueOf("@currencyCode");
	}

	public String getCurrencySymbol() {
		return  converterNode.valueOf("@currencySymbol");
	}

	public String getGroupingUsed() {
		return  converterNode.valueOf("@groupingUsed");
	}

	public String getIntegerOnly() {
		return  converterNode.valueOf("@integerOnly");
	}
	
	public String getLocale() {
		return converterNode.valueOf("@locale");
	}

	public String getMaxFractionDigits() {
		return converterNode.valueOf("@maxFractionDigits");
	}

	public String getMaxIntegerDigits() {
		return converterNode.valueOf("@maxIntegerDigits");
	}

	public String getMinFractionDigits() {
		return converterNode.valueOf("@minFractionDigits");
	}

	public String getMinIntegerDigits() {
		return converterNode.valueOf("@minIntegerDigits");
	}

	public String getPattern() {
		return converterNode.valueOf("@pattern");
	}

	public String getType() {
		return converterNode.valueOf("@type");
	}

}
