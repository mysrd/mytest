package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

/**
 * Doit être hérité par les classes gérant l'horodatage
 * @author porsini
 *
 */
@XmlAccessorType(XmlAccessType.NONE)
public abstract class Horodatage {

	public abstract Date getYdc000();

	public abstract void setYdc000(Date ydc000);

	public abstract Date getYddmaj();

	public abstract void setYddmaj(Date yddmaj);

	public abstract Date getYdclot();

	public abstract void setYdclot(Date ydclot);

	public abstract String getCuser();

	public abstract void setCuser(String cuser);


	/**
	 * Initialise la date de création à aujourd'hui
	 */
	public void initialiserDateCreation(){
		setYdc000(Calendar.getInstance().getTime());
	}

	public void mettreAJourDateModification(){
		this.setYddmaj(Calendar.getInstance().getTime());
	}


	public void definirUtilisateur(String utilisateur){
		this.setCuser(utilisateur);
	}

	/**
	 * Intialise la date de cloture au 01/01/2076
	 */
	public void initialiserDateCloture(){
		this.setYdclot(ParaneoUtils.obtenirDateMaximum());
	}

	/**
	 * Renvoie true si cet enregistrement est cloturé
	 * @return
	 */
	public boolean isEnregistrementCloture(){
		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.HOUR_OF_DAY,0);
		calendrier.set(Calendar.MINUTE,0);
		calendrier.set(Calendar.SECOND,0);
		calendrier.set(Calendar.MILLISECOND,0);
		Date dateDuJour = calendrier.getTime();
		if((getYdclot().compareTo(dateDuJour)<0)||(getYdclot().compareTo(dateDuJour)==0)){
			return true;
		}
		return false;
	}

	@XmlElement(name="ydc000")
	public String getDateCreationWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdc000());
	}

	@XmlElement(name="ydclot")
	public String getDateClotureWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdclot());
	}

	@XmlElement(name="yddmaj")
	public String getDateMiseAJourWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYddmaj());
	}

}
