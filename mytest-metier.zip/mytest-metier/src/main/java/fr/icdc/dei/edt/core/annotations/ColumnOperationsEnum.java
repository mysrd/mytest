package fr.icdc.dei.edt.core.annotations;

public enum ColumnOperationsEnum {
	
	List(), Add(), Edit(), View();
	
	private ColumnOperationsEnum (){
		
	}
}
