package fr.icdc.dei.edt.core;

import org.springframework.security.core.userdetails.UserDetails;

/**
 * Auditable est une interface implémentée par des entités que l'on souhaite
 * "auditer" dans une piste d'audit.
 * 
 * Le but de cette classe est de fournir le nom de l'utilisateur auteur de
 * l'action.
 * 
 * Cette interface est utilisée conjointement avec un listener Hibernate.
 * 
 * @author abdennebi 14/08/09
 * 
 */
public interface Auditable {

	void setPrincipal(UserDetails principal);

	UserDetails getPrincipal();

}
