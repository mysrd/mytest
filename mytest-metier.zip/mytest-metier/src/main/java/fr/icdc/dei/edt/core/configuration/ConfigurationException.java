package fr.icdc.dei.edt.core.configuration;


/**
 * Levée en cas de mauvaise configuration. 
 */
public class ConfigurationException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public ConfigurationException(String message) {
		super(message);
	}

	public ConfigurationException(Throwable e) {
		super(e);
	}
	
	public ConfigurationException(String message, Throwable e) {
		super(message, e);
	}

}
