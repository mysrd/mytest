package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidationSaisieLmtay830Validator implements ConstraintValidator<ValidationSaisieLmtay830, Object>{

	@Override
	public void initialize(ValidationSaisieLmtay830 constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if(value instanceof TaCategorieDeContrepartieBicLmtay830){
			TaCategorieDeContrepartieBicLmtay830 valeurCastee = (TaCategorieDeContrepartieBicLmtay830) value;
			String cagsis = valeurCastee.getCagsis();
			String cagbic = valeurCastee.getCagbic();
			boolean cagbicA999 = "999".equals(cagbic);
			boolean cagsisA00OuABlanc = "00 ".equals(cagsis) || " ".equals(cagsis);

			if ((cagsisA00OuABlanc == true && cagbicA999 == true)
				||
				(cagsisA00OuABlanc == false && cagbicA999 == false))
			{
				return true;
			}
		}
		return false;
	}

}
