package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

public abstract class HorodatageEffet extends Horodatage {

	public abstract Date getYddeff();

	public abstract void setYddeff(Date yddeff);

	public abstract Date getYdfeff();

	public abstract void setYdfeff(Date ydfeff);

	//public abstract char getCtmaj1();

	//public abstract void setCtmaj1(char ctmaj1);

	public void initialiserDateDebutEffet(){
		this.setYddeff(Calendar.getInstance().getTime());
	}

	public void initialiserDateFinEffet(){
		this.setYdfeff(ParaneoUtils.obtenirDateMaximum());
	}

	//public void initialiserTypeMaj(){
	//	this.setCtmaj1('C');
	//}

//	public boolean controleCoherenceDates(){
//		if(this.getYddeff().after(getYdfeff()))
//			return false;
//		else
//			return true;
//	}

	@XmlElement(name="yddeff")
	public String getDateDebutEffetWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYddeff());

	}

	@XmlElement(name="ydfeff")
	public String getDateFinEffetWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdfeff());

	}

}
