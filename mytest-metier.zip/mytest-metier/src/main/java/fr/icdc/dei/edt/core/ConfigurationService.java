package fr.icdc.dei.edt.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;
import org.springframework.stereotype.Service;

import fr.icdc.dei.edt.core.configuration.ConfigurationException;
import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.core.description.impl.HibernateTableDescriptionBuilder;
import fr.icdc.dei.edt.core.exception.EditTableException;

/**
 * <p>
 * Ce singleton est le point d'entrée de la configuration de EditTables.
 *
 * <p>
 * Cette classe est appelée par un "Persistance Service" qui lui passe en
 * paramètre de la méthode {@link #getTableList()} un objet hibernate de type
 * {@link org.hibernate.cfg.Configuration}. La méthode retourne une liste
 * d'objets de type {@link TableDescription}.
 */
@Service("configurationService")
public class ConfigurationService {

	@Resource(name = "hibernateConfig")
	private Configuration hibernateCfg;

	private List<TableDescription> tableList = new ArrayList<TableDescription>();

	private static final Logger LOGGER = Logger.getLogger(ConfigurationService.class);


	public ConfigurationService() throws EditTableException {
	}

	@PostConstruct
	public void init() throws EditTableException, SecurityException, NoSuchFieldException {

		Iterator<?> classMappingsIterator = hibernateCfg.getClassMappings();

		Set<String> classes = new HashSet<String>();

		// On itére une première fois pour récupérer la liste de toutes les
		// classes
		while (classMappingsIterator.hasNext()) {
			PersistentClass persistentClass = (PersistentClass) classMappingsIterator.next();
			classes.add(persistentClass.getClassName());
		}

		classMappingsIterator = hibernateCfg.getClassMappings();

		while (classMappingsIterator.hasNext()) {
			PersistentClass persistentClass = (PersistentClass) classMappingsIterator.next();
			String tableName = persistentClass.getTable().getName();
			tableName = tableName.toUpperCase();

			try {
				HibernateTableDescriptionBuilder tableDescriptionBuilder = new HibernateTableDescriptionBuilder(persistentClass, classes);
				TableDescription tableDescription = tableDescriptionBuilder.build();
				tableList.add(tableDescription);
			} catch (ConfigurationException e) {
				LOGGER.info(e);
				continue;
			}
		}

		updateForeignKeys(tableList);

	}

	private void updateForeignKeys(List<TableDescription> tableList) {
		Map<String, TableDescription> tableDescriptionMap = new HashMap<String, TableDescription>();

		// 1ère itération sur tableList pour la transformer en une map
		for (Iterator<TableDescription> iter = tableList.iterator(); iter.hasNext();) {
			TableDescription tableDescription = (TableDescription) iter.next();
			tableDescriptionMap.put(tableDescription.getEntityClassName(), tableDescription);
		}

		// 2ème itération sur tableList
		for (Iterator<TableDescription> iter = tableList.iterator(); iter.hasNext();) {
			TableDescription tableDescription = (TableDescription) iter.next();
			List<ColumnDescription> columnDescriptionList = tableDescription.getColumnList();

			// Itération sur la liste des colonnes d'une table
			for (Iterator<ColumnDescription> iter2 = columnDescriptionList.iterator(); iter2.hasNext();) {
				ColumnDescription columnDescription = (ColumnDescription) iter2.next();

				String className = columnDescription.getClassName();

				if (tableDescriptionMap.get(className) != null) {

					TableDescription tableDescription2 = (TableDescription) tableDescriptionMap.get(className);
					columnDescription.setForeignTableDescription(tableDescription2);
				}
			}
		}
	}

	public List<TableDescription> getTableList() {
		return tableList;
	}
}
