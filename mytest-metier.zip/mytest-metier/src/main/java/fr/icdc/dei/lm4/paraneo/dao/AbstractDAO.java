package fr.icdc.dei.lm4.paraneo.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;

import fr.icdc.dei.lm4.paraneo.utils.Alias;


@SuppressWarnings("rawtypes")
public interface AbstractDAO<T, ID extends Serializable> {

	public List<T> findAll();

	public List<T> findByCriteria(Criterion... criteres);

	public List<T> findByCriteria(int maxResults, Criterion... criteres);

	public List<T> findByCriteria(List<Alias> alias, String entityName, Criterion... criteres);

	public List<T> findByCriteria(List<Alias> alias, String entityName, Order ordre, Criterion... criteres);

	public List<T> findByCriteria(List<Alias> alias, String entityName, Order ordre, int maxResults, Criterion... criteres);

	public List<T> findByCriteria(Order ordre, Criterion... criteres);

	public List findByProjection(Projection projections,  Criterion... criteres);

	public List findByProjection(List<Alias> alias, String entityName, Projection projections, Criterion... criteres);

	public T findById(ID id);

	public void saveOrUpdate(T entity);

	public void insert(T entity);

	public void update(T entity);

	public void delete(T entity);

	public SessionFactory getSessionFactory();
}
