package fr.icdc.dei.edt.core.converter;

public class FloatConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.FloatConverter";
	
	public FloatConverter() {
	}

	public Object getAsObject(String value) throws ConverterException {

		if (value != null) {
			value = value.trim();
			if (value.length() > 0) {
				try {
					return Float.valueOf(value);
				} catch (NumberFormatException e) {
					throw new ConverterException(CONVERSION_MESSAGE_ID, e, new Object[]{value});
				}
			}
		}
		return null;
	}

	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}
		return Float.toString(((Number) value).floatValue());
	}
	
	private String label;
	
	public void setLabel(String label) {
		this.label = label;	
	}
}
