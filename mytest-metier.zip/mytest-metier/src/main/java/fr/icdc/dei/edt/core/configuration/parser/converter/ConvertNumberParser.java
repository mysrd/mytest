package fr.icdc.dei.edt.core.configuration.parser.converter;


public interface ConvertNumberParser extends ConverterParser {

	String getCurrencyCode();
	
	String getCurrencySymbol();
	
	String getGroupingUsed();

	String getIntegerOnly();
	
	String getLocale();
	
	String getMaxFractionDigits();
	
	String getMaxIntegerDigits();
	
	String getMinFractionDigits();
	
	String getMinIntegerDigits();
	
	String getPattern();
	
	String getType();

}
