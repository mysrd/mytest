package fr.icdc.dei.lm4.paraneo.utils;

public class DatatablesOrderAjax {

	private Integer column;
	
	private String direction;

	public Integer getColumn() {
		return column;
	}

	public void setColumn(Integer column) {
		this.column = column;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	
}
