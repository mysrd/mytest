package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

public abstract class HorodatageEffetDevise extends Horodatage {

	public abstract Date getYddedv();

	public abstract void setYddedv(Date yddedv);

	public abstract Date getYdfedv();

	public abstract void setYdfedv(Date ydfedv);

	public abstract Date getYddin();

	public abstract void setYddin(Date yddin);

	public void initialiserDateDebutEffetDevise(){
		this.setYddedv(Calendar.getInstance().getTime());
	}

	public void initialiserDateFinEffetDevise(){
		this.setYdfedv(ParaneoUtils.obtenirDateMaximum());
	}

	public void initialiserDateIn(){
		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, 0001);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,01);
		this.setYddin(calendrier.getTime());
	}


//	public boolean controleCoherenceDates(){
//		if(this.getYddedv().after(getYdfedv()))
//			return false;
//		else
//			return true;
//	}

	@XmlElement(name="yddedv")
	public String getDateDebutEffetDeviseWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYddedv());

	}

	@XmlElement(name="ydfedv")
	public String getDateFinEffetDeviseWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdfedv());

	}

	@XmlElement(name="yddin")
	public String getDateInWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYddin());

	}

}
