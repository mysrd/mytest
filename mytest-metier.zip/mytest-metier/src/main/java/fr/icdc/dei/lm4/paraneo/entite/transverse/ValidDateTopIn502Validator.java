package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Calendar;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang.time.DateUtils;

public class ValidDateTopIn502Validator implements ConstraintValidator<ValidDateTopIn502, TaDeviseLmtay502>{

	@Override
	public void initialize(ValidDateTopIn502 constraintAnnotation) {

	}

	@Override
	public boolean isValid(TaDeviseLmtay502 classeTestee, ConstraintValidatorContext context) {
		Date yddin = classeTestee.getYddin();
		TaChoixOuiNon ytopin = classeTestee.getTaChoixOuiNonByYtopin();

		Calendar calendrier = Calendar.getInstance();

		if (ytopin.getCodeChoixOuiNon().trim().equals("N")){
			calendrier.set(Calendar.YEAR, 0001);
			calendrier.set(Calendar.MONTH, Calendar.JANUARY);
			calendrier.set(Calendar.DAY_OF_MONTH,01);
			Date dateParDefaut = calendrier.getTime();
			if (DateUtils.isSameDay(yddin, dateParDefaut)){
				return true;
			}
			else{
				return false;
			}
		} else if (ytopin.getCodeChoixOuiNon().trim().equals("O")){
			calendrier.set(Calendar.YEAR, 1900);
			calendrier.set(Calendar.MONTH, Calendar.JANUARY);
			calendrier.set(Calendar.DAY_OF_MONTH,01);
			calendrier.set(Calendar.HOUR_OF_DAY, 0);
			calendrier.set(Calendar.MINUTE,0);
			calendrier.set(Calendar.SECOND, 0);
			calendrier.set(Calendar.MILLISECOND, 0);
			Date dateParDefaut = calendrier.getTime();
			if (yddin.before(dateParDefaut)){
				return false;
			}
			else{
				return true;
			}
		}
		else{
			return false;
		}
	}

}