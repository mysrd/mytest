package fr.icdc.dei.edt.core.configuration.impl.parser;

import java.io.FileNotFoundException;
import java.io.InputStream;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

public class Dom4jUtil {
	
	public static Document parse(String path) throws DocumentException, FileNotFoundException {
		InputStream in = loadFile(path);
		SAXReader reader = new SAXReader();
		Document document = reader.read(in);
		return document;
	}

	private static InputStream loadFile(String path) throws FileNotFoundException {
		InputStream configFile = Dom4jUtil.class.getResourceAsStream(path);
		if (configFile == null){
			throw new FileNotFoundException(path);
		}
		return configFile;
	}

}
