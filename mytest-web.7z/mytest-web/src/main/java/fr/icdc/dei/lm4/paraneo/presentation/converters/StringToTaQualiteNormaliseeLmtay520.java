package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaQualiteNormaliseeLmtay520;

public class StringToTaQualiteNormaliseeLmtay520 implements Converter<String,TaQualiteNormaliseeLmtay520> {

	@Override
	public TaQualiteNormaliseeLmtay520 convert(String arg0) {
		TaQualiteNormaliseeLmtay520 object = new TaQualiteNormaliseeLmtay520();
		object.setCqnorm(arg0.split("-")[0]);
		return object;
	}
}

