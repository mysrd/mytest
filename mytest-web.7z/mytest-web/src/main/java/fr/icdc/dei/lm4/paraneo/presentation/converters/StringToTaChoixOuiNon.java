package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaChoixOuiNon;

public class StringToTaChoixOuiNon implements Converter<String,TaChoixOuiNon> {

	@Override
	public TaChoixOuiNon convert(String arg0) {
		TaChoixOuiNon object = new TaChoixOuiNon();
		object.setCodeChoixOuiNon(arg0.split("-")[0]);
		return object;
		}


}



