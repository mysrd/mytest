package fr.icdc.dei.lm4.paraneo.presentation.commun.helper;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class HttpRuntimeHelper {

	/**
	 * Recupére le contexte de session
	 * @return
	 */
	public static HttpSession getSessionContext(){
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		return attr.getRequest().getSession();
	}
}
