package fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto;

import java.io.Serializable;

@SuppressWarnings("serial")
public abstract class AbstractDto implements Serializable{

}
