package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaModeDeGestionClientsLmtay831;

public class StringToTaModeDeGestionClientsLmtay831 implements Converter<String,TaModeDeGestionClientsLmtay831> {

	@Override
	public TaModeDeGestionClientsLmtay831 convert(String arg0) {
		TaModeDeGestionClientsLmtay831 object = new TaModeDeGestionClientsLmtay831();
		object.setCmgecl(arg0.split("-")[0]);
		return object;
	}



}
