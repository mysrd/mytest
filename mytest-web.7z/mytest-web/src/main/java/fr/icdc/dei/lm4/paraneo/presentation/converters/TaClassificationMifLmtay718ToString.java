package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaClassificationMifLmtay718;

public class TaClassificationMifLmtay718ToString implements Converter<TaClassificationMifLmtay718,String> {

	@Override
	public String convert(TaClassificationMifLmtay718 arg0) {
		return arg0.getYc0mif();
	}

}
