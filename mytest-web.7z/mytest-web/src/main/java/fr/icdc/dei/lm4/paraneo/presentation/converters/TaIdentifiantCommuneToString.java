package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaIdentifiantCommune;

public class TaIdentifiantCommuneToString implements Converter<TaIdentifiantCommune,String> {

	@Override
	public String convert(TaIdentifiantCommune arg0) {
		return arg0.getIdcom();
	}

}
