package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodificationReglementaireLmtay997;

public class StringToTaCodificationReglementaireLmtay997 implements Converter<String,TaCodificationReglementaireLmtay997> {

	@Override
	public TaCodificationReglementaireLmtay997 convert(String arg0) {
		TaCodificationReglementaireLmtay997 object = new TaCodificationReglementaireLmtay997();
		object.setCodreg(arg0.split("-")[0]);
		return object;
	}



}
