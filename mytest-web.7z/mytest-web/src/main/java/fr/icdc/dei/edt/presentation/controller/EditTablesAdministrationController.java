package fr.icdc.dei.edt.presentation.controller;

import java.beans.IntrospectionException;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import fr.icdc.dei.edt.core.converter.ConverterException;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Horodatage;
import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TableHistorique;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.ChampCalculeService;
import fr.icdc.dei.lm4.paraneo.metier.service.SecuriteBusinessService;
import fr.icdc.dei.lm4.paraneo.metier.service.impl.NotificationDidoBusinessServiceImpl;
import fr.icdc.dei.lm4.paraneo.presentation.commun.controller.AbstractReferentielController;
import fr.icdc.dei.lm4.paraneo.presentation.commun.helper.DatatablesGenerator;
import fr.icdc.dei.lm4.paraneo.presentation.commun.helper.MappingUtils;
import fr.icdc.dei.lm4.paraneo.presentation.exception.ErreurTechniqueException;
import fr.icdc.dei.lm4.paraneo.presentation.exception.HabilitationException;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables.ColumnDescriptionDto;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables.TableDescriptionDto;
import fr.icdc.dei.lm4.paraneo.utils.HDIVWrapper;
import fr.icdc.dei.lm4.paraneo.utils.InitChampParDefaut;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;
import fr.icdc.dei.lm4.paraneo.utils.MvrUtils;

/**
 * @author ffernandez-e
 *
 */
@Controller
@RequestMapping("/edittables")
public class EditTablesAdministrationController extends AbstractReferentielController {


	/**
	 * Les arguments passes a la vue
	 */
	private static final String ARGUMENT_VUE_PREVIOUS_OPERATION_STATE = "previousOperationState";

	private static final String ARGUMENT_VUE_TABLE = "table";

	private static final String ARGUMENT_VUE_MESSAGE = "message";

	private static final String ARGUMENT_VUE_LIB_COLONNES_TABLE = "LibColonnesTable";

	private static final String ARGUMENT_VUE_IS_MODE_EDITION = "isModeEdition";

	private static final String ARGUMENT_VUE_OBJETS_FOREIGN_TABLES = "objetsForeignTables";
	
	private static final String ARGUMENT_VUE_CREATION_ENREGISTREMENT = "creationEnregistrement";


	/**
	 * Les vues appellees depuis ce controller
	 */
	private static final String PAGE_CREATION = "edittables.administration.creerEnregistrement";

	private static final String URL_REDIRECT = "redirect:detailsTable";



	private static final Logger LOGGER = Logger.getLogger(EditTablesAdministrationController.class);
	
	@Resource(name = "editTablesBusinessService")
	private ReferentielBusinessService service;

	@Resource(name = "mapper")
	private Mapper mapper;

	@Resource(name = "notificationDido")
	private NotificationDidoBusinessServiceImpl notificationDido;

	@Resource(name="securiteService")
	private SecuriteBusinessService securiteService;

	@Resource(name="champCalculeService")
	private ChampCalculeService champCalculeService;
	
	@Autowired
	private DatatablesGenerator datatablesGenerator;
	
	@Autowired
	private ValeursUtilisateurEdittable valeursUtilisateur;

	@Autowired
	private  HttpServletRequest request;

	 @Autowired
    private ServletContext context;



	private String erreurTechnique;


	/**
	 * Liste des tables présentes en base.
	 */
	private List<TableDescriptionDto> tables = new ArrayList<TableDescriptionDto>();

	/**
	 * Liste des libellés de toutes les colonnes des tables
	 */
	private List<TaLibelleColonneTable> colonnes;



	@RequestMapping(value = "/tableList")
	public ModelAndView showTableList(@RequestParam(value = ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, required = false) Boolean previousOperationState,
			@RequestParam(value = ARGUMENT_VUE_MESSAGE, required = false) String message,@RequestParam(value="erreurs",required = false) String erreurs,@RequestParam(value="erreurPresente",required = false)Boolean erreurPresente) throws Exception {

		if(this.valeursUtilisateur.getTablesEnConsultation() == null
			|| this.valeursUtilisateur.getTablesEnModification()==null
			|| this.valeursUtilisateur.getTablesEnCreation()==null
			|| this.valeursUtilisateur.getTablesEnSuppression()==null
			|| this.valeursUtilisateur.getTablesEnNotification()==null){
			this.valeursUtilisateur.setTablesEnConsultation(securiteService.verifierAccesConsultation());
			this.valeursUtilisateur.setTablesEnModification(securiteService.verifierAccesModification());
			this.valeursUtilisateur.setTablesEnCreation(securiteService.verifierAccesCreation());
			this.valeursUtilisateur.setTablesEnSuppression(securiteService.verifierAccessSuppression());
			this.valeursUtilisateur.setTablesEnNotification(securiteService.verifierAccessNotification());
		}

		cacheHolder.getMenuItems();
		pickMenu(ParaneoConstantes.CODE_MENU_EDITTABLES, null);
		// Alimentation de la liste des tables paraneo
		List<TableDescription> tables = service.getTableList();
		// Pour chaque table, remise en ordre des colonnes selon celui dans la base de données
		for (TableDescription table : tables) {
			IntrospectionUtils.reorderColumns(table,service.getColumnsOrder(table));
		}
		// Alimentation de la liste à partir de la table ta_libelle_colonne_table
		colonnes = service.getAllLibelleColonneTable();

		List<TableDescriptionDto> tablesDtos = MappingUtils.mapList(tables, TableDescriptionDto.class);

		// Mise � jour de la liste des tables.
		Collections.sort(tablesDtos, TableDescriptionDto.getComparatorByTableNameAsc());
		this.tables = tablesDtos;


		// Ajout des objets à passer à la vue.
		ModelAndView model = new ModelAndView("edittables.administration.listtables");
		model.addObject(ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, previousOperationState);
		model.addObject(ARGUMENT_VUE_MESSAGE, message);
		model.addObject("erreurs", erreurs);
		model.addObject("erreurPresente",erreurPresente);
		HDIVWrapper hdivWrapper = new HDIVWrapper(request, context);

		model.addObject("json",datatablesGenerator.creerDonneesListeTable(this.tables,hdivWrapper,this.valeursUtilisateur.getTablesEnConsultation(),this.valeursUtilisateur.getTablesEnCreation()));
		model.addObject("colonnesJSON",DatatablesGenerator.creerColonnesListeTable());
		model.addObject("piedDePage",DatatablesGenerator.creerPiedDePageListeTable());
		model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());


		return model;
	}

	/**
	 * Afficher le détail d'une table (les données présentes dans cette table)/
	 *
	 * @return Les données à passer à la vue
	 * @throws BusinessServiceException
	 */
	@RequestMapping(value = "/detailsTable")
	public ModelAndView showDetailsTable(@RequestParam(value = ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, required = false) Boolean previousOperationState,@RequestParam(value = "tableName", required = true) String tableName,@RequestParam(value = ARGUMENT_VUE_MESSAGE, required = false) String message,@RequestParam(value="erreurs",required = false) String erreurs,@RequestParam(value="erreurPresente",required = false)Boolean erreurPresente) throws BusinessServiceException {
		// Mise à jour de la table à afficher selon le param en entrée.
		TableDescriptionDto tableAAfficher = new TableDescriptionDto();
		tableAAfficher.setTableName(tableName);

		if(this.valeursUtilisateur.getTablesEnConsultation().contains(tableAAfficher.getTableName())){

			this.valeursUtilisateur.setTableAAfficher(MvrUtils.getObjectInList(this.tables, tableAAfficher));

			// Appel métier pour récupérer la liste des objets à afficher.
			TableDescription table = mapper.map(this.valeursUtilisateur.getTableAAfficher(), TableDescription.class);
			List<TaLibelleColonneTable> libColonnesTable = recuperationLibellesColonnesTable();

			HDIVWrapper hdivWrapper = new HDIVWrapper(request, context);

			String colonnesJSON = datatablesGenerator.creerColonnesJSON(this.valeursUtilisateur.getTableAAfficher(),libColonnesTable,champCalculeService.obtenirColonnes(this.valeursUtilisateur.getTableAAfficher().getEntityClassName()));
			// Ajout des objets à passer à la vue.
			ModelAndView model = new ModelAndView("edittables.administration.detailsTable");
			model.addObject(ARGUMENT_VUE_MESSAGE, message);
			model.addObject("erreurs", erreurs);
			model.addObject("erreurPresente",erreurPresente);
			model.addObject(ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, previousOperationState);

			model.addObject("colonnesJSON",colonnesJSON);
			model.addObject("piedDePage",DatatablesGenerator.creerPiedDePage(this.valeursUtilisateur.getTableAAfficher()));
			model.addObject("tables", this.tables);
			model.addObject("limiteColonne",DatatablesGenerator.getNombreColonneDepliant());
			model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());
			model.addObject("urlajax",DatatablesGenerator.obtenirURLAjax(hdivWrapper));
			model.addObject("colonnesAffichees","["+DatatablesGenerator.getColonnesAffichees()+"]");
			model.addObject("isDepliant",DatatablesGenerator.isDepliant(this.valeursUtilisateur.getTableAAfficher()));
			model.addObject("droitInsertion",this.valeursUtilisateur.getTablesEnCreation().contains(tableName) && table.getConfiguration().getAddNewRecordOp());
			return model;
		} else {
			return new ModelAndView(URL_REDIRECT);
		}
	}


	@RequestMapping(value = "/editerEnregistrement")
	public ModelAndView editerEnregistrement(@RequestParam(value = "tableName", required = true) String tableName,
			@RequestParam(value = "index", required = true) String index) throws HabilitationException, ErreurTechniqueException {

		// Mise a jour de la table a afficher selon le param en entree.
		TableDescriptionDto tableDto = new TableDescriptionDto();
		tableDto.setTableName(tableName);
		this.valeursUtilisateur.setTableAAfficher(MvrUtils.getObjectInList(this.tables, tableDto));

		if(this.valeursUtilisateur.getTablesEnModification().contains(tableName)){
			try {
				this.valeursUtilisateur.setClasse(Class.forName(valeursUtilisateur.getTableAAfficher().getEntityClassName()));

				Object formulaire = createCommandObject();

				int intIndex = Integer.valueOf(index);
				if (intIndex >= this.valeursUtilisateur.getObjetsTableAAfficher().size()) {
					throw new ErreurTechniqueException(this.erreurTechnique);
				}
				formulaire = this.valeursUtilisateur.getObjetsTableAAfficher().get(intIndex);

				this.valeursUtilisateur.setOldValue(formulaire);
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String nomUtilisateur = auth.getName();

				if(formulaire instanceof Horodatage) {
					Horodatage enregistrement = (Horodatage) formulaire;
					enregistrement.mettreAJourDateModification();
					enregistrement.definirUtilisateur(nomUtilisateur);
				}



				List<TaLibelleColonneTable> libColonnesTable = recuperationLibellesColonnesTable();

				ModelAndView model = new ModelAndView("edittables.administration.editerEnregistrement");

				model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());
				model.addObject(ARGUMENT_VUE_CREATION_ENREGISTREMENT, formulaire);
				Map<String,List<Object>> foreignKeys = getMapForeignKey(this.valeursUtilisateur.getTableAAfficher());
				getCurrentForeignKey(this.valeursUtilisateur.getTableAAfficher(),foreignKeys);
				model.addObject(ARGUMENT_VUE_OBJETS_FOREIGN_TABLES, foreignKeys);
				model.addObject(ARGUMENT_VUE_IS_MODE_EDITION, true);
				model.addObject(ARGUMENT_VUE_LIB_COLONNES_TABLE, libColonnesTable);

				return model;
			} catch (ClassNotFoundException | BusinessServiceException e) {
				throw new ErreurTechniqueException(this.erreurTechnique, null, e);
			}
		} else {
			return new ModelAndView(URL_REDIRECT);

		}
	}



	@RequestMapping(value = "/validerMajEnregistrement")
	public ModelAndView validerMajEnregistrement(@ModelAttribute(ARGUMENT_VUE_CREATION_ENREGISTREMENT) @Validated Object formulaire, BindingResult result)
			throws BusinessServiceException {
		if(this.valeursUtilisateur.getTablesEnModification().contains(valeursUtilisateur.getTableAAfficher().getTableName())){

			ModelAndView model = null;
			if(result.hasErrors()){
				List<TaLibelleColonneTable> libColonnesTable = recuperationLibellesColonnesTable();

				model = new ModelAndView(PAGE_CREATION);
				model.addObject(ARGUMENT_VUE_OBJETS_FOREIGN_TABLES, getMapForeignKey(this.valeursUtilisateur.getTableAAfficher()));
				model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());
				model.addObject(ARGUMENT_VUE_CREATION_ENREGISTREMENT, formulaire);
				model.addObject(ARGUMENT_VUE_IS_MODE_EDITION, true);
				model.addObject(ARGUMENT_VUE_LIB_COLONNES_TABLE, libColonnesTable);

				return model;
			} else {
					TableDescription table = mapper.map(this.valeursUtilisateur.getTableAAfficher(), TableDescription.class);
					model = new ModelAndView(URL_REDIRECT);
					model.addObject(ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, true);

				try {
					model.addObject(ARGUMENT_VUE_MESSAGE, "editTables.editerEnregistement.succes");
					model.addObject("tableName",table.getTableName());
					service.update(formulaire, this.valeursUtilisateur.getOldValue(), table);
					notificationDido.envoyerNotificationModification(formulaire, table);
					return model;
				} catch (IllegalArgumentException | SecurityException | ConverterException 
						|  IntrospectionException | IllegalAccessException 
						| InvocationTargetException | NoSuchMethodException e) {
					throw new BusinessServiceException(e);
				}
			}
		} else {
			return new ModelAndView(URL_REDIRECT);
		}
	}

	@RequestMapping(value = "/creerEnregistrement")
	public ModelAndView creerEnregistrement(@RequestParam(value = "tableName", required = true) String tableName) throws HabilitationException {


		// Mise à jour de la table à afficher selon le param en entrée.
		TableDescriptionDto table = new TableDescriptionDto();
		table.setTableName(tableName);
		if(this.valeursUtilisateur.getTablesEnCreation().contains(tableName)){
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String nomUtilisateur = auth.getName();
			this.valeursUtilisateur.setTableAAfficher(MvrUtils.getObjectInList(this.tables, table));
			try {
				this.valeursUtilisateur.setClasse(Class.forName(valeursUtilisateur.getTableAAfficher().getEntityClassName()));
				Object formulaire = createCommandObject();

				// On initialise les champs a leurs valeurs par défaut
				InitChampParDefaut initialiseur = new InitChampParDefaut();
				initialiseur.initialiser(formulaire,nomUtilisateur);

				List<TaLibelleColonneTable> libColonnesTable = recuperationLibellesColonnesTable();

				ModelAndView model = new ModelAndView(PAGE_CREATION);
				model.addObject(ARGUMENT_VUE_OBJETS_FOREIGN_TABLES, getMapForeignKey(this.valeursUtilisateur.getTableAAfficher()));
				model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());
				model.addObject(ARGUMENT_VUE_CREATION_ENREGISTREMENT, formulaire);
				model.addObject(ARGUMENT_VUE_IS_MODE_EDITION, false);
				model.addObject(ARGUMENT_VUE_LIB_COLONNES_TABLE, libColonnesTable);

				return model;
			} catch (ClassNotFoundException | BusinessServiceException e) {
				return null;
			}
		} else {
			return new ModelAndView(URL_REDIRECT);
		}
	}


	@RequestMapping(value = "/validerCreationEnregistrement")
	public ModelAndView validerCreationEnregistrement(@ModelAttribute(ARGUMENT_VUE_CREATION_ENREGISTREMENT)@Validated Object formulaire, BindingResult result)
			throws BusinessServiceException {
		if(this.valeursUtilisateur.getTablesEnCreation().contains(this.valeursUtilisateur.getTableAAfficher().getTableName())){

			ModelAndView model = null;

			if(result.hasErrors()){
				model = new ModelAndView(PAGE_CREATION);
				List<TaLibelleColonneTable> libColonnesTable = recuperationLibellesColonnesTable();

				model.addObject(ARGUMENT_VUE_OBJETS_FOREIGN_TABLES, getMapForeignKey(this.valeursUtilisateur.getTableAAfficher()));
				model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());
				model.addObject(ARGUMENT_VUE_CREATION_ENREGISTREMENT, formulaire);
				model.addObject(ARGUMENT_VUE_IS_MODE_EDITION, false);
				model.addObject(ARGUMENT_VUE_LIB_COLONNES_TABLE, libColonnesTable);
				return model;

			} else {
				TableDescription table = mapper.map(this.valeursUtilisateur.getTableAAfficher(), TableDescription.class);
				try {
					Map<String, Object> clefsPrimaires = IntrospectionUtils.getPrimaryKeysNameAndValues(formulaire, table);
					Class<?> entite = IntrospectionUtils.getEntiteFromTableDescription(table);
					List<String> clefs = new ArrayList<String>(clefsPrimaires.keySet());
					List<Object> valeurs = new ArrayList<Object>(clefsPrimaires.values());
					Object enregistrement = service.findByMultiCriteria(entite, clefs, valeurs);
					
					// Si l'enregistrement existe
					if(enregistrement!=null){
						model = new ModelAndView(PAGE_CREATION);
						List<TaLibelleColonneTable> libColonnesTable = recuperationLibellesColonnesTable();
						result.reject("paraneo.clefendouble");
						model.addObject(ARGUMENT_VUE_OBJETS_FOREIGN_TABLES, getMapForeignKey(this.valeursUtilisateur.getTableAAfficher()));
						model.addObject(ARGUMENT_VUE_TABLE, this.valeursUtilisateur.getTableAAfficher());
						model.addObject(ARGUMENT_VUE_CREATION_ENREGISTREMENT, formulaire);
						model.addObject(ARGUMENT_VUE_IS_MODE_EDITION, false);
						model.addObject(ARGUMENT_VUE_LIB_COLONNES_TABLE, libColonnesTable);
						return model;						 
					} else { // Si l'enregistrement n'existe pas on le cree
						service.create(formulaire, table);
						notificationDido.envoyerNotificationCreation(formulaire, table);
						model = new ModelAndView(URL_REDIRECT);
						model.addObject("tableName",table.getTableName());
						model.addObject(ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, true);
						model.addObject(ARGUMENT_VUE_MESSAGE, "editTables.creerEnregistement.succes");
						return model;
					}
				}
				 catch (ConverterException | IllegalArgumentException | SecurityException 
						 | IntrospectionException | IllegalAccessException | InvocationTargetException 
						 | NoSuchMethodException e) {
					throw new ErreurTechniqueException(this.erreurTechnique, null, e);
				} 
			}
		} else {
			return new ModelAndView(URL_REDIRECT);
		}
	}

	@RequestMapping(value = "/supprimerEnregistrement")
	public ModelAndView supprimerEnregistrement(@RequestParam(value = "tableName", required = true) String tableName,@RequestParam(value = "index", required = true) String index) throws BusinessServiceException{
		ModelAndView model = null;
		TableDescriptionDto tableDto = new TableDescriptionDto();
		tableDto.setTableName(tableName);
		if(this.valeursUtilisateur.getTablesEnSuppression().contains(tableName)){

			this.valeursUtilisateur.setTableAAfficher(MvrUtils.getObjectInList(this.tables, tableDto));
			TableDescription table = mapper.map(this.valeursUtilisateur.getTableAAfficher(), TableDescription.class);
			Object formulaire = this.valeursUtilisateur.getObjetsTableAAfficher().get(Integer.parseInt(index));

			String nomDeLaClasse = formulaire.getClass().getName();			// Récupération du nom de la classe
			String nomDeLaClasseHistorique = nomDeLaClasse + "Historique";
			try {
				Class<?> classe = Class.forName(nomDeLaClasseHistorique);
				Object tableHistorique = classe.newInstance();
				TableHistorique tableHistoriqueCastee = (TableHistorique) tableHistorique;
				tableHistoriqueCastee.initTableHistorique(formulaire, SecurityContextHolder.getContext().getAuthentication().getName());

				service.delete(formulaire, table);
				service.create(tableHistoriqueCastee);
				notificationDido.envoyerNotificationSuppression(formulaire, table);

			} catch (ConverterException | IllegalArgumentException
					| SecurityException | IllegalAccessException
					| InvocationTargetException | NoSuchMethodException
					| IntrospectionException | ClassNotFoundException | InstantiationException e) {
				throw new BusinessServiceException(e);
			}

			model = new ModelAndView(URL_REDIRECT);
			model.addObject("tableName",table.getTableName());
			model.addObject(ARGUMENT_VUE_PREVIOUS_OPERATION_STATE, true);
			model.addObject(ARGUMENT_VUE_MESSAGE, "editTables.supprimerEnregistrement.succes");
			return model;
		} else {
			return new ModelAndView(URL_REDIRECT);
		}

	}

	@RequestMapping(value = "/exporterTable")
	public void exportTableBrut(HttpServletResponse response,@RequestParam(value="provenance") String provenance, @RequestParam(value="tableName") String nomTable) throws BusinessServiceException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException, SecurityException, InvocationTargetException, IOException{
		/*
		 * La solution la plus simple serait d'utiliser AbstractXlsxView du framework Spring.
		 * Mais cela necessite une montee de version qui est impossible a cause des dependances avec le fwk DEI qui a besoin d'une version particuliere de Spring.
		 * Du coup on ecrit directement le document dans la reponse HTTP
		 */

		Date dateCourante = new Date();
		final String extensionExcel = ".xlsx";
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd_HHmmss");
		String nomFichier = nomTable+"_"+sdf.format(dateCourante)+extensionExcel;

		byte[] exportExcel = service.exportExcel(nomTable);

		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setContentLength(exportExcel.length);
		response.setHeader("Content-Disposition", "attachment; filename=\""+nomFichier+"\"");
		OutputStream outStream = response.getOutputStream();
		outStream.write(exportExcel);
		outStream.flush();
	}
	
	@ModelAttribute(ARGUMENT_VUE_CREATION_ENREGISTREMENT)
	public Object createCommandObject() {
		try {
			if (this.valeursUtilisateur.getClasse() != null) {
				return this.valeursUtilisateur.getClasse().newInstance();
			}
			return null;
		} catch (InstantiationException | IllegalAccessException e) {
			return null;
		}
	}

	
	
	
	private List<TaLibelleColonneTable> recuperationLibellesColonnesTable() {
		// Constitution de la liste des colonnes/libellés de la table à afficher
		List <ColumnDescriptionDto> colonnesDeLaTable =  this.valeursUtilisateur.getTableAAfficher().getColumnList();
		List<TaLibelleColonneTable> libColonnesTable = new ArrayList<TaLibelleColonneTable>();

		for (int i = 0; i < colonnesDeLaTable.size(); i++) {
			for (int j = 0; j < colonnes.size(); j++) {
				if (colonnesDeLaTable.get(i).getColumnName().equals(colonnes.get(j).getCodColonne()) ) {
					libColonnesTable.add(colonnes.get(j));	// Ajout du code/libellé de la colonne dans la liste des colonnes/libellés de la table à afficher
				}
			}
		}
		
		// Cas des colonnes calculees
		try {
			Class<?> classeTable = Class.forName(this.valeursUtilisateur.getTableAAfficher().getEntityClassName());
			Field[] declaredFields = classeTable.getDeclaredFields();
			for (int i = 0; i < declaredFields.length; i++) {
				String fieldName = declaredFields[i].getName();
				for(int j = 0; j< colonnes.size();j++){
					if(fieldName.equals(colonnes.get(j).getCodColonne())){
						libColonnesTable.add(colonnes.get(j));
					}
				}
			}
		} catch (ClassNotFoundException e){
			LOGGER.error(e);
		}
		
		return libColonnesTable;
	}

	/**
	 * Renvoie une Map qui associe à chaque colonne de type foreignKey,
	 * une liste des valeurs possibles (liste d'objets).
	 * @param table
	 * @return
	 * @throws BusinessServiceException
	 */
	private Map<String, List<Object>> getMapForeignKey(TableDescriptionDto table) throws BusinessServiceException {
		Map<String, List<Object>> objetsForeignTable = new HashMap<String, List<Object>>();

		for (ColumnDescriptionDto colonne : table.getColumnList()) {
			if (colonne.isForeignKey()) {
				List<Object> listeNonFiltree = service.findAll(colonne.getForeignTableDescription().getEntityClassName());
				List<Object> listeFiltree = new ArrayList<Object>();
				for (Object enregistrement : listeNonFiltree) {
					if(enregistrement instanceof Horodatage){
						if(((Horodatage) enregistrement).isEnregistrementCloture()==false){
							listeFiltree.add(enregistrement);
						}
					} else {
						LOGGER.debug("Attention la table "+colonne.getForeignTableDescription().getEntityClassName()+" n'hérite pas d'horodatage. Elle ne fera pas l'objet d'un filtre sur la date de cloture.");
						listeFiltree = listeNonFiltree;
					}
				}
				objetsForeignTable.put(colonne.getColumnName(), listeFiltree);
			}
		}

		return objetsForeignTable;
	}

	private void getCurrentForeignKey(TableDescriptionDto table, Map<String, List<Object>> foreignKeys) throws BusinessServiceException {
		// On parcourt les colonnes de la table
		for (ColumnDescriptionDto colonne : table.getColumnList()) {
			// Si la colonne est une clef etrangere
			if (colonne.isForeignKey()) {
				Object value = null;
				String classNameFinal = colonne.getPropertyName(); //premierCaractere + className.substring(1);

				try {
					Field f = this.valeursUtilisateur.getOldValue().getClass().getDeclaredField(classNameFinal);
					f.setAccessible(true);
					try {
						value = f.get(valeursUtilisateur.getOldValue());
					} catch (IllegalArgumentException e) {
						LOGGER.error(e);
					} catch (IllegalAccessException e) {
						LOGGER.error(e);
					}
				} catch (NoSuchFieldException e) {
					LOGGER.error(e);
				} catch (SecurityException e) {
					LOGGER.error(e);
				}
				
				// On recupere tous les elements de la future liste deroulante
				List<Object> listeNonClose = foreignKeys.get(colonne.getColumnName());
				List<Object> listeAAfficher = new ArrayList <Object>();
				
				// On met la valeur utilisee en premiere position dans la liste qui servira a la liste deroulante
				listeAAfficher.add(0,value);
				int j = 0;
				
				// On ne garde que les enregistrements qui n'ont pas atteint leur date de cloture
				// On ne met pas en double la valeur utilisee
				for (int i = 0;i <listeNonClose.size();i++)  {
					if (!listeNonClose.get(i).equals(listeAAfficher.get(0)))	 {
						j++;
						listeAAfficher.add (j,listeNonClose.get(i));
					}
				}
				
				foreignKeys.put(colonne.getColumnName(),listeAAfficher);	
			}
		}
	}









}
