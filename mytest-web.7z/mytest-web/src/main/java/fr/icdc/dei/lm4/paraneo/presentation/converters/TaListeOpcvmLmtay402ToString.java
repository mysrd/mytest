package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaListeOpcvmLmtay402;

public class TaListeOpcvmLmtay402ToString implements Converter<TaListeOpcvmLmtay402,String> {

	@Override
	public String convert(TaListeOpcvmLmtay402 arg0) {
		return arg0.getCdlopc();
	}

}
