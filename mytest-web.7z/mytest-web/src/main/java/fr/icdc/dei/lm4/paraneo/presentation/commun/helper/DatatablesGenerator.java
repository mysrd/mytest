package fr.icdc.dei.lm4.paraneo.presentation.commun.helper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables.ColumnDescriptionDto;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables.TableDescriptionDto;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesColumn;
import fr.icdc.dei.lm4.paraneo.utils.HDIVWrapper;
import fr.icdc.dei.lm4.paraneo.utils.RoueCranteeUtil;

/**
 * Cette classe permet de creer les informations necessaires a la mise en place de Datatables
 * @author porsini
 *
 */
@Component("datatablesGenerator")
public class DatatablesGenerator {

	// Strictement superieur a cette valeur on active le depliant
	private static final int NOMBRE_COLONNE_DEPLIANT = 5;

	// Colonnes a afficher dans le cas d'une table depliante
	private static final String COLONNES_AFFICHEES = "0,1,2,-5,-4,-3,-1";
	
	@Autowired
	private RoueCranteeUtil roueCranteeUtil;
	
	public static int getNombreColonneDepliant() {
		return NOMBRE_COLONNE_DEPLIANT;
	}

	public static String getColonnesAffichees() {
		return COLONNES_AFFICHEES;
	}
	
	
	/**
	 * Cree la liste des colonnes de la table dans un format utilisable par Datatables
	 * @param descriptionTable
	 * @param libColonnesTable
	 * @return les colonnes de la table sous la forme d'un tableau JSON
	 */
	public String creerColonnesJSON(TableDescriptionDto descriptionTable, List<TaLibelleColonneTable> libColonnesTable, List<String> colonnesCalculees){
		List<DatatablesColumn> listeColonnes = new ArrayList<>();
		ajouterColonneDepliage(descriptionTable, listeColonnes);
		
		int indexColonne = 0;
		int nombreColonnes = descriptionTable.getColumnList().size();
		
		
		for (ColumnDescriptionDto colonne : descriptionTable.getColumnList()) {
			String libelleColonne = null;
			for (TaLibelleColonneTable libColonne : libColonnesTable) {
				if(libColonne.getCodColonne().equals(colonne.getColumnName())){
					libelleColonne = libColonne.getLibColonne()+"<span name='"+colonne.getColumnName()+"'></span>";
				}
			}

			String valeurAffichee = libelleColonne!=null?libelleColonne:colonne.getColumnName();
			DatatablesColumn nouvelleColonne = new DatatablesColumn(valeurAffichee+"<span name='"+colonne.getColumnName()+"'></span>");
			nouvelleColonne.setSearchable(false);

			if(colonne.getColumnName().startsWith("YD")){
				nouvelleColonne.setType("date-jjmmaaaa");
				nouvelleColonne.setSearchable(true);
			}
			nouvelleColonne.setName(colonne.getColumnName());
			if(isDepliant(descriptionTable)){
				if(isColonneAffichee(indexColonne,nombreColonnes)){
					nouvelleColonne.setSearchable(true);
				}
			} else {
				nouvelleColonne.setSearchable(true);
			}

			listeColonnes.add(nouvelleColonne);
			indexColonne++;
		}
		
		// Ajout des colonnes calculees
		if(colonnesCalculees!=null){
			for (String nomColonne : colonnesCalculees) {
				String libelleColonne = nomColonne+" <span name='"+nomColonne+"'></span> ";
				for (TaLibelleColonneTable libColonne : libColonnesTable) {
					if(libColonne.getCodColonne().equals(nomColonne)){
						libelleColonne = libColonne.getLibColonne()+" <span name='"+nomColonne+"'></span> ";
					}
				}
				DatatablesColumn datatablesColumn = new DatatablesColumn(libelleColonne);
				datatablesColumn.setName(nomColonne);
				datatablesColumn.setSearchable(false);
				listeColonnes.add(3,datatablesColumn);
			}
		}

		ajouterColonneFin(listeColonnes);
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		return gson.toJson(listeColonnes);
	}

	// Toutes les colonnes commencant par le signe - sont relatives au nombre de colonnes de la table
	// Le +1 vient du fait que la colonne contenant la roue crantee n'est pas comptee
	private static int[] obtenirColonnesDecalees(int[] indexColonnesAAfficher){
		int[] tableauDecale = new int[indexColonnesAAfficher.length];
		for (int i = 0; i < indexColonnesAAfficher.length; i++) {
			if(indexColonnesAAfficher[i]<0){
				tableauDecale[i] = indexColonnesAAfficher[i]+1;
			} else {
				tableauDecale[i] = indexColonnesAAfficher[i];
			}
		}
		
		return tableauDecale;
		
	}
	
	/**
	 * Determine a partir de l'index de la colonne si elle doit etre affichee
	 * @param indexColonne
	 * @param nombreColonnes - le nombre de colonnes presentes dans la table
	 * @return
	 */
	private static boolean isColonneAffichee(int indexColonne, int nombreColonnes){
		int[] tableauColonnesNumerique = getColonnesAfficheesNumerique();
		int[] tableauColonnesDecale = obtenirColonnesDecalees(tableauColonnesNumerique);
		
		for (int i = 0; i < tableauColonnesDecale.length; i++) {
			if(tableauColonnesDecale[i]>=0){
				if(indexColonne==tableauColonnesDecale[i]){
					return true;
				}
			} else if(tableauColonnesDecale[i]<0){
				if(indexColonne==nombreColonnes-Math.abs(tableauColonnesDecale[i])){
					return true;
				}
			}
		}
		
		return false;
	}

	/**
	 * A partir de la chaine de caracteres representant les index des colonnes a afficher retourne un tableau d'entiers
	 */
	private static int[] getColonnesAfficheesNumerique() {
		String[] tableauColonnes = COLONNES_AFFICHEES.split(",");
		
		int[] tableauColonnesNumerique = new int[tableauColonnes.length];
		
		for (int i = 0; i < tableauColonnes.length; i++) {
			tableauColonnesNumerique[i] = Integer.parseInt(tableauColonnes[i]);
		}
		
		return tableauColonnesNumerique;
	}
	
	/**
	 * Ajoute la colonne de fin
	 * @param listeColonnes
	 */
	private static void ajouterColonneFin(List<DatatablesColumn> listeColonnes) {
		DatatablesColumn colonneConfigure = new DatatablesColumn("");
		colonneConfigure.setOrderable(false);
		colonneConfigure.setSearchable(false);
		listeColonnes.add(colonneConfigure);
	}

	/**
	 * Si la table a plus de cinq colonnes ajoute une colonne depliable
	 * @param descriptionTable
	 * @param listeColonnes
	 */
	private static void ajouterColonneDepliage(TableDescriptionDto descriptionTable,	List<DatatablesColumn> listeColonnes) {
		if( DatatablesGenerator.isDepliant(descriptionTable)){
			DatatablesColumn colonneDepliage = new DatatablesColumn("<span class=\"openDescr\">Plus d'informations</span>");
			colonneDepliage.setClassName("expandRow");
			colonneDepliage.setOrderable(false);
			colonneDepliage.setSearchable(false);
			listeColonnes.add(colonneDepliage);
		}
	}

	/**
	 * Cree la liste des valeurs de la table dans un format utilisable par Datatables
	 * @param enregistrements
	 * @param descriptionTable
	 * @param tablesEnSuppression
	 * @return les valeurs de la table sous la forme d'un tableau javascript
	 */
	public String creerDonneesJSON(List<Map<String, Object>> enregistrements, TableDescriptionDto descriptionTable, HDIVWrapper hdivWrapper, String tableName, List<String> tablesEnModification, List<String> tablesEnSuppression) {

		List<Collection<Object>> listeSansClefs = new ArrayList<>();
		int compteur = 0;
		for (Map<String, Object> list : enregistrements) {
					List<Object> valeursModifiees = new ArrayList<Object>();
					if(DatatablesGenerator.isDepliant(descriptionTable)){
						valeursModifiees.add("<span class=\"openDescr\">Plus d'informations</span>");
					}

					for (ColumnDescriptionDto column : descriptionTable.getColumnList()) {
						Object valeur = list.get(column.getColumnName());
						if(valeur instanceof Date){
							SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
							valeursModifiees.add(sdf.format(valeur));
						} else {
							valeursModifiees.add(valeur);
						}

					}
					StringBuilder sb = new StringBuilder();
					if(hasOptionsDetails(descriptionTable) && (tablesEnModification.contains(descriptionTable.getTableName()) || tablesEnSuppression.contains(descriptionTable.getTableName()))){
						sb.append("<a class=\"dropdown-toggle config\" data-toggle=\"dropdown\">Configure</a>");
						sb.append("<ul class=\"dropdown-menu\">");
						if(descriptionTable.getConfiguration().getEditRecordOp() && tablesEnModification.contains(descriptionTable.getTableName())){
							String urlEditer = "editerEnregistrement?provenance=detailsTable&tableName="+tableName+"&index="+compteur;
							String hdivUrlEditer = hdivWrapper.creerLienHDIV(urlEditer);
							RoueCranteeUtil rcu = new RoueCranteeUtil();
							rcu.ajouterBoutonEditer(hdivUrlEditer, sb);
						}
						if(descriptionTable.getConfiguration().getDeleteRecordOp() && tablesEnSuppression.contains(descriptionTable.getTableName())){
							String urlSupprimer = "supprimerEnregistrement?provenance=detailsTable&tableName="+tableName+"&index="+compteur;
							String hdivUrlSupprimer = hdivWrapper.creerLienHDIV(urlSupprimer);
							roueCranteeUtil.ajouterBoutonSupprimer(hdivUrlSupprimer,sb);
						}
					} else {
						sb.append("<span class='roue_absente'></span>");
					}
					valeursModifiees.add(sb.toString());

					listeSansClefs.add(valeursModifiees);
					compteur++;

			}
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		return gson.toJson(listeSansClefs);

	}

	public static boolean hasOptionsDetails(TableDescriptionDto descriptionTable){
		return descriptionTable.getConfiguration().getEditRecordOp() || descriptionTable.getConfiguration().getDeleteRecordOp();
	}


	/**
	 * Si une table possede plus de 5 colonnes le tableau doit disposer d'une fonctionnalite de depliage
	 * @param description
	 * @return true si le tableau doit pouvoir etre deplie
	 */
	public static boolean isDepliant(TableDescriptionDto description){
		return description.getColumnList().size()>NOMBRE_COLONNE_DEPLIANT && !"ta_code_postal".equals(description.getTableName());

	}

	/**
	 * Cree le pied de page du tableau
	 * @param tableDescriptionDto
	 * @return du code HTML
	 */
	public static String creerPiedDePage(TableDescriptionDto descriptionTable){
		StringBuilder piedDePage = new StringBuilder("<tfoot id='piedDePage'><tr>");
		int nombreColonnes = descriptionTable.getColumnList().size();
		if(isDepliant(descriptionTable)){
			piedDePage.append("<td class='unprintable'></td>");
		}

		for(int i = 0; i < nombreColonnes; i++){
			if(isDepliant(descriptionTable)){
				// Ces chiffres doivent etre coherents avec les chiffres utilises cote javascript pour initialiser Datatables.
				// Sauf qu'ici on ne compte pas la colonne de bouton et la colonne des roues d'ou un decalage des index
				//targets: [0,1,2,-5,-4,-3,-1]
				if(i==0 || i==1 || i==nombreColonnes-4 || i==nombreColonnes-3 || i==nombreColonnes-2 || i==nombreColonnes)
				{
					piedDePage.append("<td><input></input></td>");
				}
			} else {
				piedDePage.append("<td><input></input></td>");

			}
		}

		piedDePage.append("<td class='hidden unprintable'></td>");
		piedDePage.append("</tr></tfoot>");


		return piedDePage.toString();
	}

	public static String creerColonnesListeTable() {
		List<DatatablesColumn> listeColonnes = new ArrayList<>();
		DatatablesColumn colonnePrincipale = new DatatablesColumn("Nom de la table");
		listeColonnes.add(colonnePrincipale);

		ajouterColonneFin(listeColonnes);

		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		return gson.toJson(listeColonnes);
	}

	public  String creerDonneesListeTable(List<TableDescriptionDto> tables, HDIVWrapper hdivWrapper, List<String> tablesEnConsultation, List<String> tablesEnCreation) {
		List<Collection<Object>> listeSansClefs = new ArrayList<>();

		for (TableDescriptionDto tableDescriptionDto : tables) {
			// Pour l'instant on ne recupere que le nom de la table
			List<Object> valeursModifiees = new ArrayList<Object>();
			valeursModifiees.add(tableDescriptionDto.getTableName());
			StringBuilder sb = new StringBuilder();
			if(hasOptionsDetailsTable(tableDescriptionDto) && tablesEnConsultation.contains(tableDescriptionDto.getTableName()) || tablesEnCreation.contains(tableDescriptionDto.getTableName())){
				sb.append("<a class=\"dropdown-toggle config\" data-toggle=\"dropdown\">Configure</a>");
				sb.append("<ul class=\"dropdown-menu\">");
				if(tableDescriptionDto.getConfiguration().getViewRecordOp() && tablesEnConsultation.contains(tableDescriptionDto.getTableName())){
					String urlDetails = "detailsTable?provenance=listeTables&tableName="+tableDescriptionDto.getTableName();
					String hdivUrlDetails = hdivWrapper.creerLienHDIV(urlDetails);
					roueCranteeUtil.ajouterBoutonConsulter(hdivUrlDetails, sb,tableDescriptionDto.getTableName());
				}
				if(tableDescriptionDto.getConfiguration().getAddNewRecordOp() && tablesEnCreation.contains(tableDescriptionDto.getTableName())){
					String urlCreer= "creerEnregistrement?provenance=listeTables&tableName="+tableDescriptionDto.getTableName();
					String hdivUrlCreer = hdivWrapper.creerLienHDIV(urlCreer);
					roueCranteeUtil.ajouterBoutonInserer(hdivUrlCreer,sb,tableDescriptionDto.getTableName());
				}
				String urlExporter = "exporterTable?provenance=listeTables&tableName="+tableDescriptionDto.getTableName();
				String hdivUrlExporter = hdivWrapper.creerLienHDIV(urlExporter);
				roueCranteeUtil.ajouterBoutonExporter(hdivUrlExporter,sb,tableDescriptionDto.getTableName());
			} else {
				sb.append("<span class='roue_absente'></span>");

			}

			valeursModifiees.add(sb.toString());
			listeSansClefs.add(valeursModifiees);

		}

		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		return gson.toJson(listeSansClefs);
	}

	private static boolean hasOptionsDetailsTable(TableDescriptionDto tableDescriptionDto) {
		return tableDescriptionDto.getConfiguration().getAddNewRecordOp() || tableDescriptionDto.getConfiguration().getViewRecordOp();
	}

	public static String creerPiedDePageListeTable() {
		StringBuilder piedDePage = new StringBuilder("<tfoot><tr>");
		piedDePage.append("<td><input></input></td>");
		piedDePage.append("<td class='hidden unprintable'></td>");
		piedDePage.append("</tr></tfoot>");

		return piedDePage.toString();
	}
	
	public static String obtenirURLAjax(HDIVWrapper hdivWrapper){
		String lienHDIV =  hdivWrapper.creerLienHDIV("../datatables");
		return lienHDIV;
		
	}





}
