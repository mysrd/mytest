package fr.icdc.dei.lm4.paraneo.presentation.exception;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

@SuppressWarnings("serial")
public class ErreurTechniqueException extends BusinessServiceException {

	private String message;

	@Value("${mvr.businessServiceExceptionDefault}")
	private String erreurTechnique;

	public ErreurTechniqueException(String pMessage){
		super(pMessage);
		message = pMessage;
	}

	public ErreurTechniqueException(String pMessage, String urlRetour) {
		super(pMessage, urlRetour);
		message = pMessage;
	}

	public ErreurTechniqueException(String pMessage, String pUrlRetour, Throwable cause) {
		super(pMessage, pUrlRetour, cause);
		message = pMessage;
	}

	@Override
	public String getMessage() {

		if (StringUtils.isNotBlank(message)) {
			return message;
		} else {
			return erreurTechnique;
		}
	}

}
