package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLongueurTypeCodifTiers;

public class StringToTaLongueurTypeCodifTiers implements Converter<String,TaLongueurTypeCodifTiers> {

	@Override
	public TaLongueurTypeCodifTiers convert(String arg0) {
		TaLongueurTypeCodifTiers object = new TaLongueurTypeCodifTiers();
		int argint = Integer.parseInt((arg0.split("-")[0]).trim());
		object.setYlgtct(argint);
		return object;
		}


}
