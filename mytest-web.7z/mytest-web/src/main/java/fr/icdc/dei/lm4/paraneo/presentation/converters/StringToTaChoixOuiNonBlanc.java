package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaChoixOuiNonBlanc;

public class StringToTaChoixOuiNonBlanc implements Converter<String,TaChoixOuiNonBlanc> {

	@Override
	public TaChoixOuiNonBlanc convert(String arg0) {
		TaChoixOuiNonBlanc object = new TaChoixOuiNonBlanc();
		object.setCodeChoixOuiNon(arg0.split("-")[0]);
		return object;
		}
}
