package fr.icdc.dei.edt.presentation.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.MultiValueMap;

import fr.icdc.dei.lm4.paraneo.utils.DatatablesColumnAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesInputAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesOrderAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesSearchAjax;

public class DatatablesAjaxMapper {
	/**
	 * Transforme les parametres HTTP envoyes par Datatables en un objet Java
	 * @param parameters
	 * @return
	 */
	public static DatatablesInputAjax structurerParametresDatatables(	MultiValueMap<String, String> parameters) {
		// Listes contenant les differentes informations
		Map<String, DatatablesColumnAjax> colonnes = new HashMap<String, DatatablesColumnAjax>();
		Map<String, DatatablesOrderAjax> ordres = new HashMap<String, DatatablesOrderAjax>();
		DatatablesSearchAjax search = new DatatablesSearchAjax();

		// On parcourt tous les parametres recus en deleguant le traitement en fonction du type de donnee
		for (Entry<String, List<String>> parameter : parameters.entrySet()) {
			if(parameter.getKey().contains("columns") ){
				structurerColonnes(colonnes, parameter);
			} else if(parameter.getKey().contains("order")){
				structurerOrdre(ordres, parameter);
			} else if(parameter.getKey().startsWith("search")){
				structurerRecherche(search, parameter);
			}
		}


		for (Entry<String,DatatablesOrderAjax> ordre : ordres.entrySet()) {
			Integer indexColonne = ordre.getValue().getColumn();
			DatatablesColumnAjax colonne = colonnes.get(indexColonne.toString());
			if(colonne!=null){
				colonne.setOrderDirection(ordre.getValue().getDirection());
			}
		}


		DatatablesInputAjax datatablesInput = new DatatablesInputAjax();
		datatablesInput.setColumns(colonnes);
		datatablesInput.setSearch(search);
		return datatablesInput;
	}

	/**
	 * Extrait les informations relatives a la recherche a partir des parametres envoyes par Datatables
	 * @param search
	 * @param parameter
	 */
	private static void structurerRecherche(DatatablesSearchAjax search, Entry<String, List<String>> parameter) {
		Pattern patternSearch = Pattern.compile("search\\[([a-z]+)\\]");
		Matcher matcherSearch = patternSearch.matcher(parameter.getKey());


		if(matcherSearch.matches()){
			String typeInformation = matcherSearch.group(1);
			switch (typeInformation) {
			case "value":
				search.setValue(parameter.getValue().get(0));
				break;
			case "regex":
				search.setRegex((Boolean.valueOf(parameter.getValue().get(0)).booleanValue()));
				break;
			default:
				break;
			}

		}
	}

	/**
	 * Extrait les informations relatives a l'ordre de tri des colonnes a partir des parametres envoyes par Datatables
	 * @param ordres
	 * @param parameter
	 */
	private static void structurerOrdre(Map<String, DatatablesOrderAjax> ordres, Entry<String, List<String>> parameter) {
		Pattern patternOrder = Pattern.compile("order\\[([0-9]{1})\\]\\[([a-z]+)\\]");
		Matcher matcherOrder = patternOrder.matcher(parameter.getKey());

		if(matcherOrder.matches()){
				String index = matcherOrder.group(1);
				String typeInformation = matcherOrder.group(2);
				DatatablesOrderAjax ordre = null;
				if(ordres.get(index)!=null){
					ordre = ordres.get(index);
				} else {
					ordre = new DatatablesOrderAjax();
				}


				switch (typeInformation) {
				case "column":
					ordre.setColumn(Integer.valueOf(parameter.getValue().get(0)));
					break;
				case "dir":
					ordre.setDirection(parameter.getValue().get(0));
					break;
				default:
					break;
				}

				ordres.put(index, ordre);
			}
	}

	/**
	 * Extrait les informations relatives aux colonnes a partir des parametres envoyes par Datatables
	 * @param colonnes
	 * @param parameter
	 */
	private static void structurerColonnes(Map<String, DatatablesColumnAjax> colonnes,	Entry<String, List<String>> parameter) {
		Pattern patternColumns = Pattern.compile("columns\\[([0-9]{1,2})\\]\\[([a-z]+)\\](\\[[a-z]+\\]){0,1}");
		Matcher matcherColumns = patternColumns.matcher(parameter.getKey());

		if(matcherColumns.matches()){
			String indexColonne = matcherColumns.group(1);
			String typeInformation = matcherColumns.group(2);
			String informationSupplementaire = matcherColumns.group(3);
			DatatablesColumnAjax colonne = null;
			if(colonnes.get(indexColonne)!=null){
				colonne = colonnes.get(indexColonne);
			} else {
				colonne = new DatatablesColumnAjax();
				colonne.setIndex(Integer.valueOf(indexColonne));
			}
			switch (typeInformation) {
			case "data":
				colonne.setData(parameter.getValue().toString());
				break;
			case "name":
				colonne.setName(parameter.getValue().toString());
				break;
			case "searchable":
				colonne.setSearchable(Boolean.valueOf(parameter.getValue().get(0)).booleanValue());
				break;
			case "orderable":
				colonne.setOrderable(Boolean.valueOf(parameter.getValue().get(0)).booleanValue());
				break;
			case "search":
				if ("[value]".equals(informationSupplementaire)){
					colonne.setSearchValue(parameter.getValue().get(0));
				}
				else if ("regex".equals(informationSupplementaire)){
					colonne.setSearchRegex(Boolean.valueOf(parameter
							.getValue().get(0)).booleanValue());
				}
				break;
			default:
				break;
			}

			colonnes.put(indexColonne, colonne);

		}
	}

}
