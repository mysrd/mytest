package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaMetierOperationnelTiersLmtay787;

public class StringToTaMetierOperationnelTiersLmtay787 implements Converter<String,TaMetierOperationnelTiersLmtay787> {

	@Override
	public TaMetierOperationnelTiersLmtay787 convert(String arg0) {
		TaMetierOperationnelTiersLmtay787 object = new TaMetierOperationnelTiersLmtay787();
		object.setCmetop(arg0.split("-")[0]);
		return object;
	}

}
