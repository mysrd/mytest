package fr.icdc.dei.lm4.paraneo.presentation.exception;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

/**
 * @author adhieb-e
 *
 */
@SuppressWarnings("serial")
public class HabilitationException extends BusinessServiceException {

	private String message;

	@Value("${mvr.common.habilitation.error}")
	private String habilitationError;

	public HabilitationException(String pMessage) {
		super(pMessage);
		message = pMessage;
	}

	@Override
	public String getMessage() {

		if (StringUtils.isNotBlank(message)) {
			return message;
		} else {
			return habilitationError;
		}
	}

}
