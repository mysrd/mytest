package fr.icdc.dei.edt.presentation.controller;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.ChampCalculeService;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesColumnAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesInputAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesOutputAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesSSPReturn;
import fr.icdc.dei.lm4.paraneo.utils.HDIVWrapper;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;

@Controller
public class DatatablesAjaxController {
	@Autowired
	private ValeursUtilisateurEdittable valeursUtilisateur;

	@Autowired
	private  HttpServletRequest request;

	@Autowired
    private ServletContext context;

	@Resource(name = "editTablesBusinessService")
	private ReferentielBusinessService service;

	@Resource(name="champCalculeService")
	private ChampCalculeService champCalculeService;
	
	private static final Logger LOGGER = Logger.getLogger(DatatablesAjaxController.class);

	@RequestMapping(value="/datatables",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DatatablesSSPReturn getData(@RequestParam("draw") Integer draw,
										@RequestParam("start") Integer start,
										@RequestParam("length") Integer length,
										@RequestParam MultiValueMap<String,String> parameters,
										@RequestParam("table") String table) throws BusinessServiceException{
		try {
			DatatablesInputAjax parametresStructures = DatatablesAjaxMapper.structurerParametresDatatables(parameters);
			// Filtrage pour retirer les colonnes calculees
			List<TableDescription> listeTables = service.getTableList();
			TableDescription descriptionTable =	IntrospectionUtils.getTableDescriptionFromTableName(listeTables,table);
			
			List<String> clefsARetirer = new ArrayList<String>();
			List<DatatablesColumnAjax> colonnesCalculeesFormatDatatables = new ArrayList<DatatablesColumnAjax>();
			List<String> colonnesCalculees = champCalculeService.obtenirColonnes(descriptionTable.getEntityClassName());
			for (Entry<String, DatatablesColumnAjax> entree : parametresStructures.getColumns().entrySet()) {
					for (String nomColonneCalculee : colonnesCalculees) {
						if(nomColonneCalculee.equals(entree.getValue().getName().replace("[", "").replace("]", ""))){
							clefsARetirer.add(entree.getKey());
							colonnesCalculeesFormatDatatables.add(entree.getValue());
						}
					}
				
			}
			
			for (String clef : clefsARetirer) {
				parametresStructures.getColumns().remove(clef);
			}

			
			
			LOGGER.debug("Conversion des arguments datatables en objet Java terminée");
			HDIVWrapper hdivWrapper = new HDIVWrapper(request, context);
			DatatablesOutputAjax retourBusiness = service.requeteDatatables(draw,start,length,parametresStructures, table,valeursUtilisateur.getTablesEnModification(),valeursUtilisateur.getTablesEnSuppression(),hdivWrapper, null);
			LOGGER.debug("Requête en base pour obtenir les données terminée");

			// Calcul des données calculées
				// index
				// nom du champ
				for (DatatablesColumnAjax colonneAjax : colonnesCalculeesFormatDatatables) {
					int index = colonneAjax.getIndex();
					String nom = colonneAjax.getName().replace("[","").replace("]","");
					LOGGER.debug("Alimentation de la colonne calculee "+nom);
					for (int i = 0; i < retourBusiness.getEnregistrementsBruts().size(); i++) {
						// On calcule les valeurs
						champCalculeService.calculerValeurChamps(retourBusiness.getEnregistrementsBruts().get(i));
						Class classeEnregistrement = retourBusiness.getEnregistrementsBruts().get(i).getClass();
						Field champ = classeEnregistrement.getDeclaredField(nom);
						champ.setAccessible(true);
						String resultatCalcul = (String) champ.get(retourBusiness.getEnregistrementsBruts().get(i));
						champ.setAccessible(false);
						LOGGER.debug("Calcul du champ "+nom+" avec pour resultat "+resultatCalcul);
						ArrayList liste = (ArrayList) retourBusiness.getEnregistrementsAlimentes().get(i);
						liste.add(index, resultatCalcul);
					}
					
				}
				
				
			// Insérer avec les données classiques
			DatatablesSSPReturn retour = new DatatablesSSPReturn();
			retour.draw = draw;
			int count = service.count(descriptionTable.getEntityClassName());
			LOGGER.debug("Count du nombre de lignes total terminé");
			retour.recordsTotal = count;
			retour.recordsFiltered = service.countDatatableFiltre(parametresStructures,descriptionTable);
			LOGGER.debug("Count du nombre de lignes filtrées terminé");

			retour.data = retourBusiness.getEnregistrementsAlimentes();
			valeursUtilisateur.setObjetsTableAAfficher(retourBusiness.getEnregistrementsBruts());
			return retour;
		} catch( HibernateException | NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e){
			LOGGER.debug(e);
			throw new BusinessServiceException(e);
		}

	}
	
	@ExceptionHandler(Throwable.class)
	public ModelAndView handleUncheckedException(Throwable e) {
		LOGGER.error(e.getMessage(), e);
		ModelAndView mav = new ModelAndView("runtime.exception.scene");
		return mav;
	}
	

}
