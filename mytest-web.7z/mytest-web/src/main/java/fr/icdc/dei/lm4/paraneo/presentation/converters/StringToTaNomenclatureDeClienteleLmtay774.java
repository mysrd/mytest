package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNomenclatureDeClienteleLmtay774;

public class StringToTaNomenclatureDeClienteleLmtay774 implements Converter<String,TaNomenclatureDeClienteleLmtay774> {

	@Override
	public TaNomenclatureDeClienteleLmtay774 convert(String arg0) {
		TaNomenclatureDeClienteleLmtay774 object = new TaNomenclatureDeClienteleLmtay774();
		object.setYcncli(arg0.split("-")[0]);
		return object;
	}



}
