@javax.xml.bind.annotation.XmlSchema(namespace = "http://dei.icdc.fr/lm4/paraneo/pivot/schema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package fr.icdc.dei.lm4.paraneo.pivot.schema;
