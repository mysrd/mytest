package fr.icdc.dei.edt.presentation.controller;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.xml.bind.annotation.XmlSeeAlso;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.context.support.WebApplicationContextUtils;

import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;
import fr.icdc.dei.lm4.paraneo.pivot.schema.Reponse;

public class ThreadCleanUpListener implements ServletContextListener {
	
	private static final Logger LOGGER = Logger.getLogger(ThreadCleanUpListener.class);
	
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		ApplicationContext appCtx = WebApplicationContextUtils.getWebApplicationContext(event.getServletContext());
		ThreadPoolTaskExecutor executor =(ThreadPoolTaskExecutor) appCtx.getBean("taskExecutor");
		executor.shutdown();
		LOGGER.info("Fermeture des threads lors de la destruction du contexte");
		
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void contextInitialized(ServletContextEvent event) {
		//On souhaite verifier que les tables qui sont notifiees sont egalement diffusees
		Class<Reponse> classeDeReponse = Reponse.class;
		XmlSeeAlso annotation = (XmlSeeAlso) classeDeReponse.getAnnotation(XmlSeeAlso.class);
		Class[] tablesDiffusees = annotation.value();	
		Class[] tablesNotifiees = ParaneoConstantes.TABLES_NOTIFIEES;
		if(!comparerClasses(tablesNotifiees,tablesDiffusees)){
			throw new RuntimeException("Les tables notifiées et les tables diffusées ne sont pas les mêmes. Démarrage de Paraneo bloqué !");
		}
		LOGGER.info("Vérification des tables notifiées et diffusées : OK. Démarrage de Paraneo autorisé.");
	}
	
	@SuppressWarnings("rawtypes")
	/**
	 * Compare deux tableaux de classe sur leur contenu et non pas sur leur instance
	 * @param tableau1
	 * @param tableau2
	 * @return
	 */
	private boolean comparerClasses(Class[] tableau1, Class[] tableau2){
		if(tableau1.length!=tableau2.length){
			return false;
		}
		
		for (int i = 0; i < tableau1.length; i++) {
			String nomClasse = tableau1[i].getName();
			boolean trouve = false;
			for (int j = 0; j < tableau2.length; j++) {
				if(tableau2[j].getName().equals(nomClasse)){
					trouve = true;
				}
			}
			if(!trouve) {
				return false;
			} 
		}
		return true;
	}

}
