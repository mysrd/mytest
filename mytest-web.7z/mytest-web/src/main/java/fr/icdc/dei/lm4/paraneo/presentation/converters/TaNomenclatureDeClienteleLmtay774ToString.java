package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNomenclatureDeClienteleLmtay774;

public class TaNomenclatureDeClienteleLmtay774ToString implements Converter<TaNomenclatureDeClienteleLmtay774,String> {

	@Override
	public String convert(TaNomenclatureDeClienteleLmtay774 arg0) {
		return arg0.getYcncli();
	}

}
