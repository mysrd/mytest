package fr.icdc.dei.lm4.paraneo.presentation.converters;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;

public class DateToString implements Converter<Date,String>{

	@Override
	public String convert(Date arg0) {
		return new SimpleDateFormat("dd/MM/yyyy").format(arg0);
	}


}
