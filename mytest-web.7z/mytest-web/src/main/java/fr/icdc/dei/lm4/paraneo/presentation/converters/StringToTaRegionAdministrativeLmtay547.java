package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegionAdministrativeLmtay547;

public class StringToTaRegionAdministrativeLmtay547 implements Converter<String,TaRegionAdministrativeLmtay547> {

	@Override
	public TaRegionAdministrativeLmtay547 convert(String arg0) {
		TaRegionAdministrativeLmtay547 object = new TaRegionAdministrativeLmtay547();
		object.setYc0rgi(arg0.split("-")[0]);
		return object;
	}

}
