package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategorieDeDeposantLmtay525;

public class StringToTaCategorieDeDeposantLmtay525 implements Converter<String,TaCategorieDeDeposantLmtay525> {

	@Override
	public TaCategorieDeDeposantLmtay525 convert(String arg0) {
		TaCategorieDeDeposantLmtay525 object = new TaCategorieDeDeposantLmtay525();
		object.setCcatde(arg0.split("-")[0]);
		return object;
	}

}
