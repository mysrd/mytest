package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLieuDeCompensationLmtay891;

public class TaLieuDeCompensationLmtay891ToString implements Converter<TaLieuDeCompensationLmtay891,String> {

	@Override
	public String convert(TaLieuDeCompensationLmtay891 arg0) {
		return arg0.getClcmc();
	}

}
