package fr.icdc.dei.lm4.paraneo.presentation.commun.helper;

import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import fr.icdc.dei.lm4.paraneo.critere.CritereRechercheMenu;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Menu;
import fr.icdc.dei.lm4.paraneo.metier.service.MenuBusinessService;
import fr.icdc.dei.lm4.paraneo.presentation.commun.dto.MenuDto;


@Component("cacheHolder")
public class CacheHolder implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String MENU_KEY = "MENU_SERVICE";
	private static final String USER = "USER";
	private static final String GROUP = "GROUP";
	private static final String VERSION = "VERSION";


	@Resource(name = "menuBusinessService")
	private MenuBusinessService menuService;


	/**
	 * R�cup�re la liste des menus accessibles en session
	 *
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<MenuDto> getMenuItems() {
		HttpSession session = HttpRuntimeHelper.getSessionContext();

		List<MenuDto> result = (List<MenuDto>) session.getAttribute(CacheHolder.MENU_KEY);

		// Si les menus ne sont pas en cache
		if (result == null) {
			// On récupére l'identité de l'utilsateur
			UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			session.setAttribute(CacheHolder.USER, userDetails.getUsername());
			CritereRechercheMenu critere = new CritereRechercheMenu();
			if (userDetails.getAuthorities() != null && userDetails.getAuthorities().size() > 0) {
				Iterator<? extends GrantedAuthority> authorityIterator = userDetails.getAuthorities().iterator();
				StringBuilder sb = new StringBuilder();
				while(authorityIterator.hasNext()){
					sb.append(authorityIterator.next().getAuthority());
					if(authorityIterator.hasNext()){
						sb.append("/");
					}
				}

				session.setAttribute(CacheHolder.GROUP, sb.toString());

			}
			// Mapping des menus
			List<Menu> menuItems = this.menuService.construireMenus(critere);

			result = MappingUtils.mapList(menuItems, MenuDto.class);

			session.setAttribute(CacheHolder.MENU_KEY, result);
		}
		return result;
	}

	/**
	 * Récupère la version de l'application en session
	 *
	 * @throws IOException
	 */
	public void getVersion() throws IOException {
		HttpSession session = HttpRuntimeHelper.getSessionContext();
		String result = (String) session.getAttribute(CacheHolder.VERSION);
		// Si la version n'est pas en cache
		if (StringUtils.isBlank(result)) {
			result = VersionUtil.readVersion();
			session.setAttribute(CacheHolder.VERSION, result);
		}
	}




}
