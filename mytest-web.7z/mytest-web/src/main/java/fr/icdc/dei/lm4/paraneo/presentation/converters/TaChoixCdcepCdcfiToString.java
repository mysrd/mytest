package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaChoixCdcepCdcfi;

public class TaChoixCdcepCdcfiToString implements Converter<TaChoixCdcepCdcfi,String> {

	@Override
	public String convert(TaChoixCdcepCdcfi arg0) {
		return arg0.getC0etcd();
	}


}
