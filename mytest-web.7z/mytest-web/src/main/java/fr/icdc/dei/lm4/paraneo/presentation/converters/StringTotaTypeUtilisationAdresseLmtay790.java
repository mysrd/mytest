package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeUtilisationAdresseLmtay790;

public class StringTotaTypeUtilisationAdresseLmtay790 implements Converter<String,TaTypeUtilisationAdresseLmtay790> {

	@Override
	public TaTypeUtilisationAdresseLmtay790 convert(String arg0) {
		TaTypeUtilisationAdresseLmtay790 object = new TaTypeUtilisationAdresseLmtay790();
		object.setCtutad(arg0.split("-")[0]);
		return object;
	}



}
