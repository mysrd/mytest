package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTypeUtilisationAdresseLmtay790;

public class TaTypeUtilisationAdresseLmtay790ToString implements Converter<TaTypeUtilisationAdresseLmtay790,String> {

	@Override
	public String convert(TaTypeUtilisationAdresseLmtay790 arg0) {
		return arg0.getCtutad();
	}

}
