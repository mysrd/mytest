package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodeAgentFinancier;

public class StringToTaCodeAgentFinancier implements Converter<String,TaCodeAgentFinancier> {

	@Override
	public TaCodeAgentFinancier convert(String arg0) {
		TaCodeAgentFinancier object = new TaCodeAgentFinancier();
		object.setCagtf(arg0.split("-")[0]);
		return object;
		}


}



