package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleDeCatgEcoAnalyseLmtay530;

public class StringToTaFamilleDeCatgEcoAnalyseLmtay530 implements Converter<String,TaFamilleDeCatgEcoAnalyseLmtay530> {

	@Override
	public TaFamilleDeCatgEcoAnalyseLmtay530 convert(String arg0) {
		TaFamilleDeCatgEcoAnalyseLmtay530 object = new TaFamilleDeCatgEcoAnalyseLmtay530();
		object.setCfceco(arg0.split("-")[0]);
		return object;
	}



}
