package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaProfilTitulaireLmtay400;

public class TaProfilTitulaireLmtay400ToString implements Converter<TaProfilTitulaireLmtay400,String> {

	@Override
	public String convert(TaProfilTitulaireLmtay400 arg0) {
		return arg0.getCprtit();
	}

}
