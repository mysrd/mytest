package fr.icdc.dei.lm4.paraneo.presentation.converters;
import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaNiveauAgregationNomenclature;

public class StringToTaNiveauAgregationNomenclature implements Converter<String,TaNiveauAgregationNomenclature> {

	@Override
	public TaNiveauAgregationNomenclature convert(String arg0) {
		TaNiveauAgregationNomenclature object = new TaNiveauAgregationNomenclature();
		object.setCnagno(arg0.split("-")[0]);
		return object;
		}


}
