package fr.icdc.dei.lm4.paraneo.pivot.definition;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.pivot.schema.Reponse;
import fr.icdc.dei.lm4.paraneo.pivot.schema.Requete;
import fr.icdc.dei.lm4.paraneo.pivot.service.ParaneoPivot;
import fr.icdc.dei.lm4.paraneo.pivot.service.ParaneoPivotException;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;

@WebService(endpointInterface="fr.icdc.dei.lm4.paraneo.pivot.service.ParaneoPivot", portName="ParaneoPivot", serviceName="ParaneoService")
@Component("ParaneoPivot")
public class ParaneoPivotImpl implements ParaneoPivot {

	private static final Logger LOGGER = Logger.getLogger(ParaneoPivotImpl.class);

	@Resource(name = "editTablesBusinessService")
	private ReferentielBusinessService service;

	@Resource(name = "mapper")
	private Mapper mapper;


	@Override
	@WebMethod(action = "http://dei.icdc.fr/paraneo/pivot/service/demanderEnregistrement")
	@WebResult(name = "Reponse", targetNamespace = "http://dei.icdc.fr/lm4/paraneo/pivot/schema", partName = "parameters")
	public Reponse demanderEnregistrement(@WebParam(name = "Requete", targetNamespace = "http://dei.icdc.fr/lm4/paraneo/pivot/schema", partName = "parameters") Requete parameters) throws ParaneoPivotException {
		Reponse reponse = new Reponse();
		try {
			// Le nom de la table recherchée nous est fourni lors de l'appel du WS
			String nomTableARecuperer = parameters.getTABLE();

			// On récupére l'entité Hibernate correspondant à cette table
			Class<?> classeEntite = getEntite(nomTableARecuperer);

			Object enregistrementTable = null;

			if(parameters.getIDENTIFIANT().contains("|")){
				String[] valeursBrutes = StringUtils.split(parameters.getIDENTIFIANT(),"|");
				List<Object> valeursTypees = new ArrayList<>();
				for (int i = 0; i < valeursBrutes.length; i++) {
					if(valeursBrutes[i].matches("\\d{4}-\\d{2}-\\d{2}")){
						SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
						Date date = sdf.parse(valeursBrutes[i]);
						valeursTypees.add(date);
					} else {
						valeursTypees.add(valeursBrutes[i]);
					}

				}

				TableDescription tableMetadata = getTableMetadata(nomTableARecuperer);
				List<ColumnDescription> listeColonnes = tableMetadata.getColumnList();
				Collections.sort(listeColonnes);
				List<String> clefsPrimaire = new ArrayList<String>();

				for (ColumnDescription colonne : listeColonnes) {
					if(colonne.isPrimaryKey()){
						if(colonne.isForeignKey()){
							clefsPrimaire.add((colonne.getPropertyName()+"."+colonne.getColumnName().toLowerCase()));
						} else {
							clefsPrimaire.add(colonne.getColumnName().toLowerCase());
						}
					}
				}

				enregistrementTable = service.findByMultiCriteria(classeEntite,clefsPrimaire,valeursTypees);


			} else {
				// Si la valeur a un format de date
				if(parameters.getIDENTIFIANT().matches("\\d{4}-\\d{2}-\\d{2}")){
					SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
					try {
						Date date = sdf.parse(parameters.getIDENTIFIANT());
						enregistrementTable =  service.findById(classeEntite,date);
					} catch (ParseException e) {
						LOGGER.error(e);
						throw new ParaneoPivotException("Erreur technique",createParaneoPivotException(2, "Erreur technique")); // NOSONAR
					}

				} else {
					// On récupére l'enregistrement de la table correspondant l'identifiant qui nous est fourni
					enregistrementTable =  service.findById(classeEntite,parameters.getIDENTIFIANT());
				}
			}


			if(enregistrementTable == null){
				throw new ParaneoPivotException("Enregistrement non trouvé pour la table demandée", createParaneoPivotException(1,"Enregistrement non trouvé pour la table demandée" )); // NOSONAR
			}

			// On place l'enregistrement dans la réponse
			reponse.setAny(enregistrementTable);

		} catch (BusinessServiceException e) {
			LOGGER.error(e);
			throw new ParaneoPivotException("Erreur technique",createParaneoPivotException(2, "Erreur technique")); // NOSONAR
		} catch (ParseException e) {
			LOGGER.error(e);
			throw new ParaneoPivotException("Erreur technique",createParaneoPivotException(2, "Erreur technique")); // NOSONAR
		}
		// On retourne la réponse
		return reponse;
	}





	/**
	 * Fournit l'entité correspondant à la table à récuperer
	 * @param tableARecuperer
	 * @return
	 * @throws BusinessServiceException
	 * @throws ClassNotFoundException
	 * @throws ParaneoPivotException
	 */
	private Class<?> getEntite(String tableARecuperer) throws BusinessServiceException, ParaneoPivotException {
		List<TableDescription> listeDesTables = service.getTableList();
		String nomDeLentite = IntrospectionUtils.getClassNameFromTableName(listeDesTables, tableARecuperer);

		// On retourne la clef primaire sous forme de String
		try {
			Class<?> classeEntite = Class.forName(nomDeLentite);
			return classeEntite;
		} catch(ClassNotFoundException e){
			LOGGER.error(e);
			throw new ParaneoPivotException("Table non gérée par l'application",createParaneoPivotException(0, "Table non gérée par l'exception")); // NOSONAR
		}
	}

	private TableDescription getTableMetadata(String tableARecuperer) throws BusinessServiceException{
		List<TableDescription> listeDesTables = service.getTableList();
		TableDescription tableMetadata = IntrospectionUtils.getTableDescriptionFromTableName(listeDesTables, tableARecuperer);

		return tableMetadata;

	}

	private fr.icdc.dei.lm4.paraneo.pivot.schema.ParaneoPivotException createParaneoPivotException(int codeErreur, String message){
		fr.icdc.dei.lm4.paraneo.pivot.schema.ParaneoPivotException exception = new fr.icdc.dei.lm4.paraneo.pivot.schema.ParaneoPivotException();
		exception.setCodeErreur(codeErreur);
		exception.setMessageErreur(message);
		return exception;
	}




}
