package fr.icdc.dei.lm4.paraneo.presentation.commun.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import fr.icdc.dei.fwk.web.controller.AbstractFormBaseController;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.presentation.commun.dto.MenuDto;
import fr.icdc.dei.lm4.paraneo.presentation.commun.helper.CacheHolder;
import fr.icdc.dei.lm4.paraneo.presentation.commun.helper.HttpRuntimeHelper;
import fr.icdc.dei.lm4.paraneo.presentation.exception.ErreurTechniqueException;
import fr.icdc.dei.lm4.paraneo.presentation.exception.HabilitationException;

/**
 * @author adhieb-e
 *
 */
public abstract class AbstractReferentielController extends AbstractFormBaseController {

	private static final String EXCEPTION_MESSAGE = "exceptionMessage";

	private static final Logger LOGGER = Logger.getLogger(AbstractReferentielController.class);

	@Resource(name = "cacheHolder")
	protected CacheHolder cacheHolder;

	@Value("${mvr.businessServiceExceptionDefault}")
	private String erreurTechnique;



	@Resource(name = "mapper")
	protected Mapper mapper;

	/**
	 * @param codeMenu
	 * @param codeSousMenu
	 */
	public void pickMenu(String codeMenu, String codeSousMenu) {
		List<MenuDto> menusDto = cacheHolder.getMenuItems();
		if (menusDto != null && menusDto.size() > 0 && StringUtils.isNotBlank(codeMenu)) {
			for (MenuDto menu : menusDto) {
				if (menu.getCodeMenu().equals(codeMenu)) {
					menu.setEstSelectionne(Boolean.TRUE);
					List<MenuDto> sousMenus = menu.getNoeudsEnfants();
					if (sousMenus != null && sousMenus.size() > 0 && StringUtils.isNotBlank(codeSousMenu)) {
						for (MenuDto sousMenu : sousMenus) {
							if (sousMenu.getCodeMenu().equals(codeSousMenu)) {
								sousMenu.setEstSelectionne(Boolean.TRUE);
							} else {
								sousMenu.setEstSelectionne(Boolean.FALSE);
							}
						}
					}
				} else {
					menu.setEstSelectionne(Boolean.FALSE);
					List<MenuDto> sousMenus = menu.getNoeudsEnfants();
					for (MenuDto sousMenu : sousMenus) {
						sousMenu.setEstSelectionne(Boolean.FALSE);
					}
				}
			}
		}
	}

	/**
	 * @param codeMenu
	 * @return un booleen indiquant si l'utilisateur a le droit d'acceder au
	 *         menu demande
	 */
	public boolean hasHabilitation(String codeMenu) {
		MenuDto found = recursiveFind(cacheHolder.getMenuItems(), codeMenu);
		// Si le menu a été trouvé, l'utilisateur a les droits
		return (found != null);
	}

	/**
	 * Permet de trouver un noeud du menu de façon récursive
	 *
	 * @param menusDto
	 * @param codeMenu
	 * @return
	 */
	private MenuDto recursiveFind(List<MenuDto> menusDto, String codeMenu) {
		for (MenuDto menuItem : menusDto) {
			if (menuItem.getCodeMenu().equals(codeMenu)) {
				return menuItem;
			}
			if (menuItem.getNoeudsEnfants() != null && menuItem.getNoeudsEnfants().size() > 0) {
				MenuDto found = recursiveFind(menuItem.getNoeudsEnfants(), codeMenu);
				if (found != null) {
					return found;
				}
			}
		}
		return null;
	}

	/**
	 * Alias permettant la récupération du contextde de session dans le
	 * controller
	 *
	 * @return
	 */
	protected HttpSession getSessionContext() {
		return HttpRuntimeHelper.getSessionContext();
	}


	@ExceptionHandler(HabilitationException.class)
	public ModelAndView handleHabilitationException(HabilitationException e) {
		LOGGER.error(e.getMessage(), e);
		// Rendering the "error" view to handle the exception
		ModelAndView mav = new ModelAndView("business.exception.scene");
		mav.addObject(EXCEPTION_MESSAGE, e.getMessage());
		return mav;
	}

	@ExceptionHandler(ErreurTechniqueException.class)
	public ModelAndView handleErreurTechniqueException(ErreurTechniqueException e) {
		LOGGER.error(e.getMessage(), e);
		// Rendering the "error" view to handle the exception
		ModelAndView mav = new ModelAndView("runtime.exception.scene");
		mav.addObject(EXCEPTION_MESSAGE, e.getMessage());
		mav.addObject("urlRetour", e.getUrlRetour());
		return mav;
	}

	@ExceptionHandler(BusinessServiceException.class)
	public ModelAndView handleBusinessServiceException(BusinessServiceException e) {
		LOGGER.error(e.getMessage(), e);
		// Rendering the "error" view to handle the exception
		ModelAndView mav = new ModelAndView("business.exception.scene");
		mav.addObject(EXCEPTION_MESSAGE, e.getMessage());
		mav.addObject("urlRetour", e.getUrlRetour());
		return mav;
	}

	@Override
	@ExceptionHandler(Throwable.class)
	public ModelAndView handleUncheckedException(Throwable e) {
		LOGGER.error(e.getMessage(), e);
		ModelAndView mav = new ModelAndView("runtime.exception.scene");
		mav.addObject(EXCEPTION_MESSAGE, erreurTechnique);
		return mav;
	}

}
