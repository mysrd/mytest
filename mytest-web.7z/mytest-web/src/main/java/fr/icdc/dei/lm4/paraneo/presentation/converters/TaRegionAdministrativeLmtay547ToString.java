package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegionAdministrativeLmtay547;

public class TaRegionAdministrativeLmtay547ToString implements Converter<TaRegionAdministrativeLmtay547,String> {

	@Override
	public String convert(TaRegionAdministrativeLmtay547 arg0) {
		return arg0.getYc0rgi();
	}

}
