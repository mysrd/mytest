package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaArticleMajuscule;

public class TaArticleMajusculeToString implements Converter<TaArticleMajuscule,String> {

	@Override
	public String convert(TaArticleMajuscule arg0) {
		return arg0.getArtmaj();
	}

}
