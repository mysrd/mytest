package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDeviseLmtay502;

public class TaDeviseLmtay502ToString implements Converter<TaDeviseLmtay502,String> {

	@Override
	public String convert(TaDeviseLmtay502 arg0) {
		return arg0.getCdev();
	}

}
