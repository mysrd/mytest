package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaRegion2016;

public class TaRegion2016ToString implements Converter<TaRegion2016,String> {

	@Override
	public String convert(TaRegion2016 arg0) {
		return arg0.getRegion();
	}

}
