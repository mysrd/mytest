package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaTopSiegeReseau;

public class StringToTaTopSiegeReseau implements Converter<String,TaTopSiegeReseau> {

	@Override
	public TaTopSiegeReseau convert(String arg0) {
		TaTopSiegeReseau object = new TaTopSiegeReseau();
		object.setTsigre(arg0.split("-")[0]);
		return object;
	}

}
