package fr.icdc.dei.lm4.paraneo.presentation.commun.helper;

import java.util.ArrayList;
import java.util.List;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MappingUtils {

	private static Mapper mapper;

	public static <Tin extends Object, Tout extends Object> List<Tout> mapList(List<Tin> input, Class<Tout> _class){

		//
		List<Tout> result = new ArrayList<Tout>();
		if (input != null && input.size() > 0) {
			for (Tin item : input) {
				result.add(mapper.map(item, _class));
			}
		}
		return result;
	}


	@Autowired
    public void setMapper(Mapper mapper){
        MappingUtils.mapper = mapper;
    }

}


