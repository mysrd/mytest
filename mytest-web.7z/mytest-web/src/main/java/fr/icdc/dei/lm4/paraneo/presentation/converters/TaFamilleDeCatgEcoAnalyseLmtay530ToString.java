package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFamilleDeCatgEcoAnalyseLmtay530;



public class TaFamilleDeCatgEcoAnalyseLmtay530ToString implements Converter<TaFamilleDeCatgEcoAnalyseLmtay530,String> {

	@Override
	public String convert(TaFamilleDeCatgEcoAnalyseLmtay530 arg0) {
		return arg0.getCfceco();
	}

}
