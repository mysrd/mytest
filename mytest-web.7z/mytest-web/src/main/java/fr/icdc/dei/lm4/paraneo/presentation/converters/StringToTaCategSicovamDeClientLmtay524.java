package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCategSicovamDeClientLmtay524;

public class StringToTaCategSicovamDeClientLmtay524 implements Converter<String,TaCategSicovamDeClientLmtay524> {

	@Override
	public TaCategSicovamDeClientLmtay524 convert(String arg0) {
		TaCategSicovamDeClientLmtay524 object = new TaCategSicovamDeClientLmtay524();
		object.setCcacli(arg0.split("-")[0]);
		return object;
	}

}
