package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaFormeJuridiqueDgiLmtay518;

public class TaFormeJuridiqueDgiLmtay518ToString implements Converter<TaFormeJuridiqueDgiLmtay518,String> {

	@Override
	public String convert(TaFormeJuridiqueDgiLmtay518 arg0) {
		return arg0.getYc0fjd();
	}

}
