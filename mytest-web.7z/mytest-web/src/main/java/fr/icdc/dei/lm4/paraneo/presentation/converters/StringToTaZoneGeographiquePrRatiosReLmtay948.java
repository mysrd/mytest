package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaZoneGeographiquePrRatiosReLmtay948;

public class StringToTaZoneGeographiquePrRatiosReLmtay948 implements Converter<String,TaZoneGeographiquePrRatiosReLmtay948> {

	@Override
	public TaZoneGeographiquePrRatiosReLmtay948 convert(String arg0) {
		TaZoneGeographiquePrRatiosReLmtay948 object = new TaZoneGeographiquePrRatiosReLmtay948();
		object.setCzgeor(arg0.split("-")[0]);
		return object;
	}

}
