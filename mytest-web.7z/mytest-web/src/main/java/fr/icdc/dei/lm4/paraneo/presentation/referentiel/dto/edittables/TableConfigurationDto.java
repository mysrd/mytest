package fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables;

import java.util.List;

import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.AbstractDto;

public class TableConfigurationDto extends AbstractDto {

	private boolean addNewRecordOp;

	private boolean deleteRecordOp;

	private boolean editRecordOp;

	private boolean viewRecordOp;

	/**
	 * Le nom physique de la table.
	 */
	private String name;

	/**
	 * Le nom de la table tel qu'il sera afffiché.
	 */
	private String label;

	/**
	 * Le nombre de ligne par page qu'on souhaite afficher.
	 */
	private int pagination;

	private List<String> validationFiles;

	private String validationFormName;

	// ~~ Getters & Setters
	/*
	 * (non-Javadoc)
	 *
	 * @see fr.icdc.dei.edt.core.configuration.TableConfiguration#getLabel()
	 */
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	/*
	 * (non-Javadoc)s
	 *
	 * @see fr.icdc.dei.edt.core.configuration.TableConfiguration#getName()
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPagination(int pagination) {
		this.pagination = pagination;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * fr.icdc.dei.edt.core.configuration.TableConfiguration#getPagination()
	 */
	public int getPagination() {
		return pagination;
	}

	public void setValidationFiles(List<String> validationFiles) {
		this.validationFiles = validationFiles;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * fr.icdc.dei.edt.core.configuration.TableConfiguration#getValidationFiles
	 * ()
	 */
	public List<String> getValidationFiles() {
		return validationFiles;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * fr.icdc.dei.edt.core.configuration.TableConfiguration#getValidationFormName
	 * ()
	 */
	public String getValidationFormName() {
		return this.validationFormName;
	}

	public void setValidationFormName(String validationFormName) {
		this.validationFormName = validationFormName;
	}

	public boolean getAddNewRecordOp() {
		return addNewRecordOp;
	}

	public void setAddNewRecordOp(boolean addNewRecordOp) {
		this.addNewRecordOp = addNewRecordOp;
	}

	public boolean getDeleteRecordOp() {
		return deleteRecordOp;
	}

	public void setDeleteRecordOp(boolean deleteRecordOp) {
		this.deleteRecordOp = deleteRecordOp;
	}

	public boolean getEditRecordOp() {
		return editRecordOp;
	}

	public void setEditRecordOp(boolean editRecordOp) {
		this.editRecordOp = editRecordOp;
	}

	public boolean getViewRecordOp() {
		return viewRecordOp;
	}

	public void setViewRecordOp(boolean viewRecordOp) {
		this.viewRecordOp = viewRecordOp;
	}

}
