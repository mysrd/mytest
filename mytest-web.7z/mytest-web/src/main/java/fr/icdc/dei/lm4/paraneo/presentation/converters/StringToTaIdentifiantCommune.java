package fr.icdc.dei.lm4.paraneo.presentation.converters;

import org.springframework.core.convert.converter.Converter;

import fr.icdc.dei.lm4.paraneo.entite.transverse.TaIdentifiantCommune;

public class StringToTaIdentifiantCommune implements Converter<String,TaIdentifiantCommune> {

	@Override
	public TaIdentifiantCommune convert(String arg0) {
		TaIdentifiantCommune object = new TaIdentifiantCommune();
		object.setIdcom(arg0.split("-")[0]);
		return object;
	}

}
