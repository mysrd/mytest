$(function()
{
	var messages = {};
	$("#customMessageContainer option").each(function(id, el) {
		messages[$(el).attr("value")] = $(el).html();
	});

	$.validator.addMethod("requireIdentifiant", function(value, element) {
		return (value != null && value != "");
	}, messages.identifiantObligatoire);

	$.validator.addMethod("requireMdp", function(value, element) {
		return (value != null && value != "");
	}, messages.mdpObligatoire);

	validateForm("#login_form", {});
});