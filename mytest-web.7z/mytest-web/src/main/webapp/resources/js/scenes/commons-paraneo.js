$(function()
{

	
	$(document).ready(function() {
	
// metadata

		$.metadata.setType("attr", "data-rule");

// metadata


// select 2

			$('.select2').select2();


// fin select 2		
	});
	
});

