$(function(){

	menuResponsive();

	/*
	 * Calcul de la hauteur du menu � l'initialisation de la page
	 */
	calculHauteurMenu();

	/*
	 *Activation du scroll customis� sur le menu
	 */
	$('#menu-niveau-1').enscroll();



	/*
	 *Script ex�cut� lors du resize de la fen�tre
	 */
	$(window).resize(function() {

		//Calcul de la hauteur du menu lors du resize de la fen�tre
		calculHauteurMenu();

		menuResponsive();

	});



	/*
	 * Ajout ou retrait de la classe "menu-selectionne" sur le lien lorsqu'on d�plie ou replie un menu
	 */
    $('#menu-niveau-1').on('hide', function (e) {

    	$(e.target).closest("div.accordion-group").find("a[data-toggle='collapse']").first().removeClass("menu-selectionne");
    });
    $('#menu-niveau-1').on('show', function (e) {
//    	$(e.target).closest("div.accordion-group").siblings().each(function(){
//    		$(this).first("a[data-toggle='collapse']").removeClass("menu-selectionne");
//    	});
    	$(e.target).closest("div.accordion-group").find("a[data-toggle='collapse']").first().addClass("menu-selectionne");
    });

    $('#menuPortlet .menu-selectionne').parents('#menuPortlet .accordion-body').each(function(){
    	$(this).addClass("in");
    	$(this).prev().find("a[data-toggle='collapse']").addClass("menu-selectionne");
    });

    $('#menuPortlet a').click(function(){
    	$(this).addClass("menu-selectionne");
    	$(this).closest("div.accordion-group").siblings().each(function(){
    		$(this).find("a.accordion-toggle").first().removeClass("menu-selectionne");
    		//$(this).find("div.accordion-body").first().attr("style","");
    		//$(this).find("div.accordion-body").first().removeClass("in");
    	});
    });

});

function menuResponsive()
{
	//Passage d'une position fixe � relative du lorsque la fen�tre est inf�rieur � 768px
	var windowWidth = $(window).width();
	if(windowWidth<768)
	{
		$("#menuPortlet").css("position", "relative");
		$('.enscroll-track').remove();
	}
	else
	{
		$("#menuPortlet").css("position", "fixed");
		$('.enscroll-track').remove();
		$('#menu-niveau-1').enscroll();
	}
}

/*
 * Fonction qui calcule la taille du menu afin de l'ajuster � la taille de la fen�tre
 */
function calculHauteurMenu()
{
	var windowHeight = $(window).height();

	var menuHeight = $("#menuPortlet").height();
	var headerHeight = $("#bandeau").height();
	var ongletHeight = $("#onglet-menu").height();
	var filtreHeight = $("#filtre-menu").height();
	var titreHeight = $("#titre-menu").height();
	var newEntreeHeight = windowHeight-headerHeight-ongletHeight-filtreHeight-titreHeight-200;
	$('#menu-niveau-1').css("height", newEntreeHeight);
	$('#menu-niveau-1').css("width", $(".span3").width()-10);
}