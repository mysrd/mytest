if (window.CDC == null) {
	CDC = {};
}

CDC.relativeImagePath = "../..";


// Initialisation du datatable
$(function() {
	/** ** Start datatable configuration ID=listeTablesTable ** */
	// Activation du datatable listeTablesTable
	/*var options = {
		iDisplayLength : -1,
		// choisir la colonne � trier
		aaSorting : [ [ 0, 'asc' ] ],
		aoColumnDefs : []
	};*/

	// Colonnes non triables
	/*options.aoColumnDefs.push({
		bSortable : false,
		aTargets : []
	// d�finir les colonnes sans tri
	});*/

	// Cr�ation table.
	/*createDatatable("#listeTablesTable", options, {
		pdf : false,
		csv : false,
		print : false
	});*/
	var options = {
	        "data": dataset,
	        "columns": columns,
	        "deferRender": true,
	        "columnDefs": [{
				bVisible: true,
				aTargets: ['_all']
	        }],
	        "aaSorting" : [],
			"lengthChange": false,
			"lengthMenu": [[5, 10, 25,-1],[5, 10, 25,"Tous"]],
			"pageLength": -1};

	var table = createDatatableParaneo("#prototype", options);
	$("th").first().addClass("coinArrondiHaut");
	$("tr td").each(function() {
		$(this).attr("id",$(this).text());
	});



	// Ajout des �v�nements sur les boutons (
	$("table.dataTable").on('click','.consultationTableButton', goToDetailsTable);
	$("table.dataTable").on('click','.ajoutTableButton', goToCreationEnregistrement);
	$("table.dataTable").on('click','.exportTableButton', goToExportTable);
	/** ** End datatable configuration ID=listeTablesTable ** */

	// On actualise les �lements du layout qui doivent �tre recalcul�s
	resizeHeight();
});


/**
 * Fonction permettant d'aller vers la page de d�tails d'une table.
 *
 * @returns {Boolean}
 */
function goToDetailsTable() {
	window.location = $(this).attr('lien');
	return false;
};

function goToCreationEnregistrement() {
	window.location = $(this).attr('lien');
	return false;
};

function goToExportTable(){
	window.location = $(this).attr('lien');
	return false;
}

