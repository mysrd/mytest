// metadata
if(window.CDC == null){
	window.CDC = {};
}

if(CDC.Messages == null){
	CDC.Messages = {};
}

$("#customMessageContainer option").each(function(id, el) {
	CDC.Messages[$(el).attr("value")] = $(el).html();
});


/**
 * Regles de valdiation communes
 */

//Date backoffice obligatoire (message custom)
$.validator.addMethod(
		"requireDateBackOffice",
		function(value, element) {
			return (value != null && value != "");
		},
		CDC.Messages.dateBackOfficeObligatoire);

//Date backoffice invalide (message custom)
$.validator.addMethod(
		"formatDateBackOffice",
		function(value, element) {
			return parseFrenchDate(value) != null;
		},
		CDC.Messages.dateBackOfficeInvalide);

//Date backoffice anterieure (message custom)
$.validator.addMethod(
		"maxDateBackOffice",
		function(value, element) {
			var tomorrow = new Date();
			tomorrow.setHours(0, 0, 0, 0);
			tomorrow.setDate(tomorrow.getDate() + 1);
			return (parseFrenchDate(value) < tomorrow);
		},
		CDC.Messages.dateBackOfficeMax);



//Numero de version obligatoire (message custom)
$.validator.addMethod(
		"requireNumeroVersion",
		function(value, element) {
			return (value != null && value != "");
		},
		CDC.Messages.numeroVersionObligatoire
);


//Numero de version incorrect (message custom)
$.validator.addMethod(
		"formatNumeroVersion",
		function(value, element) {
			return /^[0-9]{0,2}$/.test(value);
		},
		CDC.Messages.numeroVersionFormat
);

CDC.common = {
		// Valeurs initiales du formulaire de crit�re
		initialFilterState : {
			dateBackOffice : $("#dateBackOffice").val(),
			numVersion : $("#numeroVersion").val()
		},

		changeDateNumVersion : function(formName, urlRedirect, reinitFunction) {
			// V�rfication des modifications
			var dateBackOfficeChange = $("#dateBackOffice").val() !=CDC.common.initialFilterState.dateBackOffice;
			var numeroVersionChange = $("#numeroVersion").val() !=CDC.common.initialFilterState.numVersion;

			// S'il y a des changements
			if (dateBackOfficeChange || numeroVersionChange) {

				// Si le formulaire n'est pas valide
				if (!validateForm(formName, {})) {
					// On ne fait rien (affichage des erreurs dans validateForm)
					return false;
				}

				// Si changement on affiche la modal popup
				$('#pop-filter-confirm').modal({
					backdrop : 'static',
					keyboard : false,
					show : true
				});

				$("#confirmChangeForm").bind('click', function() {
					// R�initialisation des champs
					reinitFunction();

					// Envoi du formulaire de crit�re
					submitForm(formName, urlRedirect);
				});
				$("#cancelChangeForm")
				.bind('click',function() {
					// R�initialisation des champs
					$("#dateBackOffice").val(CDC.common.initialFilterState.dateBackOffice);
					$("#numeroVersion").val(CDC.common.initialFilterState.numVersion);
				});
			}
		},

		/** Retourne le nombre de checkbox visibles */
		visibleCheckboxNumber : function(table){
			var oDT = $(table).dataTable();

			var oSettings = oDT.fnSettings();
			var numberOfCb = 0;

			for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ )
			{
			    	var eTr = oDT.fnGetNodes(oSettings.aiDisplay[ i ]);
			    	var eInputCheckbox = $('input[type="checkbox"]', eTr).not(":disabled");

			    	if($(eInputCheckbox).length > 0)
			    	{
			    		numberOfCb ++;
			    	}
			}
			return numberOfCb;
		}
};
