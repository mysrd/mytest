if (window.CDC == null) {
	CDC = {};
}

CDC.relativeImagePath = "../..";


// Initialisation du datatable
$(function() {
	
	var options = {
			"columns": columns,   // La variable columns est injectee dans la JSP
	        "deferRender": true, 
	        "lengthChange": true,
			"lengthMenu": [[5, 10, 25],[5, 10, 25]],
			"pageLength": 25,
	        "serverSide" : true,  // Le traitement se fait cote serveur
	        "ajax": {			
	        	"url": urlajax,
	        	"data": function (d) {
	        		d.table = $("a.element.current").text().trim(); // Lors de l'appel au serveur on envoie le nom de la table
	        	}
	        }

	};
	
	/** ** Start datatable configuration ID=listeColonnesTable ** */
	var nombreColonnes = Object.keys(columns).length;
	var isScrollHorizontal = !isDepliant && nombreColonnes>limiteColonne;
	
	// Activation du datatable listeColonnesTable
	if(isDepliant){
		var optionsDepliant = {
		        "columnDefs": [{
					bVisible: true,
					aTargets: JSON.parse(colonnesAffichees)// La variable colonnesAffichees est injectee dans la JSP
		        },{
					bVisible: false,
					aTargets: ['_all'] // Toutes les colonnes non mentionnees au dessus ne sont pas visibles
		        }
		        ],
		        "aaSorting" : [[1,'asc'],[2,'asc']] // On trie sur les deux premieres colonnes sans compter la colonne contenant le +	        	
			};
		options = $.extend({},options,optionsDepliant);
	} else {
		var optionsNonDepliant = {
		        "columnDefs": [{
					bVisible: true,
					aTargets: ['_all']
		        }], // Toutes les colonnes sont visibles
		        "aaSorting" : [[0,'asc'],[1,'asc']] // On trie sur les deux premieres colonnes
			};		
		options = $.extend({},options,optionsNonDepliant);
     
     if(isScrollHorizontal){
    	 var optionsScrollHorizontal = {
    			 "footerCallback": function( tfoot, data, start, end, display ) {
    				  	$("table.table.dataTable tfoot").show();
    			 },		        
    			 "scrollX": true,
 		        "autoWidth": true
    	 };
    	 options = $.extend({},options,optionsScrollHorizontal);
     	
     }

	};
			

	var table = createDatatableParaneo("#prototype", options, isScrollHorizontal);
	
	// Si le scroll est horizontal il faut appliquer a nouveau les listener
	if(isScrollHorizontal){
	    var myDatatable = table;
		var filterInputSelector = "table.table.dataTable" + " tfoot input";
		$(filterInputSelector).keyup(function() {
			// On prend la cellule du filtre
			var myElementTD = $(this).parent();
			// On prend toutes les celulles
			var allElementTD = $(this).parent().parent().children();
			// On recupere l'index du filtre
			var indexColonne = $(allElementTD).index(myElementTD);

			// On va mettre les colonnes visibles dans ce tableau
			var colonnesVisibles = new Array();

			// On va mettre toutes les colonnes (visibles et invisibles) dans ce tableau
			var toutesColonnes = new Array();

			// On parcourt toutes les colonnes du tableau
			for ( var int = 0; int < myDatatable.fnSettings().aoColumns.length; int++) {
				// Si la colonne est visible on la met dans le tableau adequat
				if(myDatatable.fnSettings().aoColumns[int].bVisible){
					colonnesVisibles.push(myDatatable.fnSettings().aoColumns[int]);
				}

				// Toutes les colonnes vont dans ce tableau
				toutesColonnes.push(myDatatable.fnSettings().aoColumns[int]);
			}

			// On recupere l'index "reel" a partir de l'index "visuel"
			var colonneLogique = undefined;
			for ( var int = 0; int < toutesColonnes.length; int++) {
				if(toutesColonnes[int]==colonnesVisibles[indexColonne]){
					colonneLogique = int;
				}
			}

			// On passe a la fonction de filtrage le numero "reel" de la colonne
			myDatatable.fnFilter(this.value, colonneLogique);
			resizeHeight();
		});

	}

	
	$("th").first().addClass("coinArrondiHautGauche");
	$("th").eq(-2).addClass("coinArrondiHautDroite");

	// Ajout des évènements sur les boutons (
	$("table.dataTable").on('click','.editerEnregistrementButton', goToDetailsEnregistrement);
	$("table.dataTable").on('click','.supprimerEnregistrementButton', goToSupprimerEnregistrement);

	/** ** End datatable configuration ID=listeColonnesTable ** */

	// On actualise les élements du layout qui doivent être recalculés
	resizeHeight();
});


/**
 * Fonction permettant d'aller vers la page de détails d'un enregistrement.
 *
 * @returns {Boolean}
 */
function goToDetailsEnregistrement() {
	var queryString = {
		tableName : $(this).attr('data-tableName'),
		index : $(this).attr('data-index'),
		provenance : 'detailsTable'
	};
	window.location = $(this).attr('lien');

	return false;
};

/**
 * Fonction permettant de supprimer un enregistrement.
 *
 * @returns {Boolean}
 */
function goToSupprimerEnregistrement() {
	var queryString = {
		tableName : $(this).attr('data-tableName'),
		index : $(this).attr('data-index'),
		provenance : 'detailsTable'
	};
	window.location = $(this).attr('lien');
	return false;
};

