$(function() {

	/** ** Start datatable configuration ID=idTableau2 ** */
	// instanciation du datatable
	var idTableau2 = $('#idTableau2')
			.dataTable(
					{
						"bJQueryUI" : true,
						"sPaginationType" : "full_numbers",
						"sDom" : "<'row'<'span6'l><'span3'f>r>t<'row'<'span5 infoWrap'i><'span4 paginateWrap'p>>",
						"bAutoWidth" : true,
						"oLanguage" : {
							"sInfoFiltered" : '<script language="javascript">addEmptyCellShadow(true);</script>'
						},
						"aoColumnDefs" : [
						// indique les colonnes que l'on ne veut pas trier (1
						// colonne = index 0 ...)
						{
							"bSortable" : false,
							"aTargets" : [ 0, 1, 7 ]
						} ]
					});
	// instanciation des filtres de colonnes pour le datatable
	$("#idTableau2 tfoot input").keyup(function() {
		var myElementTD = $(this).parent();
		var allElementTD = $(this).parent().parent().children();
		idTableau2.fnFilter(this.value, $(allElementTD).index(myElementTD));
	});
	/** ** End datatable configuration ID=idTableau2 ** */

	////
    /************** Start datatable configuration ID=idTableauDeBord ****************/
    ////
    var idTableauDeBord = $('#idTableauDeBord').dataTable({
        "bJQueryUI": true,
        "sPaginationType": "full_numbers",
        "sDom": "<'row'<'span8' <'titleWrap'> l><'span4'f>r>t<'row'<'span9 infoWrap'i><'span4 paginateWrap'p>>",
		"oLanguage": {
			"sInfoFiltered": '<script language="javascript">addEmptyCellShadow(false);</script>'
		},
        "aoColumnDefs": [
			{"sClass": " verticalShadow ", "aTargets": [ 7 ]},
            {"bSortable": false, "aTargets": [ 0, 7]}
        ]
    });

    $("#idTableauDeBord tfoot input").keyup( function () {
    	var myElementTD=$(this).parent();
    	var allElementTD=$(this).parent().parent().children();
    	idTableauDeBord.fnFilter(this.value, $(allElementTD).index(myElementTD));
    } );
    ////
    /************** End datatable configuration ID=idTableauDeBord ****************/
    ////


	/**
	 * ** Start configuration de la validation du formulaire
	 * ID=formulaireValidation1 **
	 */
	// Personnalisation des messages d'erreur pour la validation
	$
			.extend(
					$.validator.messages,
					{
						required : "La saisie de ce champ est requise.",
						remote : 'needs to get fixed',
						email : 'L\'adresse email saisie est invalide.',
						url : 'L\'url saisie est invalide.',
						date : 'La date saisie est invalide.',
						dateISO : 'Le format de la date saisie est invalide (ISO)',
						number : 'La valeur de ce champs n\'est pas un nombre valide.',
						digits : 'Ce champs ne doit comporter que des chiffres.',
						creditcard : 'is not a valid credit card number',
						equalTo : 'is not the same value again',
						accept : 'is not a value with a valid extension',
						maxlength : jQuery.validator
								.format('Ce champs doit �tre compos� de {0} caract�res maximum.'),
						minlength : jQuery.validator
								.format('Ce champs doit comporter au moins {0} caract�res.'),
						rangelength : jQuery.validator
								.format('Ce champs doit comporter entre {0} et {1} caract�res.'),
						range : jQuery.validator
								.format('La valeur de ce champs doit �tre comprise entre {0} et {1}'),
						max : jQuery.validator
								.format('La valeur de ce champs doit �tre inf�rieure ou �gale � {0}'),
						min : jQuery.validator
								.format('La valeur de ce champs doit �tre sup�rieures � {0}')
					});
	// Activation de la validation client
	$('#monFormulaire').validate({
		rules : {
			champRequis : {
				required : true
			},
			champ2 : {
				required : true,
				email : true
			}
		},
		errorPlacement : function(error, element) {
			/* Ajout du message d'erreur dans la tooltip */
			$(element).attr('data-original-title', error.text());

		},
		highlight : function(element, errorClass, validClass) {
			/* Ajout de la class error */
			$(element).closest('.control-group').addClass(errorClass);

			/* Activation de la tooltip */
			$(element).tooltip();
		},
		unhighlight : function(element, errorClass, validClass) {
			/* Retrait de la class error */
			$(element).closest('.control-group').removeClass(errorClass);
			/*
			 * Retrait du message d'erreur de la tooltip. Par d�fault, s'il n'y
			 * a pas de message elle s'efface.
			 */
			$(element).attr('data-original-title', "");
		},
		errorClass : "error",
		validClass : "success",
		errorElement : 'label'
	});
	/**
	 * ** End configuration de la validation du formulaire
	 * ID=formulaireValidation1 **
	 */

});
