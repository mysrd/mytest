function createDatatableParaneo(tableSelector, options, isScrollHorizontal) {
	//nom de la clef qui stocke l'état du tableau en sessionStorage
	var nomCookieStateSave = 'DataTables_'+tableSelector.substring(1, tableSelector.length)+'_StateSave';

	//nom du cookie qui indique si l'utilisateur a cliqu� sur le bouton déplier tout du tableau
	var nomCookieDeplieTout = 'DataTables_'+tableSelector.substring(1, tableSelector.length)+'_DeplieTout';
	var sDomOption = "<'datatableHeaderOptions'l f>" + "t"
	+ "<'datatableFooterOptions'i p>";
	jQuery.extend( jQuery.fn.dataTableExt.oSort, {
	    "date-jjmmaaaa-pre": function ( a ) {
	        var jjmmaaaa = a.split('/');
	        return (jjmmaaaa[2] + jjmmaaaa[1] + jjmmaaaa[0]) * 1;
	    },

	    "date-jjmmaaaa-asc": function ( a, b ) {
	        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
	    },

	    "date-jjmmaaaa-desc": function ( a, b ) {
	        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
	    },
	    "nombre-monetaire-pre": function ( a ) {
	    	// On enl�ve les espaces
	    	var c = a.replace(/\s+/g, "");
	    	// On enl�ve les espaces ins�cables
	    	var d = c.replace(/(&nbsp;)/g, "");
	    	// On enl�ve toute chaine de caract�res (ex:EUR)
	    	var b = d.replace(/[A-Za-z]/g, "");
	    	// on remplace les "," par des "." pour les float
	    	var e = b.replace(',','.');

	    	return parseFloat( e );
	    },
	    "nombre-monetaire-asc": function ( a, b ) {
	    	if(isNaN(a) && isNaN(b))
	    		return 0;
	    	else if(isNaN(a))
    			return -1;
    		else if(isNaN(b))
    			return 1;
    		else
	    		return ((a < b) ? -1 : ((a > b) ? 1 : 0));

	    },

	    "nombre-monetaire-desc": function ( a, b ) {
	    	if(isNaN(a) && isNaN(b))
	    		return 0;
	    	else if(isNaN(a))
    			return 1;
    		else if(isNaN(b))
    			return -1;
    		else
    			return ((a < b) ? 1 : ((a > b) ? -1 : 0));

	    }
	} );

	var genericDataTablesOptions = {
			//sDom : sDomOption,
			"jQueryUI": false,
			"autoWidth": false,
			"stateSave": true,
			"pagingType": "full_numbers",
			"lengthChange": true,
			"lengthMenu": [[5, 10, 25],[5, 10, 25]],
			oLanguage : {
				sSearch : "_INPUT_",
				sLengthMenu : "Nombre de lignes par page : _MENU_",
				sZeroRecords : "Pas d&#39;information",
	//			sInfo :"_START_ &#224; _END_ / _TOTAL_ r&#233;sultat(s)", //d�fini dans le fnPreDrawCallback
				sInfoEmpty : " ",
				sInfoFiltered : " ",
				oPaginate : {
					sNext : " ",
					sFirst : " ",
					sLast : " ",
					sPrevious : " "
				},
				sInfoThousands:" "
			},
			"stateSaveCallback": function (settings, data) {
				/*//On met à jour l'état du tableau dans le sessionStorage
				$.cdcStorage.set(nomCookieStateSave, JSON.stringify(data),'sessionStorage');
				$.cdcStorage.set( nomCookieIsClickMenu, false,'sessionStorage' );

				//On récupére le gestionnaire de datatable
				var gestionnaireDatatables = $.cdcStorage.get( nomCookieGestionnaireDatatables,'sessionStorage' );

				//On vérifie si le cookie pour ce datatable est référencé dans le gestionnaire
				if(typeof gestionnaireDatatables === 'undefined' || !gestionnaireDatatables.hasOwnProperty(nomCookieStateSave))
				{
					//on crée une nouvelle entrée pour ce cookie
					var jsonNomCookieStateSave = {};
					jsonNomCookieStateSave[nomCookieStateSave] = "";

					//on met à jour le gestionnaire avec la nouvelle valeur
					$.cdcStorage.set( nomCookieGestionnaireDatatables,$.extend(gestionnaireDatatables,jsonNomCookieStateSave),'sessionStorage' );
				}*/
			},
			"stateLoadCallback": function (settings) {
	    		/*var gestionnaireDatatables = $.cdcStorage.get( nomCookieGestionnaireDatatables,'sessionStorage' );
	    		if(typeof gestionnaireDatatables !== 'undefined'  && gestionnaireDatatables.hasOwnProperty(nomCookieStateSave))
				{
	            	var valeurCookieIsClickMenu = $.cdcStorage.get( nomCookieIsClickMenu,'sessionStorage' );
	        		var isClickMenu = JSON.parse(valeurCookieIsClickMenu);
		    		if(!isClickMenu)
					{
		        		var dataSauvegarde = $.cdcStorage.get(nomCookieStateSave,'sessionStorage');
			        	if(dataSauvegarde != "" && dataSauvegarde != null)
			        	{
			        		var oData =  JSON.parse( dataSauvegarde );
			        		restoreFilters(tableSelector,oData);
			        		return oData;
			        	}
					}
				}*/
			},
			"rowCallback": function( row, data, index ) {
				// Code pour afficher le texte des cellules tronquées dans untooltip.
				// On ajoute un attribut title sur le TD, valorisé avec le texte du TD.
				// Le navigateur interprete l'attribut title et génére un tooltip au
				// survol ou au clique. (fonction de base des navigateurs)
				var cellules = $(row).children();
				var nbCellule = $(cellules).length;
				for ( var cptDatatable = 0, i = nbCellule; cptDatatable < i; cptDatatable++) {
					var elementTd = $(cellules.get(cptDatatable));
					var contenu = $(elementTd).html();
					var title = cleanString(contenu);
					if(title.substring(0,9) == 'Configure'){
						$(elementTd).addClass("dtSettingsItem dropdown unprintable ");
					}

					if (!$(elementTd).hasClass("checkboxRow") && !$(elementTd).hasClass("dtSettingsItem") && title != "" ) {
						$(elementTd).attr("title", title);
					}

				}




			},
			"headerCallback": function( thead, data, start, end, display ) {
				// Code pour afficher le texte des cellules tronquées dans un
				// tooltip.
				// On ajoute un attribut title sur le TH, valorisé avec le texte du
				// TH.
				// Le navigateur interprete l'attribut title et génére un tooltip au
				// survol ou au clique. (fonction de base des navigateurs)
				var cellules = $(thead).children($("th"));
				var nbCellule = $(cellules).length;
				for ( var cptDatatable = 0, i = nbCellule; cptDatatable < i; cptDatatable++) {
					var elementTd = $(cellules.get(cptDatatable));
					var contenu = $(elementTd).html();
					var title = cleanString(contenu);
					var titreCode = $(elementTd).find("span").attr("name");
					if (!$(elementTd).hasClass("checkboxRow") && !$(elementTd).hasClass("dtSettingsItem") && title != "" ) {
						$(elementTd).attr("title", title);
					}
					if(!titreCode==""){
						$(elementTd).attr("name",titreCode);
						$(elementTd).attr("title",titreCode);
					}

				}
			},
			fnPreDrawCallback : function(oSettings) {
				//On r�cup�re le nombre de ligne � afficher
				var nbLigneAffichee = oSettings.fnRecordsDisplay();

				if (nbLigneAffichee == 1) {
					//s'il n'y a qu'une ligne, on �crit r�sultat sans "S"
					oSettings.oLanguage.sInfo = "_START_ &#224; _END_ / _TOTAL_ r&#233;sultat";
				}
				else if(nbLigneAffichee > 1)
				{
					//s'il y a plus qu'une ligne, on �crit r�sultat avec un "S"
					oSettings.oLanguage.sInfo = "_START_ &#224; _END_ / _TOTAL_ r&#233;sultats";
				}

				//On r�cup�re le nombre de r�sultat
				var nbResultatTotal = oSettings.fnRecordsTotal();
                
				//S'il n'y a pas de r�sultat ou qu'il s'agit d'un tableau limit�, on cache les filtres et les elements de pagination
				if(nbResultatTotal == 0)
				{
					//On d�finit le selecteur CSS
					var selectorHeader = tableSelector+"_wrapper .datatableHeaderOptions,"+tableSelector+"_wrapper .datatableFooterOptions,"+tableSelector+"_wrapper tfoot";
					//On passe la propri�t� display � "none"
					$(selectorHeader).css("display","none");
				}

			},
			"drawCallback": function( settings ) {
				var myDatatable = this;
				// on adapte la taille du message de tableau vide pour qu'il ne prenne pas en compte la colonne d'options
				if (settings.fnRecordsDisplay() == 0) {
					var tdToRedraw = $('.' + settings.oClasses.sRowEmpty,tableSelector), tdColspan = tdToRedraw.attr('colspan');
					tdToRedraw.attr('colspan', (tdColspan > 1 ? tdColspan - 1: tdColspan));
				}

				//on déplie les lignes si le bouton de d�pliage de toutes les lignes est activé
				var flagDeplieTout = $.cdcStorage.get(nomCookieDeplieTout,'sessionStorage');
				if(flagDeplieTout == true)
				{
					if($(tableSelector+' th.expandRow .openDescr').hasClass('minus'))
					{
						// on ouvre toutes les lignes fermées
						$(tableSelector).find("tr td").each(
						function() {
							// on prepare les lignes a afficher dans le detail
							afficherLigneDeplie(myDatatable, $(this).closest("tr")[0]);
							if(!($(this).find(".openDescr").hasClass("minus")))
							{
								$(this).find(".openDescr").addClass("minus");
							}
						});
					}
					else
					{
						// on ferme toutes les lignes ouvertes
						$(tableSelector).find("tr td").each(
						function() {
							myDatatable.fnClose($(this).closest("tr")[0]);
							if(($(this).find(".openDescr").hasClass("minus")))
							{
								$(this).find(".openDescr").removeClass("minus");
							}
						});
					}
				}
				$(".roue_absente").parent().hide();			
				resizeHeight();
			}

	};
	// Ajout des autres options à la conf de base du datatable
	var datatableOptions = $.extend({}, genericDataTablesOptions, options);
	if(isScrollHorizontal){
		//La variable piedDePage est initialisee par detailsTable.jsp
		$(tableSelector).append(piedDePage);		
	}

	// Instanciation du datatable avec les options
	var myDatatable = $(tableSelector).dataTable(datatableOptions);

	if(!isScrollHorizontal){
		//La variable piedDePage est initialisee par detailsTable.jsp
		$(tableSelector).append(piedDePage);				
	}

	$("tfoot td").first().addClass("coinArrondiBasGauche");

	$("th").last().addClass("dtSettings");
	$("tfoot td").eq(-2).addClass("coinArrondiBasDroite");

	//On prend chaque ligne
	$(".roue_absente").parent().hide();


	// instanciation des filtres de colonnes pour le datatable
	var filterInputSelector = tableSelector + " tfoot input";
	$(filterInputSelector).keyup(function() {
		// On prend la cellule du filtre
		var myElementTD = $(this).parent();
		// On prend toutes les celulles
		var allElementTD = $(this).parent().parent().children();
		// On recupere l'index du filtre
		var indexColonne = $(allElementTD).index(myElementTD);

		// On va mettre les colonnes visibles dans ce tableau
		var colonnesVisibles = new Array();

		// On va mettre toutes les colonnes (visibles et invisibles) dans ce tableau
		var toutesColonnes = new Array();

		// On parcourt toutes les colonnes du tableau
		for ( var int = 0; int < myDatatable.fnSettings().aoColumns.length; int++) {
			// Si la colonne est visible on la met dans le tableau adequat
			if(myDatatable.fnSettings().aoColumns[int].bVisible){
				colonnesVisibles.push(myDatatable.fnSettings().aoColumns[int]);
			}

			// Toutes les colonnes vont dans ce tableau
			toutesColonnes.push(myDatatable.fnSettings().aoColumns[int]);
		}

		// On recupere l'index "reel" a partir de l'index "visuel"
		var colonneLogique = undefined;
		for ( var int = 0; int < toutesColonnes.length; int++) {
			if(toutesColonnes[int]==colonnesVisibles[indexColonne]){
				colonneLogique = int;
			}
		}

		// On passe a la fonction de filtrage le numero "reel" de la colonne
		myDatatable.fnFilter(this.value, colonneLogique);
		resizeHeight();
	});

	// Intégration du mot "filtre" dans l'input. Besoin de refaire appel au
	// Javascript placeholders.
	$(".dataTables_filter input").attr("placeholder", "Filtre").addClass("input-medium");
	$("tfoot tr td input").attr("placeholder", "Filtre");


	// fonction open
	$(tableSelector).delegate('span.openDescr', 'click',
		function() {
			var nTh = $(this).parents('th')[0];
			var nTr = $(this).parents('tr')[0];
			if(typeof nTh == 'undefined')
			{
				$.cdcStorage.set(nomCookieDeplieTout, false,'sessionStorage');
				if (myDatatable.fnIsOpen(nTr))
				{
					$(this).removeClass("minus");
					myDatatable.fnClose(nTr);
				}
				else
				{
					// on ajoute la classe minus pour mettre l'icone deplier
					$(this).addClass("minus");
					// on prepare les lignes a afficher dans le detail
					afficherLigneDeplie(myDatatable, nTr);

				}
			}
			else
			{
				$.cdcStorage.set(nomCookieDeplieTout, true,'sessionStorage');
				if ($(nTh).hasClass("minus"))
				{
					//On retire la classe minus au header du tableau afin de passer l'icone du - au +
					$(nTh).removeClass("minus");
					// on ferme toutes les lignes ouvertes
					$(tableSelector).find("tr").each(
					function() {
						myDatatable.fnClose(this);
						$(this).find(".openDescr").removeClass("minus");
					});
				}
				else
				{
					//On ajoute la classe minus au header du tableau afin de passer l'icone du + au -
					$(nTh).addClass("minus");

					// on ouvre toutes les lignes ferm�es
					$(tableSelector).find("tr").each(
					function() {
						if(this.innerText != null && this.innerText != "") {
							// on prepare les lignes a afficher dans le detail
							afficherLigneDeplie(myDatatable, this);

							$(this).find(".openDescr").addClass("minus");
						}
					});
				}
			}
			resizeHeight();
		}
	);
	return myDatatable;
}


/**
 *Fonction qui construit la ligne à déplier
 */
function afficherLigneDeplieParaneo(myDatatable, ligne)
{
	// on prepare les lignes a afficher dans le detail
	var aData = myDatatable.fnGetData(ligne);
	var oSettings = myDatatable.fnSettings();
	var detailRowRender = '<div class="row innerDetails form-horizontal"><div class="span8">';

	$(aData).each(
		function(index, value) {
			if (oSettings.aoColumns[index].bVisible === false) {
				var columnName = oSettings.aoColumns[index].sTitle;
				var codeColonne = oSettings.aoColumns[index].sName;


				// Le cas o� le champs � afficher est un champ de saisie ou une liste d�roulante
				if(value.indexOf("<input") >=0 || value.indexOf("<select") >=0){
					var mandatory = '';
					if(value.indexOf("require") >=0){
						mandatory = ' mandatory rouge';
					}
					detailRowRender = detailRowRender
					+ '<div class="row"><div class="span8 control-group'+mandatory+'"><label class="control-label">'
					+ columnName
					+ ' :</label><div class="controls">'
					+ value
					+ '</div></div></div>';
				} else {
					var values = value.split("<br>");
					if(columnName.trim().length != 00)
					{
						detailRowRender = detailRowRender
						+ '<div class="row"><div class="span8 control-group"><label class="control-label" name="'+codeColonne+'">'
						+ columnName
						+ ' :</label><div class="controls"><p title="'
						+ value.trim()
						+'">'
						+ value
						+ '</p></div></div></div>';
					}
					else if(columnName.trim().length == 0)
					{
						var concatenationValue = "";
						$.each(values,function(index,value){
							concatenationValue = concatenationValue
							+ '<p class="infoComplement" title="'
							+ value.trim()
							+ '">'
							+ value
							+ '</p>';
						});
						detailRowRender = detailRowRender
						+ '<div class="row"><div class="span8 control-group">'
						+ concatenationValue
						+ '</div></div>';
					}
				}
			}
		}
	);
	detailRowRender = detailRowRender + '</div></div>';
	//var nDetailsRow = myDatatable.fnOpen(ligne, detailRowRender, "info_row");
	var nDetailsRow = myDatatable.api().row(ligne.rowindex).child(detailRowRender, "info_row").show();
//	$('div.innerDetails', nDetailsRow).show(0,
//		function() {
//			resizeHeight();
//		}
//	);
	return this;
}



