package acceptation;


import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@Profile("acceptation")
public class ConfigurationAcceptation {

	/**
	 * Base de donnees
	 */
	@Bean(name="paraneoDatasource")
	@Conditional(EnvironnementLocalCondition.class)
	public DataSource getParaneoDatasourceLocal(){
		DriverManagerDataSource driver = new DriverManagerDataSource();
		driver.setUrl("jdbc:mysql://localhost:3306/paraneo");
		driver.setDriverClassName("com.mysql.jdbc.Driver");
		driver.setUsername("root");
		driver.setPassword("");
		return driver;
	}

	@Bean(name="paraneoDatasource")
	@Conditional(EnvironnementIntegrationCondition.class)
	public DataSource getParaneoDatasourceIntegration(){
		DriverManagerDataSource driver = new DriverManagerDataSource();
		driver.setUrl("jdbc:mysql://dlsgbddevi2001:6459/paraneo");
		driver.setDriverClassName("com.mysql.jdbc.Driver");
		driver.setUsername("admparaneo");
		driver.setPassword("admparaneo");
		return driver;
	}

	/**
	 * URL de l'IHM
	 */
	@Bean(name="url")
	@Conditional(EnvironnementLocalCondition.class)
	public String getUrlLocal(){
		return "http://localhost:8080/paraneo-web/web/login";
	}

	@Bean(name="url")
	@Conditional(EnvironnementIntegrationCondition.class)
	public String getUrlIntegration(){
		return "http://dlj2eedevi2003:10100/paraneo/web/login";
	}

	/**
	 * Login
	 */
	@Bean(name="login")
	@Conditional(EnvironnementLocalCondition.class)
	public String getLoginLocal(){
		return "aparaneo";
	}

	@Bean(name="login")
	@Conditional(EnvironnementIntegrationCondition.class)
	public String getLoginIntegration(){
		return "aparaneo";
	}

	/**
	 * Mot de passe
	 */
	@Bean(name="password")
	@Conditional(EnvironnementLocalCondition.class)
	public String getPasswordLocal(){
		return "password";
	}

	@Bean(name="password")
	@Conditional(EnvironnementIntegrationCondition.class)
	public String getPasswordIntegration(){
		return "password";
	}

	/**
	 * Binaires PhantomJS
	 */
	@Bean(name="binaires")
	@Conditional(EnvironnementLocalCondition.class)
	public String getBinairesLocal(){
		return "C:\\Local\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe";
	}

	@Bean(name="binaires")
	@Conditional(EnvironnementIntegrationCondition.class)
	public String getBinairesIntegration(){
		return "/dn-jenkins/product/phantomjs";
		//return "/dn-continuum-agent/ntiers/ma1/ext/bin/phantomjs";
	}

	@Bean(name="environnement")
	@Conditional(EnvironnementLocalCondition.class)
	public String getOSEnvironnementLocal(){
		return "WINDOWS";

	}

	@Bean(name="environnement")
	@Conditional(EnvironnementIntegrationCondition.class)
	public String getOSEnvironnementIntegration(){
		return "UNIX";

	}




}
