package acceptation;

import java.util.concurrent.TimeUnit;

import org.junit.runner.RunWith;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;

import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSetTestExecutionListener;
@RunWith(ConcordionSpringJunit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {ConfigurationAcceptation.class})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
						 DataSetTestExecutionListener.class})
@ActiveProfiles(profiles={"acceptation"})
public class AbstractFixture {

	protected WebDriver driver;

	@Autowired
	String environnement;
	@Autowired
	private String login;
	@Autowired
	private String password;
	@Autowired
	private String url;
	@Autowired
	private String binaires;

    protected LoginPage initialisationSelenium() {
    	//System.out.println("Répertoire de sortie par défaut : "+System.getProperty("concordion.output.dir"));
		System.setProperty("phantomjs.binary.path", binaires);
		System.setProperty("webdriver.firefox.bin","C:\\Local\\FirefoxPortable\\FirefoxPortable.exe");
		System.setProperty("webdriver.ie.driver", "C:\\Local\\IEDriverServer.exe");
		driver = DriverSingleton.getInstance().getDriver();
		//driver = new FirefoxDriver();
		//DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		//caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		//driver = new InternetExplorerDriver(caps);
		//Si on ne change pas la taille de la fenêtre des éléments ne sont pas pris en compte car pas visibles
		driver.manage().window().setSize(new Dimension(1920,1080));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.get(url);

		LoginPage page =  PageFactory.initElements(driver, LoginPage.class);
		page.login = login;
		page.password = password;
		return page;
	}


    /**
     * @deprecated
     * Inutile maintenant que la gestion du driver est geree par le RunListener
     * @see PhantomJSRunListener#testRunFinished(org.junit.runner.Result)
     *
     */
    @Deprecated
	protected void fermetureSelenium(){
    }

}
