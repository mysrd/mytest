package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay930plus.xml")

public class Lmtay930plusFixture extends AbstractFixture {


    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
    											   String valeur1, String valeur2, String valeur3, String valeur4, String valeur5) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_economique_lmtay930");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByYtoptr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByYtopta");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
				this.fermetureSelenium();
				throw e;
    	}
}



    public Tuyau  insertionCasValeursIncompatiblesEntreElles(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
			   String valeur1, String valeur2, String valeur3, String valeur4, String valeur5) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_economique_lmtay930");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taFamilleDeCatgEcoAnalyseLmtay530");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByYtoptr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByYtopta");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
}


    public Tuyau  creationRechercheValeurCloseListeDeroulante(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_economique_lmtay930");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur3,"taFamilleDeCatgEcoAnalyseLmtay530");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau modificationRechercheValeurCloseDorigineListeDeroulante(String champclef, String champamodifier, String champamodifierbis, String valeurclef, String valeurnouvelle, String valeurdorigine){
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeurclef);
	  		editerEnregistrement.selectionnerValeurListeDéroulante(valeurnouvelle,"taFamilleDeCatgEcoAnalyseLmtay530");
			boolean estPresent = editerEnregistrement.verifierPresenceValeurListeDeroulante(valeurdorigine,"taFamilleDeCatgEcoAnalyseLmtay530");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur est absente de la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau modificationRechercheValeurCloseListeDeroulante(String champclef, String champamodifier,  String valeurclef, String valeurnouvelle ){
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeurclef);
			boolean estPresent = editerEnregistrement.verifierPresenceValeurListeDeroulante(valeurnouvelle,"taFamilleDeCatgEcoAnalyseLmtay530");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }



    public Tuyau  modificationCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String valeur1, String valeur2) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.enregistrerBloquant();
		    boolean estEnAnomalie = true;
			estEnAnomalie = editerEnregistrement.selectionnerChampEnAnomalie(champ2);
		 	this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
			String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taFamilleDeCatgEcoAnalyseLmtay530");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByYtoptr");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByYtopta");
			editerEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
    	} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
}

    public Tuyau  modificationCasChangementYTOPTASeul(String champ1, String champ2, String valeur1, String valeur2 ) {
    	try {
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taChoixOuiNonByYtopta");
	 		accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
			String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, int valeur6JJ, String valeur6MM, String valeur6SSAA,String valeur1bis) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_economique_lmtay930");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taFamilleDeCatgEcoAnalyseLmtay530");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByYtoptr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByYtopta");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_economique_lmtay930");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1bis);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public boolean enAnomalie;

	}
}
