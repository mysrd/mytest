package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay501plus.xml")

public class Lmtay501plusFixture extends AbstractFixture {


    public Tuyau insertionCasErreurValeurEnDoubleCpay(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			String champ11, String champ12,	String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20,
			String valeur1, String valeur5, String valeur7, String valeur8, String valeur9, String valeur10,
			String valeur11, String valeur12, String valeur13, int valeur14JJ, String valeur14MM, String valeur14SSAA,
			String valeur16, String valeur17, String valeur18, String valeur19) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ5, valeur5);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.remplirChamp(champ9, valeur9);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodeResidentLmtay554");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taRgrpPaysARisqueDeContrepaLmtay928");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taZoneGeographiquePrRatiosReLmtay948");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur12,"taChoixOuiNonByCefisp");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taChoixOuiNonByTopue");
			insererEnregistrement.selectionnerDate(valeur14JJ, valeur14MM, valeur14SSAA, "yddeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taChoixOuiNonByYtsepa");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByYtpeee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taChoixOuiNonByEurold");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taChoixOuiNonByYnlfce");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();

	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau creationRechercheValeurCloseListeDeroulanteLmtay928(String champ1,String valeur1) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur1,"taRgrpPaysARisqueDeContrepaLmtay928");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau creationRechercheValeurCloseListeDeroulanteLmtay948(String champ1,String valeur1) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur1,"taZoneGeographiquePrRatiosReLmtay948");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau insertionCasNominalAvecMajToutesDates(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
													 String champ11, String champ12,	String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20,
													 String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10,
													 String valeur11, String valeur12, String valeur13, int valeur14JJ, String valeur14MM, String valeur14SSAA, int valeur15JJ, String valeur15MM, String valeur15SSAA,
													 String valeur16, String valeur17, String valeur18, String valeur19, int valeur20JJ, String valeur20MM, String valeur20SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.remplirChamp(champ5, valeur5);
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.remplirChamp(champ9, valeur9);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodeResidentLmtay554");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taRgrpPaysARisqueDeContrepaLmtay928");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taZoneGeographiquePrRatiosReLmtay948");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur12,"taChoixOuiNonByCefisp");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taChoixOuiNonByTopue");
			insererEnregistrement.selectionnerDate(valeur14JJ, valeur14MM, valeur14SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "ydfeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taChoixOuiNonByYtsepa");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByYtpeee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taChoixOuiNonByEurold");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taChoixOuiNonByYnlfce");
			insererEnregistrement.selectionnerDate(valeur20JJ, valeur20MM, valeur20SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_pays_lmtay501");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			t.champ19 = donnees.get(champ19);
			t.champ20 = donnees.get(champ20);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }

    public Tuyau insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
											  String champ11, String champ12,	String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20,
											  String valeur1, String valeur5, String valeur7, String valeur8, String valeur9, String valeur10,
											  String valeur11, String valeur12, String valeur13, int valeur14JJ, String valeur14MM, String valeur14SSAA,
											  String valeur16, String valeur17, String valeur18, String valeur19) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ5, valeur5);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodeResidentLmtay554");
			insererEnregistrement.remplirChamp(champ9, valeur9);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taRgrpPaysARisqueDeContrepaLmtay928");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taZoneGeographiquePrRatiosReLmtay948");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur12,"taChoixOuiNonByCefisp");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taChoixOuiNonByTopue");
			insererEnregistrement.selectionnerDate(valeur14JJ, valeur14MM, valeur14SSAA, "yddeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taChoixOuiNonByYtsepa");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByYtpeee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taChoixOuiNonByEurold");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taChoixOuiNonByYnlfce");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();

	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}




    public Tuyau insertionCasSaisieIncorrecte(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			  								  String champ11, String champ12,	String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20,
			  								  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10,
			  								  String valeur11, String valeur12, String valeur13, int valeur14JJ, String valeur14MM, String valeur14SSAA,
			  								  String valeur16, String valeur17, String valeur18, String valeur19) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.remplirChamp(champ5, valeur5);
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.remplirChamp(champ7, valeur7);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taCodeResidentLmtay554");
			insererEnregistrement.remplirChamp(champ9, valeur9);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taRgrpPaysARisqueDeContrepaLmtay928");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taZoneGeographiquePrRatiosReLmtay948");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur12,"taChoixOuiNonByCefisp");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taChoixOuiNonByTopue");
			insererEnregistrement.selectionnerDate(valeur14JJ, valeur14MM, valeur14SSAA, "yddeff");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taChoixOuiNonByYtsepa");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByYtpeee");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taChoixOuiNonByEurold");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taChoixOuiNonByYnlfce");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau insertionCasNominalAvecMajDateDebutEffetSeule(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
    													   String champ11, String champ12,	String champ13, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20,
			 										       String valeur1, String valeur1maj, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7,
			 										       int valeur15JJ, String valeur15MM, String valeur15SSAA) {
    		try{
				LoginPage loginPage = initialisationSelenium();
				AccueilPage accueil = loginPage.login("admin", "password");
				ListeTablesPage listeTables = accueil.voirListeTables();
				InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_pays_lmtay501");
				insererEnregistrement.remplirChamp(champ1, valeur1);
				insererEnregistrement.remplirChamp(champ2, valeur2);
				insererEnregistrement.remplirChamp(champ3, valeur3);
				insererEnregistrement.remplirChamp(champ4, valeur4);
				insererEnregistrement.remplirChamp(champ5, valeur5);
				insererEnregistrement.remplirChamp(champ6, valeur6);
				insererEnregistrement.remplirChamp(champ7, valeur7);
				insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "ydfeff");
				listeTables = insererEnregistrement.enregistrer();
				DetailsTablePage detailsTable = listeTables.consultation("ta_pays_lmtay501");
				Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1maj);

				this.fermetureSelenium();
				Tuyau t = new Tuyau();
				t.champ1 = donnees.get(champ1);
				t.champ2 = donnees.get(champ2);
				t.champ3 = donnees.get(champ3);
				t.champ4 = donnees.get(champ4);
				t.champ5 = donnees.get(champ5);
				t.champ6 = donnees.get(champ6);
				t.champ7 = donnees.get(champ7);
				t.champ8 = donnees.get(champ8);
				t.champ9 = donnees.get(champ9);
				t.champ10 = donnees.get(champ10);
				t.champ11 = donnees.get(champ11);
				t.champ12 = donnees.get(champ12);
				t.champ13 = donnees.get(champ13);
				t.champ15 = donnees.get(champ15);
				t.champ16 = donnees.get(champ16);
				t.champ17 = donnees.get(champ17);
				t.champ18 = donnees.get(champ18);
				t.champ19 = donnees.get(champ19);
				t.champ20 = donnees.get(champ20);
				return t;
    		} catch (Exception e){
    			this.fermetureSelenium();
    			throw e;
    		}
    }


    public Tuyau modificationCasNominalSansMajDates(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10,
			  									    String champ11, String champ12,	String champ13, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20,
			  									    String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7) {
    	try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_pays_lmtay501");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.remplirChamp(champ3, valeur3);
			editerEnregistrement.remplirChamp(champ4, valeur4);
			editerEnregistrement.remplirChamp(champ5, valeur5);
			editerEnregistrement.remplirChamp(champ6, valeur6);
			editerEnregistrement.remplirChamp(champ7, valeur7);
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_pays_lmtay501");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			t.champ19 = donnees.get(champ19);
			t.champ20 = donnees.get(champ20);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }

public class Tuyau {
	public String champ1;
	public String champ2;
	public String champ3;
	public String champ4;
	public String champ5;
	public String champ6;
	public String champ7;
	public String champ8;
	public String champ9;
	public String champ10;
	public String champ11;
	public String champ12;
	public String champ13;
	public String champ14;
	public String champ15;
	public String champ16;
	public String champ17;
	public String champ18;
	public String champ19;
	public String champ20;
	public boolean enAnomalie;

}
}
