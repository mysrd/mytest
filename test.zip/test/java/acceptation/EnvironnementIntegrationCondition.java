package acceptation;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class EnvironnementIntegrationCondition implements Condition {

	@Override
	public boolean matches(ConditionContext context,AnnotatedTypeMetadata metadata) {
			String os = System.getProperty("os.name");
			if (os.toUpperCase().indexOf("WINDOWS") > -1) {
				return false;
			}
			return true;
	}

}
