package acceptation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Map;

import org.concordion.api.FailFast;

import com.excilys.ebi.spring.dbunit.test.DataSet;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;
import acceptation.page.TraitementHexapostePage;



@FailFast
@DataSet(value ="dataset/jeudetest_hexaposte.xml")
public class HexaposteFixture extends AbstractFixture{

	public class Tuyau {
		public String champ;
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public String champ10;
		public String champ11;
		public String champ12;
		public String champ13;
		public String champ14;
		public String champ15;
		public String champ16;
		public boolean testDate1;
		public boolean testDate2;
		public boolean testDate3;
		public boolean testDate4;

	}

	private String obtenirProperty(String clef){
		ResourceBundle bundle = ResourceBundle.getBundle("messages",Locale.FRENCH);
		return bundle.getString(clef);
	}

	public Tuyau envoiFichierCorrect(){
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			TraitementHexapostePage traitementHexaposte = accueil.voirTraitementHexaposte();
			String message = traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_DOUBLONNAGE);
			System.out.println(message);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(message.equals(obtenirProperty("paraneo.hexaposte.succes")) ){
				t.champ="intégré.";
			} else {
				t.champ ="en erreur.";
			}
			return t;
		} catch (Exception e){
 			throw e;
		}

	}

    public Tuyau  consultationCodePostalCree	(String valeur1, String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8
    											,String champ9, String champ10, String champ11, String champ12, String champ13, String champ14, String champ15, String champ16) throws ParseException {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_postal");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ12);
			Date dateCreation = sdf.parse(t.champ14);
			Date dateDerniereMaj = sdf.parse(t.champ15);
			t.testDate1 = dateCreation.equals(dateDebutEffet);
			t.testDate2 = dateCreation.equals(dateDerniereMaj);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau  consultationCodePostalClos	(String valeur1, String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8
			,String champ9, String champ10, String champ11, String champ12, String champ13, String champ14, String champ15, String champ16) throws ParseException {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_postal");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ12);
			Date dateFinEffet = sdf.parse(t.champ13);
			Date dateCreation = sdf.parse(t.champ14);
			Date dateDerniereMaj = sdf.parse(t.champ15);
			Date dateCloture = sdf.parse(t.champ16);
			t.testDate1 = dateFinEffet.after(dateDebutEffet);
			t.testDate2 = dateFinEffet.after(dateCreation);
			t.testDate3 = dateFinEffet.equals(dateDerniereMaj);
			t.testDate4 = dateFinEffet.before(dateCloture);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau  consultationCodePostalNonModifie	(String valeur1, String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8
			,String champ9, String champ10, String champ11, String champ12, String champ13, String champ14, String champ15, String champ16) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_postal");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }

    public Tuyau  consultationCodePostalModifie	(String valeur1, String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8
			,String champ9, String champ10, String champ11, String champ12, String champ13, String champ14, String champ15, String champ16) throws ParseException {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_postal");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateCreation = sdf.parse(t.champ14);
			Date dateDerniereMaj = sdf.parse(t.champ15);
			t.testDate1 = dateDerniereMaj.after(dateCreation);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }

    public Tuyau  consultationCodePostalReouvert(String valeur1, String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8
			,String champ9, String champ10, String champ11, String champ12, String champ13, String champ14, String champ15, String champ16) throws ParseException {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_code_postal");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date dateDebutEffet = sdf.parse(t.champ12);
			Date dateCreation = sdf.parse(t.champ14);
			Date dateDerniereMaj = sdf.parse(t.champ15);
			Date dateCloture = sdf.parse(t.champ16);
			t.testDate1 = dateDebutEffet.equals(dateDerniereMaj);
			t.testDate2 = dateDebutEffet.after(dateCreation);
			t.testDate3 = dateDebutEffet.before(dateCloture);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


	public Tuyau envoiFichierVide(){
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			TraitementHexapostePage traitementHexaposte = accueil.voirTraitementHexaposte();
			String message = traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_VIDE);
			System.out.println(message);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(message.equals(obtenirProperty("paraneo.hexaposte.erreur.fichiervide")) ){
				t.champ="bloquante.";
			} else {
				t.champ ="non bloquante.";
			}
			return t;
		} catch (Exception e){
 			throw e;
		}

	}

	public Tuyau envoiFichierMauvaiseExtension(){
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			TraitementHexapostePage traitementHexaposte = accueil.voirTraitementHexaposte();
			String message = traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_MAUVAISE_EXTENSION);
			System.out.println(message);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(message.equals(obtenirProperty("paraneo.hexaposte.erreur.mauvaiseextension")) ){
				t.champ="bloquante.";
			} else {
				t.champ ="non bloquante.";
			}
			return t;
		} catch (Exception e){
 			throw e;
		}

	}

	public Tuyau envoiFichierTropPeuDeLignes(){
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			TraitementHexapostePage traitementHexaposte = accueil.voirTraitementHexaposte();
			String message = traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_TROP_PEU_DE_LIGNES);
			System.out.println(message);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(message.equals(obtenirProperty("paraneo.hexaposte.erreur.fichiervide")) ){
				t.champ="bloquante.";
			} else {
				t.champ ="non bloquante.";
			}
			return t;
		} catch (Exception e){
 			throw e;
		}

	}


	public Tuyau envoiFichierEnDouble(){
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			TraitementHexapostePage traitementHexaposte = accueil.voirTraitementHexaposte();
			traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_1);
			String message = traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_DOUBLONNAGE);
			System.out.println(message);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(message.equals(obtenirProperty("paraneo.hexaposte.erreur.empreinte")) ){
				t.champ="bloquante.";
			} else {
				t.champ ="non bloquante.";
			}
			return t;
		} catch (Exception e){
 			throw e;
		}

	}


	public Tuyau envoiFichierTraitementEnCours(){
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			TraitementHexapostePage traitementHexaposte = accueil.voirTraitementHexaposte();
			traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_1);
			String message = traitementHexaposte.envoyerFichier(TraitementHexapostePage.FICHIER_2);
			System.out.println(message);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(message.equals(obtenirProperty("paraneo.hexaposte.erreur.traitementencours")) ){
				t.champ="bloquante.";
			} else {
				t.champ ="non bloquante.";
			}
			return t;
		} catch (Exception e){
 			throw e;
		}

	}
}
