package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay934plus.xml")

public class Lmtay934plusFixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3,
    											String valeur1, String valeur2, int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_famille_fiscale_lmtay934");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_famille_fiscale_lmtay934");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  insertionCasSaisieInvalide(String champ1, String champ2, String champ3,
    										   String valeur1, String valeur2, int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_famille_fiscale_lmtay934");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
				this.fermetureSelenium();
				throw e;
    	}
}


    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3,
    												String valeur1, String valeur2, int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_famille_fiscale_lmtay934");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_famille_fiscale_lmtay934");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			return t;
    	} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
}


    public Tuyau modificationCasZoneObligatoireNonSaisie(String champ1, String champ2, String valeur1, String valeur2) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_famille_fiscale_lmtay934");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }




	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public boolean enAnomalie;

	}
}
