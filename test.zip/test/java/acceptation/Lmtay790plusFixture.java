package acceptation;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay790.xml")
@FailFast
public class Lmtay790plusFixture extends AbstractFixture {

    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
 		try {
	    	LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
	 		insererEnregistrement.remplirChamp(champ1, valeur1);
	 		insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante";
	 		} else {
	 			t.champ1 ="non bloquante";
	 		}
	 		t.enAnomalie = estEnAnomalie;

	 		return t;
			} catch(Exception e){
				fermetureSelenium();
				throw e;
			}
	    }

    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public boolean enAnomalie;
    	}
}
