package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay532plus.xml")

public class Lmtay532plusFixture extends AbstractFixture {

    public Tuyau insertionCasNominalSansMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
    											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_etat_du_client_lmtay532");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByC0acr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCvecl");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_etat_du_client_lmtay532");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau insertionCasSaisieCaractereNonAutorise(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
			  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_etat_du_client_lmtay532");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByC0acr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCvecl");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau  modificationCasNominalSansMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
				String valeur1, String valeur2, String valeur3, String valeur4, String valeur5) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_etat_du_client_lmtay532");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.remplirChamp(champ3, valeur3);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByC0acr");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCvecl");
			ListeTablesPage listeTables2 = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable2 = listeTables2.consultation("ta_etat_du_client_lmtay532");
			Map<String,String> donnees = detailsTable2.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau modificationCasZoneObligatoireNonSaisie(String champ1, String champ2, String valeur1, String valeur2) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_etat_du_client_lmtay532");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			estEnAnomalie= editerEnregistrement.selectionnerChampEnAnomalie(champ2);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }



    public Tuyau modificationCasSaisieCaractereNonAutorise(String champ1, String champ2, String valeur1, String valeur2) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_etat_du_client_lmtay532");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }








    public Tuyau insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
											  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_etat_du_client_lmtay532");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByC0acr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCvecl");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
			  										String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		DetailsTablePage consulterTable = listeTables.consultation("ta_etat_du_client_lmtay532");
    		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
    		editerEnregistrement.remplirChamp(champ2, valeur2);
    		editerEnregistrement.remplirChamp(champ3, valeur3);
    		editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByC0acr");
    		editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCvecl");
    		editerEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
    		ListeTablesPage listeTables2 = editerEnregistrement.enregistrer();
    		DetailsTablePage detailsTable2 = listeTables2.consultation("ta_etat_du_client_lmtay532");
    		Map<String,String> donnees = detailsTable2.obtenirDonneesParIdentifiant(valeur1);
    		this.fermetureSelenium();
    		Tuyau t = new Tuyau();
    		t.champ1 = donnees.get(champ1);
    		t.champ2 = donnees.get(champ2);
    		t.champ3 = donnees.get(champ3);
    		t.champ4 = donnees.get(champ4);
    		t.champ5 = donnees.get(champ5);
    		t.champ6 = donnees.get(champ6);
    		return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau  modificationCasSaisieTropLongue(String champ1, String champ2,
												  String valeur1, String valeur2) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_etat_du_client_lmtay532");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
			t.champ1="bloquante.";
			} else {
			t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
												String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, int valeur6JJ, String valeur6MM, String valeur6SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_etat_du_client_lmtay532");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByC0acr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCvecl");
			insererEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public boolean enAnomalie;

	}
}
