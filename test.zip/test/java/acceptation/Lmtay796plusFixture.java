package acceptation;
import java.util.Map;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay796.xml")
@FailFast
public class Lmtay796plusFixture extends AbstractFixture {

    public Tuyau  insertionCasErreurCaractereInterdit(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String valeur1, String valeur2, String valeur3, String valeur4, String valeur5) {
		try {
			LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_codification_des_tiers_lmtay796");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taChoixOuiNon");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taLongueurTypeCodifTiers");
			insererEnregistrement.remplirChamp(champ5, valeur5);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau  insertionCasNominalSansMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String valeur1, String valeur2, String valeur3, String valeur4, String valeur5) {
		try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_codification_des_tiers_lmtay796");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taChoixOuiNon");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taLongueurTypeCodifTiers");
			insererEnregistrement.remplirChamp(champ5, valeur5);
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_type_codification_des_tiers_lmtay796");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public boolean enAnomalie;

	}
}
