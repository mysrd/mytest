package acceptation;

import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.RunListener;

public class PhantomJSRunListener extends RunListener {

	@Override
	public void testRunStarted(Description description) throws Exception {
		super.testRunStarted(description);
		System.out.println("Lancement du runlistener");
	}


	@Override
	public void testRunFinished(Result result) throws Exception {
		super.testRunFinished(result);
		// On ferme le driver une fois les tests termines
		DriverSingleton.getInstance().closeDriver();
		System.out.println("Fin du runlistener");
	}
}
