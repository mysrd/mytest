package acceptation;

import java.util.Map;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_table_des_tables.xml")
@FailFast
public class TableDesTablesplusFixture extends AbstractFixture {

    public Tuyau  consultation(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String valeur1) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_table_des_tables");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau  insertionCasNominalAvecMajTroisDates(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2,
														int valeur1JJ, String valeur1MM, String valeur1SSAA,
														int valeur2JJ, String valeur2MM, String valeur2SSAA,
														int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try {
    			LoginPage loginPage = initialisationSelenium();
    			AccueilPage accueil = loginPage.login("admin", "password");
    			ListeTablesPage listeTables = accueil.voirListeTables();
    			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_code_editique_lmtay403");
    			insererEnregistrement.remplirChamp(champ1, valeur1);
    			insererEnregistrement.remplirChamp(champ2, valeur2);
    			insererEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
    			insererEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
    			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
    			listeTables = insererEnregistrement.enregistrer();
    			DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
    			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
    			this.fermetureSelenium();
    			Tuyau t = new Tuyau();
    			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
    			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
    			t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
    			t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
    			t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture

    			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau modificationCasNominalAvecMajTroisDates(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2,
														 int valeur1JJ, String valeur1MM, String valeur1SSAA,
														 int valeur2JJ, String valeur2MM, String valeur2SSAA,
														 int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try {
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
    		DetailsTablePage consulterTable = listeTables.consultation("ta_code_editique_lmtay403");
    		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
    		editerEnregistrement.remplirChamp(champ2, valeur2);
    		editerEnregistrement.selectionnerDate(valeur1JJ, valeur1MM, valeur1SSAA, "yddeff");
    		editerEnregistrement.selectionnerDate(valeur2JJ, valeur2MM, valeur2SSAA, "ydfeff");
    		editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
    		listeTables = editerEnregistrement.enregistrer();
    		DetailsTablePage detailsTable = listeTables.consultation("ta_code_editique_lmtay403");
    		Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
    		this.fermetureSelenium();
    		Tuyau t = new Tuyau();
    		t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
    		t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
    		t.champ4 = donnees.get(champ4);         //YDDEFF date de début d'effet
    		t.champ5 = donnees.get(champ5);         //YDFEFF date de fin d'effet
    		t.champ6 = donnees.get(champ6);         //YDCLOT date de cloture
    		return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau modification(String champ1, String champ2, String champ3, String champ6, String champ7, String valeur1, String valeur2,int valeur3JJ, String valeur3MM, String valeur3SSAA) {
    	try {
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_table_des_tables");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_table_des_tables");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);         //CDEDIT CODE EDITIQUE
			t.champ2 = donnees.get(champ2);         //LBEDIT LIBELLE CODE EDITIQUE
			t.champ3 = donnees.get(champ3);         //YDDEFF date de début d'effet
			t.champ6 = donnees.get(champ6);         //YDFEFF date de fin d'effet
			t.champ7 = donnees.get(champ7);         //YDCLOT date de cloture
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
	}

}
