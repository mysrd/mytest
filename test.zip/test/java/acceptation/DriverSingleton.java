package acceptation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DriverSingleton{

	private static WebDriver driver;

	private DriverSingleton(){
		DesiredCapabilities dcaps = new DesiredCapabilities();
		dcaps.setCapability("takesScreenshot", true);
		driver = new PhantomJSDriver(dcaps); 
	}
	
	
	public WebDriver getDriver(){
		return driver;
	}

	public void closeDriver(){
		driver.close();
		driver.quit();
	}
	/** Instance unique pré-initialisée */
	private static DriverSingleton INSTANCE = new DriverSingleton();

	/** Point d'accès pour l'instance unique du singleton */
	public static DriverSingleton getInstance()	{
		return INSTANCE;
	}

	public static void tearDown() throws Exception {
		driver.quit();
	}


}