package acceptation;


import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay400.xml")
public class Lmtay400plusFixture extends AbstractFixture {



    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ4, String champ5, String champ6, String valeur1, String valeur2 ) {
 		try {
	    	LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_profil_titulaire_lmtay400");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}



    public Tuyau  modificationCasCaractereNonAutorise(String champ1, String champ2, String valeur1, String valeur2 ) {
    	try {
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		DetailsTablePage consulterTable = listeTables.consultation("ta_profil_titulaire_lmtay400");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = editerEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}


	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public boolean enAnomalie;
		public boolean testDate1;
		public boolean testDate2;
		public boolean testDate3;
		public boolean testDate4;
		public boolean testDate5;
		public boolean testDate6;
		public boolean testDate7;

	}
}
