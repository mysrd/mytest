package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay523.xml")

public class Lmtay523plusFixture extends AbstractFixture {



    public Tuyau insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
											String champ12,
											String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
											String champ22,
											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
											int valeur12JJ, String valeur12MM, String valeur12SSAA,
											String valeur13, String valeur14, String valeur15, String valeur16, String valeur17, String valeur18, String valeur19, String valeur20, String valeur21,
											int valeur22JJ, String valeur22MM, String valeur22SSAA) {
    	try{
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_client_lmtay523");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taNomenclatureDeClienteleLmtay774");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taModeDeGestionClientsLmtay831");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taRgptCategorieClienteleComptLmtay947");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			insererEnregistrement.remplirChamp(champ15, valeur15);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taProfilTitulaireLmtay400");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taTypeFiliereLmtay401");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur20,"taListeOpcvmLmtay402");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur21,"taChoixOuiNonByYtnopc");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}





	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public String champ10;
		public String champ11;
		public String champ12;
		public String champ13;
		public String champ14;
		public String champ15;
		public String champ16;
		public String champ17;
		public String champ18;
		public String champ19;
		public String champ20;
		public String champ21;
		public String champ22;
		public boolean enAnomalie;

	}
}
