package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay890plus.xml")

public class Lmtay890plusFixture extends AbstractFixture {

    public Tuyau insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
    											String champ12, String champ13, String champ14, String champ15, String champ16, String champ17,
    											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
    											String valeur12, String valeur13, int valeur14JJ, String valeur14MM, String valeur14SSAA, int valeur15JJ, String valeur15MM, String valeur15SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_complement_structure_banq_lmtay890");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.remplirChamp(champ4, valeur4);
			insererEnregistrement.remplirChamp(champ5, valeur5);
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taLieuDeCompensationLmtay891");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taTerritorialiteFicobaLmtay508");
			insererEnregistrement.remplirChamp(champ9, valeur9);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taTopSiegeReseau");
			insererEnregistrement.remplirChamp(champ11, valeur11);
			insererEnregistrement.remplirChamp(champ12, valeur12);
			insererEnregistrement.remplirChamp(champ13, valeur13);
			insererEnregistrement.selectionnerDate(valeur14JJ, valeur14MM, valeur14SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur15JJ, valeur15MM, valeur15SSAA, "ydfeff");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}


	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public String champ10;
		public String champ11;
		public String champ12;
		public String champ13;
		public String champ14;
		public String champ15;
		public String champ16;
		public String champ17;
		public boolean enAnomalie;

	}
}
