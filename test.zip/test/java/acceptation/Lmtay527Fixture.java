package acceptation;
import java.util.Map;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@DataSet(value ="dataset/jeudetest_lmtay527.xml")
@FailFast
public class Lmtay527Fixture extends AbstractFixture {

    public Tuyau  insertionCasNominal(String champ1, String champ2, String champ3,String valeur1, String valeur2) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_qualite_normal_qualite_polites_lmtay527");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur1,"taQualiteNormaliseeLmtay520");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur2,"taQualitePolitesseLmtay526");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_qualite_normal_qualite_polites_lmtay527");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  modificationAvecMajDate(String champ1, String champ2, String champ3, String valeur1, int valeur3JJ, String valeur3MM, String valeur3SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
		    DetailsTablePage consulterTable = listeTables.consultation("ta_qualite_normal_qualite_polites_lmtay527");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_qualite_normal_qualite_polites_lmtay527");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
	}
}
