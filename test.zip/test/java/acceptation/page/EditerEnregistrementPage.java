package acceptation.page;

import org.openqa.selenium.WebDriver;


public class EditerEnregistrementPage extends AbstractUpsert {

	public EditerEnregistrementPage(WebDriver driver) {
		this.driver = driver;
	}

}
