package acceptation.page;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CaptureEcranUtil {
	
	/**
	 * Effectue une capture d'écran avec pour nom de fichier capture_exception_timestamp.png dans le répertoire des résultats de test
	 * @param driver
	 */
	public static void prendreCaptureEcran(WebDriver driver){
	    try {
		    Date date = new Date();
		    File captureEcran = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    	String emplacementSauvegarde = System.getProperty("concordion.output.dir");
		    String nomFichier = emplacementSauvegarde+File.separator+"capture_exception_"+date.getTime()+".png";
	    	System.out.println("Sauvegarde de la capture d'écran : "+nomFichier);
	        FileUtils.copyFile(captureEcran, new File(nomFichier));
	    } catch (IOException e) {
	        e.printStackTrace();
	    }	
	}


}
