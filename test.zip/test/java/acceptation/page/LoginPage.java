package acceptation.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPage {

	protected WebDriver driver;

	@FindBy(id="j_username")
	protected WebElement champLogin;
	@FindBy(id="j_password")
	protected WebElement champPassword;
	@FindBy(className="valider")
	protected WebElement boutonValider;

	public String login;
	public String password;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public AccueilPage login(String user, String password) {
		champLogin.sendKeys(this.login);
		champPassword.sendKeys(this.password);
		boutonValider.click();
		return PageFactory.initElements(driver, AccueilPage.class);

	}
}
