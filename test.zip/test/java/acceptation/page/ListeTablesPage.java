package acceptation.page;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ListeTablesPage {
	protected WebDriver driver;

	public ListeTablesPage(WebDriver driver) {
		this.driver = driver;
	}


	public DetailsTablePage consultation(String nomTable){
		WebElement ligne = driver.findElement(By.id(nomTable));
		ligne.click();

		WebDriverWait wait = new WebDriverWait(driver, 300);
		WebElement selectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("roue_consultation_"+nomTable)));

		selectElement.click();
		return PageFactory.initElements(driver, DetailsTablePage.class);
	}

	public InsererEnregistrementPage insertionLigne(String nomTable){
		//try {
			WebElement ligne = driver.findElement(By.id(nomTable));
			ligne.click();
			WebDriverWait wait = new WebDriverWait(driver, 300);
			WebElement selectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("roue_insertion_"+nomTable)));

			selectElement.click();
			return PageFactory.initElements(driver, InsererEnregistrementPage.class);
			/*} catch(NoSuchElementException exception){
			Date date = new Date();

			String source = driver.getPageSource();
			PrintWriter sortie;
			try {
				sortie = new PrintWriter("C:\\Prive\\source_"+nomTable+"_"+date.getTime()+".html");
				sortie.println(source);
				sortie.close();

			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			File captureEcran = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(captureEcran, new File("C:\\Prive\\capture_"+nomTable+"_insertion_"+date.getTime()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw exception;*/

	}




}
