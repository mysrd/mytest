package acceptation;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
			Lmtay400Fixture.class,
			Lmtay400plusFixture.class,
			Lmtay401Fixture.class,
			Lmtay401plusFixture.class,
			Lmtay402Fixture.class,
			Lmtay402plusFixture.class,
			Lmtay403Fixture.class,
			Lmtay403plusFixture.class,
			Lmtay511Fixture.class,
			Lmtay511plusFixture.class,
			Lmtay518Fixture.class,
			Lmtay518plusFixture.class,
			Lmtay520Fixture.class,
			Lmtay520plusFixture.class,
			Lmtay523Fixture.class,
			Lmtay523plusFixture.class,
			Lmtay524Fixture.class,
			Lmtay524plusFixture.class,
			Lmtay525Fixture.class,
			Lmtay525plusFixture.class,
			Lmtay526Fixture.class,
			Lmtay526plusFixture.class,
			Lmtay527Fixture.class,
			Lmtay527plusFixture.class,
			Lmtay533Fixture.class,
			Lmtay538plusFixture.class,
			Lmtay538Fixture.class,
			Lmtay540Fixture.class,
			Lmtay540plusFixture.class,
			Lmtay560Fixture.class,
			Lmtay717Fixture.class,
			Lmtay717plusFixture.class,
			Lmtay718Fixture.class,
			Lmtay718plusFixture.class,
			Lmtay738Fixture.class,
			Lmtay738plusFixture.class,
			Lmtay739Fixture.class,
			Lmtay774Fixture.class,
			Lmtay774plusFixture.class,
			Lmtay786Fixture.class,
			Lmtay786plusFixture.class,
			Lmtay788Fixture.class,
			Lmtay788plusFixture.class,
			Lmtay789Fixture.class,
			Lmtay789plusFixture.class,
			Lmtay790Fixture.class,
			Lmtay790plusFixture.class,
			Lmtay791Fixture.class,
			Lmtay791plusFixture.class,
			Lmtay792Fixture.class,
			Lmtay792plusFixture.class,
			Lmtay793Fixture.class,
			Lmtay793plusFixture.class,
			Lmtay794Fixture.class,
			Lmtay794plusFixture.class,
			Lmtay796Fixture.class,
			Lmtay796plusFixture.class,
			Lmtay797Fixture.class,
			Lmtay797plusFixture.class,
			Lmtay799Fixture.class,
			Lmtay799plusFixture.class,
			Lmtay831Fixture.class,
			Lmtay831plusFixture.class,
			Lmtay947Fixture.class,
			Lmtay967Fixture.class,
			Lmtay967plusFixture.class,
			Lmtay999Fixture.class

})

public class AcceptationSuite {
	@BeforeClass
	public static void before(){
		System.out.println("Lancement de la suite");
	}

	@AfterClass
	public static void after(){
		System.out.println("Fin de la suite");
	}

}
