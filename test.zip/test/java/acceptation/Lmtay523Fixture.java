package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay523.xml")

public class Lmtay523Fixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
    											String champ12,
    											String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
    											String champ22,
    											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
    											int valeur12JJ, String valeur12MM, String valeur12SSAA,
    											String valeur13, String valeur14, String valeur15, String valeur16, String valeur17, String valeur18, String valeur19, String valeur20, String valeur21,
    											int valeur22JJ, String valeur22MM, String valeur22SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_client_lmtay523");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taNomenclatureDeClienteleLmtay774");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taModeDeGestionClientsLmtay831");
			insererEnregistrement.selectionnerDate(valeur12JJ, valeur12MM, valeur12SSAA, "ydclot");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taRgptCategorieClienteleComptLmtay947");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			insererEnregistrement.remplirChamp(champ15, valeur15);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taProfilTitulaireLmtay400");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taTypeFiliereLmtay401");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur20,"taListeOpcvmLmtay402");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur21,"taChoixOuiNonByYtnopc");
			insererEnregistrement.selectionnerDate(valeur22JJ, valeur22MM, valeur22SSAA, "ydf000");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_client_lmtay523");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			t.champ19 = donnees.get(champ19);
			t.champ20 = donnees.get(champ20);
			t.champ21 = donnees.get(champ21);
			t.champ22 = donnees.get(champ22);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}

    public Tuyau insertionCasNominalSansMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
												String champ12,
												String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
												String champ22,
												String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur7, String valeur8, String valeur9,
												String valeur14, String valeur16, String valeur17) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_client_lmtay523");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_client_lmtay523");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			t.champ19 = donnees.get(champ19);
			t.champ20 = donnees.get(champ20);
			t.champ21 = donnees.get(champ21);
			t.champ22 = donnees.get(champ22);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
															String champ12,
															String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
															String champ22,
															String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
															String valeur13, String valeur14, String valeur15, String valeur16, String valeur17, String valeur18, String valeur19, String valeur20, String valeur21, int noCas) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_client_lmtay523");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taNomenclatureDeClienteleLmtay774");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taModeDeGestionClientsLmtay831");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taRgptCategorieClienteleComptLmtay947");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			insererEnregistrement.remplirChamp(champ15, valeur15);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taProfilTitulaireLmtay400");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taTypeFiliereLmtay401");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur20,"taListeOpcvmLmtay402");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur21,"taChoixOuiNonByYtnopc");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
	    	switch (noCas)
			{
			case 4:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
				break;
			case 5:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
				break;
			case 6:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ3);
				break;
			default:
				break;
			}
	    	this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
												String champ12,
												String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
												String champ22,
												String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
												int valeur12JJ, String valeur12MM, String valeur12SSAA,
												String valeur13, String valeur14, String valeur15, String valeur16, String valeur17, String valeur18, String valeur19, String valeur20, String valeur21,
												int valeur22JJ, String valeur22MM, String valeur22SSAA) {
    	try{
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_client_lmtay523");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taNomenclatureDeClienteleLmtay774");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taModeDeGestionClientsLmtay831");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taRgptCategorieClienteleComptLmtay947");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			insererEnregistrement.remplirChamp(champ15, valeur15);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taProfilTitulaireLmtay400");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taTypeFiliereLmtay401");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur20,"taListeOpcvmLmtay402");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur21,"taChoixOuiNonByYtnopc");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();

	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
											String champ12,
											String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
											String champ22,
											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
											int valeur12JJ, String valeur12MM, String valeur12SSAA,
											String valeur13, String valeur14, String valeur15, String valeur16, String valeur17, String valeur18, String valeur19, String valeur20, String valeur21,
											int valeur22JJ, String valeur22MM, String valeur22SSAA) {
    	try{
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_categorie_de_client_lmtay523");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			insererEnregistrement.remplirChamp(champ6, valeur6);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taNomenclatureDeClienteleLmtay774");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taModeDeGestionClientsLmtay831");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taRgptCategorieClienteleComptLmtay947");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			insererEnregistrement.remplirChamp(champ15, valeur15);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taProfilTitulaireLmtay400");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taTypeFiliereLmtay401");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur20,"taListeOpcvmLmtay402");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur21,"taChoixOuiNonByYtnopc");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}

    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9, String champ10, String champ11,
													String champ12,
													String champ13, String champ14, String champ15, String champ16, String champ17, String champ18, String champ19, String champ20, String champ21,
													String champ22,
													String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6, String valeur7, String valeur8, String valeur9, String valeur10, String valeur11,
													int valeur12JJ, String valeur12MM, String valeur12SSAA,
													String valeur13, String valeur14, String valeur15, String valeur16, String valeur17, String valeur18, String valeur19, String valeur20, String valeur21,
													int valeur22JJ, String valeur22MM, String valeur22SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_categorie_de_client_lmtay523");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.remplirChamp(champ3, valeur3);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taChoixOuiNonByCnoagr");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taChoixOuiNonByCappar");
			editerEnregistrement.remplirChamp(champ6, valeur6);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur7,"taChoixOuiNonByYcfccc");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur8,"taFamilleCommercialeLmtay738");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur9,"taChoixOuiNonByCcclit");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur10,"taNomenclatureDeClienteleLmtay774");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur11,"taModeDeGestionClientsLmtay831");
			editerEnregistrement.selectionnerDate(valeur12JJ, valeur12MM, valeur12SSAA, "ydclot");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur13,"taRgptCategorieClienteleComptLmtay947");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur14,"taChoixOuiNonByTetpub");
			editerEnregistrement.remplirChamp(champ15, valeur15);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur16,"taClassificationMifLmtay718");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur17,"taChoixOuiNonByCsinfo");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur18,"taProfilTitulaireLmtay400");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur19,"taTypeFiliereLmtay401");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur20,"taListeOpcvmLmtay402");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur21,"taChoixOuiNonByYtnopc");
			editerEnregistrement.selectionnerDate(valeur22JJ, valeur22MM, valeur22SSAA, "ydf000");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_categorie_de_client_lmtay523");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			t.champ10 = donnees.get(champ10);
			t.champ11 = donnees.get(champ11);
			t.champ12 = donnees.get(champ12);
			t.champ13 = donnees.get(champ13);
			t.champ14 = donnees.get(champ14);
			t.champ15 = donnees.get(champ15);
			t.champ16 = donnees.get(champ16);
			t.champ17 = donnees.get(champ17);
			t.champ18 = donnees.get(champ18);
			t.champ19 = donnees.get(champ19);
			t.champ20 = donnees.get(champ20);
			t.champ21 = donnees.get(champ21);
			t.champ22 = donnees.get(champ22);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public String champ10;
		public String champ11;
		public String champ12;
		public String champ13;
		public String champ14;
		public String champ15;
		public String champ16;
		public String champ17;
		public String champ18;
		public String champ19;
		public String champ20;
		public String champ21;
		public String champ22;
		public boolean enAnomalie;

	}
}
