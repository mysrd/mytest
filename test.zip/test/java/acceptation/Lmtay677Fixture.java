package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_lmtay677.xml")

public class Lmtay677Fixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
    											String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA, int valeur5JJ, String valeur5MM, String valeur5SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nomenclat_insee_activ_econom_lmtay677");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taMotifDePaiementCrpPrBdpLmtay979");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "ydfeff");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_nomenclat_insee_activ_econom_lmtay677");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
												String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nomenclat_insee_activ_econom_lmtay677");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taMotifDePaiementCrpPrBdpLmtay979");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "yddeff");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_nomenclat_insee_activ_econom_lmtay677");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
															String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA,
															int noCas) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
    		AccueilPage accueil = loginPage.login("admin", "password");
    		ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_nomenclat_insee_activ_econom_lmtay677");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taMotifDePaiementCrpPrBdpLmtay979");
			insererEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "yddeff");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
			switch (noCas)
			{
			case 3:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
				break;
			case 4:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ2);
				break;
			default:
				break;
			}
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
    	} catch (Exception e){
    		this.fermetureSelenium();
    		throw e;
    	}
    }


    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6,
													String valeur1, String valeur2, String valeur3, int valeur4JJ, String valeur4MM, String valeur4SSAA,
													int valeur5JJ, String valeur5MM, String valeur5SSAA, int valeur6JJ, String valeur6MM, String valeur6SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_nomenclat_insee_activ_econom_lmtay677");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taMotifDePaiementCrpPrBdpLmtay979");
			editerEnregistrement.selectionnerDate(valeur4JJ, valeur4MM, valeur4SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur5JJ, valeur5MM, valeur5SSAA, "ydfeff");
			editerEnregistrement.selectionnerDate(valeur6JJ, valeur6MM, valeur6SSAA, "ydclot");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_nomenclat_insee_activ_econom_lmtay677");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			return t;
    	} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
}


    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public boolean enAnomalie;

	}
}
