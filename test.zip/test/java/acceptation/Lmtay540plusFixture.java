package acceptation;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;
import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay540plus.xml")
public class Lmtay540plusFixture extends AbstractFixture {

    public Tuyau  creationRechercheValeurCloseListeDeroulante(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_adresse_lmtay540");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			boolean estPresent = insererEnregistrement.verifierPresenceValeurListeDeroulante(valeur3,"taTypeUtilisationAdresseLmtay790");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau modificationRechercheValeurCloseDorigineListeDeroulante(String champclef, String champamodifier, String champamodifierbis, String valeurclef, String valeurnouvelle, String valeurdorigine){
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_type_adresse_lmtay540");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeurclef);
	  		editerEnregistrement.selectionnerValeurListeDéroulante(valeurnouvelle,"taTypeUtilisationAdresseLmtay790");
			boolean estPresent = editerEnregistrement.verifierPresenceValeurListeDeroulante(valeurdorigine,"taTypeUtilisationAdresseLmtay790");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur est absente de la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau modificationRechercheValeurCloseListeDeroulante(String champclef, String champamodifier,  String valeurclef, String valeurnouvelle ){
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_type_adresse_lmtay540");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeurclef);
			boolean estPresent = editerEnregistrement.verifierPresenceValeurListeDeroulante(valeurnouvelle,"taTypeUtilisationAdresseLmtay790");
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estPresent){
	 			t.champ1="Cette valeur est présente dans la liste";
	 		} else {
	 			t.champ1 ="Cette valeur n'est pas présente dans la liste";
	 		}
	 		t.enAnomalie = estPresent;

	 		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3, String champ4, String valeur4) {
 		try {
	    	LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_adresse_lmtay540");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur3,"taTypeUtilisationAdresseLmtay790");
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante";
	 		} else {
	 			t.champ1 ="non bloquante";
	 		}
	 		t.enAnomalie = estEnAnomalie;

	 		return t;
		} catch(Exception e){
			this.fermetureSelenium();
			throw e;
		}
     }



    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public boolean enAnomalie;
	}
}
