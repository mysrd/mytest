package acceptation;

import java.util.Map;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay603.xml")

public class Lmtay603Fixture extends AbstractFixture {


    public Tuyau  consultation(String champ1, String champ2, String valeur1) {
		try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage detailsTable = listeTables.consultation("ta_jour_ferie_oc_bdf_lmtay603");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}



	public class Tuyau {
		public String champ1;
		public String champ2;
	}
}
