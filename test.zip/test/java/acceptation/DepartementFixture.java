package acceptation;
import java.util.Map;
import org.concordion.api.FailFast;
import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;
@FailFast
@DataSet(value ="dataset/jeudetest_departement.xml")

public class DepartementFixture extends AbstractFixture {

    public Tuyau insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9,
    											String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6,
    											int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
    	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_departement");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taTerritorialiteFicobaLmtay508");
			insererEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_departement");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau insertionCasErreurZoneObligatoireNonSaisie(String champ1, String champ2, String champ3, String champ4, String champ5, String champ7, String champ8, String champ9,
															String valeur1, String valeur2, String valeur3, String valeur4, String valeur5,
															int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA,int noCas) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_departement");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = true;
	    	switch (noCas)
			{
			case 2:
				estEnAnomalie= insererEnregistrement.selectionnerChampEnAnomalie(champ1);
				break;
			case 7:
				estEnAnomalie = insererEnregistrement.selectionnerChampEnAnomalie(champ2);
					break;
			case 9:
				estEnAnomalie = insererEnregistrement.selectionnerChampEnAnomalie(champ3);
					break;
			default:
				break;
			}
	    	this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;

			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
    }



    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String champ4, String champ5, String champ7, String champ8, String champ9,
												String valeur1, String valeur2, String valeur3, String valeur4, String valeur5,
												int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
       	try{
    		LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_departement");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
       	} catch (Exception e){
       		this.fermetureSelenium();
       		throw e;
       	}
    }



    public Tuyau  modificationCasNominalAvecMajDate(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String champ7, String champ8, String champ9,
													String valeur1, String valeur2, String valeur3, String valeur4, String valeur5, String valeur6,
													int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_departement");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.remplirChamp(champ3, valeur3);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur6,"taTerritorialiteFicobaLmtay508");
			editerEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_departement");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);

			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);
			t.champ4 = donnees.get(champ4);
			t.champ5 = donnees.get(champ5);
			t.champ6 = donnees.get(champ6);
			t.champ7 = donnees.get(champ7);
			t.champ8 = donnees.get(champ8);
			t.champ9 = donnees.get(champ9);
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



    public Tuyau  insertionCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ7, String champ8, String champ9,
											   String valeur1, String valeur2, String valeur3, String valeur4, String valeur5,
											   int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_departement");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
	}


    public Tuyau  insertionCasSaisieTropCourte(String champ1, String champ2, String champ3, String champ4, String champ5, String champ7, String champ8, String champ9,
			   								   String valeur1, String valeur2, String valeur3, String valeur4, String valeur5,
			   								   int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_departement");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }


    public Tuyau  insertionCasDatesEffetInvalides(String champ1, String champ2, String champ3, String champ4, String champ5, String champ7, String champ8, String champ9,
			   									  String valeur1, String valeur2, String valeur3, String valeur4, String valeur5,
			   									  int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_departement");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			insererEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			insererEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			insererEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterExceptionMetier();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e) {
			this.fermetureSelenium();
			throw e;
		}
   	}


    public Tuyau  modificationCasSaisieTropLongue(String champ1, String champ2, String champ3, String champ4, String champ5, String champ7, String champ8, String champ9,
    												String valeur1, String valeur2, String valeur3, String valeur4, String valeur5,
    												int valeur7JJ, String valeur7MM, String valeur7SSAA, int valeur8JJ, String valeur8MM, String valeur8SSAA) {
    	try{
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_departement");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
			editerEnregistrement.remplirChamp(champ2, valeur2);
			editerEnregistrement.remplirChamp(champ3, valeur3);
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur4,"taRegionAdministrativeLmtay547");
			editerEnregistrement.selectionnerValeurListeDéroulante(valeur5,"taRegion2016");
			editerEnregistrement.selectionnerDate(valeur7JJ, valeur7MM, valeur7SSAA, "yddeff");
			editerEnregistrement.selectionnerDate(valeur8JJ, valeur8MM, valeur8SSAA, "ydfeff");
			accueil = editerEnregistrement.enregistrerErreur();
			boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante.";
			} else {
				t.champ1 ="non bloquante.";
			}
			t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }





	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public String champ4;
		public String champ5;
		public String champ6;
		public String champ7;
		public String champ8;
		public String champ9;
		public boolean enAnomalie;

	}
}
