package acceptation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.excilys.ebi.spring.dbunit.test.DataSet;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;
import org.concordion.api.FailFast;

@FailFast
@DataSet(value ="dataset/jeudetest_lmtay717.xml")

public class Lmtay717plusFixture extends AbstractFixture {


    public Tuyau  insertionCasCaractereNonAutorise(String champ1, String champ2, String champ3, String champ4, String champ5, String champ6, String valeur1, String valeur2, String valeur3) {
    	try {
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_classification_bale2_lmtay717");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.remplirChamp(champ3, valeur3);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
			this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante.";
	 		} else {
	 			t.champ1 ="non bloquante.";
	 		}
	 		t.enAnomalie = estEnAnomalie;
			return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
    }

    public Tuyau  modificationCasCaractereNonAutorise(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
    	try {
	  		LoginPage loginPage = initialisationSelenium();
	  		AccueilPage accueil = loginPage.login("admin", "password");
	  		ListeTablesPage listeTables = accueil.voirListeTables();
	  		DetailsTablePage consulterTable = listeTables.consultation("ta_classification_bale2_lmtay717");
	 		EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeur1);
   			editerEnregistrement.remplirChamp(champ2, valeur2);
   			editerEnregistrement.remplirChamp(champ3, valeur3);
	  		accueil = editerEnregistrement.enregistrerErreur();
	  		boolean estEnAnomalie = accueil.detecterMessageErreur();
	  		this.fermetureSelenium();
	  		Tuyau t = new Tuyau();
	  		if(estEnAnomalie){
	  			t.champ1="bloquante.";
	  		} else {
	  			t.champ1 ="non bloquante.";
	  		}
	  		t.enAnomalie = estEnAnomalie;

	  		return t;
		} catch (Exception e){
			this.fermetureSelenium();
			throw e;
		}
   	}



    public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public boolean enAnomalie;
	}

}
