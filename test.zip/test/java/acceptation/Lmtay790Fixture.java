package acceptation;
import java.util.Map;

import org.concordion.api.FailFast;

import acceptation.page.AccueilPage;
import acceptation.page.DetailsTablePage;
import acceptation.page.EditerEnregistrementPage;
import acceptation.page.InsererEnregistrementPage;
import acceptation.page.ListeTablesPage;
import acceptation.page.LoginPage;

import com.excilys.ebi.spring.dbunit.test.DataSet;

@DataSet(value ="dataset/jeudetest_lmtay790.xml")
@FailFast
public class Lmtay790Fixture extends AbstractFixture {



	public class Tuyau {
		public String champ1;
		public String champ2;
		public String champ3;
		public boolean enAnomalie;
	}


    public Tuyau  insertionCasNominalAvecMajDate(String champ1, String champ2, String champ3, String valeur1, String valeur2, int valeur3JJ, String valeur3MM, String valeur3SSAA, String valeur1bis ) {
		try {
	    	LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur3JJ, valeur3MM, valeur3SSAA, "ydclot");
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_type_utilisation_adresse_lmtay790");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1bis);
			//assertEquals(valeur1,donnees.get(champ1));
			//assertEquals(valeur2,donnees.get(champ2));
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);

			return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

    }



    public Tuyau  insertionCasErreurCodeNonSaisi(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
    	try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = insererEnregistrement.selectionnerChampEnAnomalie(champ1);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante";
			} else {
				t.champ1 ="non bloquante";
			}
			t.enAnomalie = estEnAnomalie;

			return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

    }


    public Tuyau  insertionCasErreurLibelleNonSaisi(String champ1, String champ2, String champ3, String valeur1, String valeur2, int valeur3, String valeur4, String valeur5) {
		try {
	    	LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			insererEnregistrement.selectionnerDate(valeur3, valeur4, valeur5, "ydclot");
			insererEnregistrement.enregistrerBloquant();
			boolean estEnAnomalie = insererEnregistrement.selectionnerChampEnAnomalie(champ2);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			if(estEnAnomalie){
				t.champ1="bloquante";
			} else {
				t.champ1 ="non bloquante";
			}
			t.enAnomalie = estEnAnomalie;

			return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

    }


    public Tuyau  insertionCasNominal(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
    	try {
			LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
			insererEnregistrement.remplirChamp(champ1, valeur1);
			insererEnregistrement.remplirChamp(champ2, valeur2);
			listeTables = insererEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_type_utilisation_adresse_lmtay790");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeur1);
			//assertEquals(valeur1,donnees.get(champ1));
			//assertEquals(valeur2,donnees.get(champ2));
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(champ1);
			t.champ2 = donnees.get(champ2);
			t.champ3 = donnees.get(champ3);

			return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

    }


    public Tuyau editionCasNominal(String nomchampamodifier, String valeurchampamodifieravant, String valeurchampamodifierapres, String champclef, String valeurclef){
    	try {
	    	LoginPage loginPage = initialisationSelenium();
			AccueilPage accueil = loginPage.login("admin", "password");
			ListeTablesPage listeTables = accueil.voirListeTables();
			DetailsTablePage consulterTable = listeTables.consultation("ta_type_utilisation_adresse_lmtay790");
			EditerEnregistrementPage editerEnregistrement = consulterTable.editer(valeurclef);
			editerEnregistrement.remplirChamp(nomchampamodifier, valeurchampamodifierapres);
			listeTables = editerEnregistrement.enregistrer();
			DetailsTablePage detailsTable = listeTables.consultation("ta_type_utilisation_adresse_lmtay790");
			Map<String,String> donnees = detailsTable.obtenirDonneesParIdentifiant(valeurclef);
			this.fermetureSelenium();
			Tuyau t = new Tuyau();
			t.champ1 = donnees.get(nomchampamodifier);

			return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

    }


    public Tuyau  insertionCasErreurCleEnDouble(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
    	try {
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
	 		insererEnregistrement.remplirChamp(champ1, valeur1);
	 		insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante";
	 		} else {
	 			t.champ1 ="non bloquante";
	 		}
	 		t.enAnomalie = estEnAnomalie;

	 		return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

     }


    public Tuyau  insertionCasErreurCodeTropLong(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
 		try {
	    	LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
	 		insererEnregistrement.remplirChamp(champ1, valeur1);
	 		insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante";
	 		} else {
	 			t.champ1 ="non bloquante";
	 		}
	 		t.enAnomalie = estEnAnomalie;

	 		return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

     }


    public Tuyau  insertionCasErreurLibelleTropLong(String champ1, String champ2, String champ3, String valeur1, String valeur2, String valeur3) {
    	try {
	 		LoginPage loginPage = initialisationSelenium();
	 		AccueilPage accueil = loginPage.login("admin", "password");
	 		ListeTablesPage listeTables = accueil.voirListeTables();
	 		InsererEnregistrementPage insererEnregistrement = listeTables.insertionLigne("ta_type_utilisation_adresse_lmtay790");
	 		insererEnregistrement.remplirChamp(champ1, valeur1);
	 		insererEnregistrement.remplirChamp(champ2, valeur2);
	 		accueil = insererEnregistrement.enregistrerErreur();
	 		boolean estEnAnomalie = accueil.detecterMessageErreur();
	 		this.fermetureSelenium();
	 		Tuyau t = new Tuyau();
	 		if(estEnAnomalie){
	 			t.champ1="bloquante";
	 		} else {
	 			t.champ1 ="non bloquante";
	 		}
	 		t.enAnomalie = estEnAnomalie;

	 		return t;
		} catch(Exception e){
			fermetureSelenium();
			throw e;
		}

     }


}
