package edt.presentation.controller;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.handler;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import mockit.Expectations;
import mockit.Injectable;
import mockit.Tested;

import org.dozer.Mapper;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import edt.presentation.AbstractControllerTest;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.edt.presentation.controller.EditTablesAdministrationController;
import fr.icdc.dei.edt.presentation.controller.ValeursUtilisateurEdittable;
import fr.icdc.dei.lm4.paraneo.metier.service.SecuriteBusinessService;
import fr.icdc.dei.lm4.paraneo.metier.service.impl.NotificationDidoBusinessServiceImpl;
import fr.icdc.dei.lm4.paraneo.presentation.commun.helper.CacheHolder;
import fr.icdc.dei.lm4.paraneo.presentation.referentiel.dto.edittables.TableDescriptionDto;
@Ignore(value="Mieux couvert par les tests d'acceptation. Il faudrait injecter beaucoup de donnees fictives pour le faire fonctionner.")
public class EditTablesAdministrationControllerTest extends edt.presentation.AbstractControllerTest {
		@Injectable
		private CacheHolder cacheHolder;

		@Injectable
		private Mapper mapper;

		@Resource
		@Tested
		private EditTablesAdministrationController controller;

		@Injectable
		ReferentielBusinessService service;

		@Injectable
		private NotificationDidoBusinessServiceImpl notificationDido;

		@Injectable
		private SecuriteBusinessService securiteService;

		@Injectable
		private  HttpServletRequest request;

		@Injectable
	    private ServletContext context;

		@Injectable
		private ValeursUtilisateurEdittable valeursUtilisateur;


		@BeforeClass
		public static void setUpBeforeClass() throws Exception {
			AbstractControllerTest.initContext();
		}

		@Before
		public void setup() {
			super.setup();
		}

		@Test
		public void testshowTableList() throws Exception {
			final List<TableDescription> toto = new ArrayList<>();
			TableDescription maTable = new TableDescription();
			toto.add(maTable);

			final List<TableDescriptionDto> totoDto = new ArrayList<>();
			TableDescriptionDto maTableDto = new TableDescriptionDto();
			totoDto.add(maTableDto);

			new Expectations() {{
				service.getTableList();result=toto;
			}};

			/*Class[] cArg = new Class[6];
			cArg[0] = ApdmCompensateurForm.class;
			cArg[1] = BindingResult.class;
			cArg[2] = String.class;
			cArg[3] = Boolean.class;
			cArg[4] = String.class;
			cArg[5] = Long.class;*/



			this.mockMvc
				.perform(get("/edittables/tableList"))
				//.param("provenance", "4")
				//.param("previousOperationState", "false")
				//.param("message", "message")
				//.param("idFiltre", "1")
				//.param("numeroVersion", "1")
				//.param("dateBackOffice", "01/01/2014"))
				.andDo(print())
				.andExpect(handler().handlerType(EditTablesAdministrationController.class))
				//.andExpect(handler().method((tbCompenseController.getClass()).getDeclaredMethod("showTbCompense", cArg)))
//				.andExpect(request().asyncNotStarted())
//				.andExpect(request().asyncResult(null))
				.andExpect(status().isOk())
				.andExpect(view().name("edittables.administration.listtables"))
				//.andExpect(model().attribute("tables", Matchers.hasProperty(propertyName)))
				//.andExpect(model().attributeHasNoErrors("enregistrerForm"))
				//.andExpect(model().attributeDoesNotExist("controles"))
				.andExpect(model().attribute("tables",totoDto))
				.andExpect(model().attributeDoesNotExist("previousOperationState"))
				//.andExpect(model().attribute("message","message"))
				//.andExpect(forwardedUrl("/WEB-INF/pages/layout/main.jsp"))
				.andExpect(redirectedUrl(null));
		}

}