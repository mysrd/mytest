package edt.presentation;

import javax.jms.ConnectionFactory;
import javax.naming.NamingException;

import mockit.Mock;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jca.cci.connection.DelegatingConnectionFactory;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@WebAppConfiguration
@ContextConfiguration(locations = {
		"file:src/main/webapp/WEB-INF/spring/security-config.xml",
		"file:src/main/webapp/WEB-INF/spring/backend-config.xml",
		"file:src/main/webapp/WEB-INF/spring/hdiv-config.xml",
		"file:src/main/webapp/WEB-INF/spring/presentation-config.xml" })
@ActiveProfiles(value = "devintegration")
@RunWith(SpringJUnit4ClassRunner.class)
public abstract class AbstractControllerTest {

	protected MockMvc mockMvc;

	@Autowired
	protected WebApplicationContext wac ;


	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}

	protected static void initContext() throws NamingException {
		SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
		builder.bind("java:comp/env/ldap/gide/idappli", "3093");
		builder.bind("java:comp/env/ldap/gide/codeappli", "LM4");
		builder.bind("java:comp/env/ldap/gide/url", "http://sps-support-confiancenum-int.serv.cdc.fr:10100/Confiance/Numerique/Prive/GIDE/AUTHENT/Facade/V1.2.1");
		builder.bind("java:comp/env/ldap/gide/clientid", "urn:cdc:banque:paraneo:lm4:3093:iihm:1.0");
		builder.bind("java:comp/env/ldap/gide/serviceid", "urn:cdc:support:gide:authent:ws:1.2.1");
		builder.bind("java:comp/env/paraneo/environnement", "LOC" );
		builder.bind("java:comp/env/jms/qcfdido",new MockConnectionFactory());
		builder.bind("java:comp/env/jms/queuedido",new MockDestination());
	    builder.activate();
	}
}